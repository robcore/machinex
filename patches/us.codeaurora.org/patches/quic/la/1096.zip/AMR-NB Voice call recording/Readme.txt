AMR-NB Voice call recorder 


Apply the patch on 6370 build 

1. There are 7 patches and apply the patch from the top android tree level:

patch -p1 -i <path_file>

2. Make sure to re-build the kernel and device tree after applying the patch.

How to test this feature

After booting up the phone, open the voice recorder application.

select the input source 

Key 0 : MIC
key 1 : TX
key 2 : RX
Key 3 :TX-RX


