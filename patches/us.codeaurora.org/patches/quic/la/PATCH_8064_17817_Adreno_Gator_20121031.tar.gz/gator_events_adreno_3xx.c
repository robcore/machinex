/**
 * Copyright (c) 2012, The Linux Foundation. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 and
 * only version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <linux/init.h>
#include <linux/io.h>
#include <linux/ratelimit.h>

#include "gator.h"

#include "../gpu/msm/kgsl_device.h"

struct counter_info {
	unsigned long enabled;
	unsigned long event;
	unsigned long key;

	unsigned int last_val;
	bool read_once;

	unsigned int read_offset;

	unsigned int select_offset;
};

/*
 * For each counter set, copy the given fragment to events.xml
 */

/*
  <counter_set name="a3xx_rbbm_cntX">
    <counter name="a3xx_rbbm_cnt0" />
    <counter name="a3xx_rbbm_cnt1" />
  </counter_set>
  <category name="Adreno RBBM Metrics" counter_set="a3xx_rbbm_cntX">
    <event event="0x0" title="GPU Clock" name="Awake cycles" display="hertz" units="Hz" average_selection="yes" />
    <event event="0x16" title="GPU Clock" name="Busy cycles" display="hertz" units="Hz" average_selection="yes" />
  </category>
 */
#define RBBM_COUNTERS 2
static struct counter_info rbbm_counters[RBBM_COUNTERS];

/*
  <counter_set name="a3xx_hlsq_cntX">
    <!-- HLSQ counter 0 is reserved for internal use -->
    <counter name="a3xx_hlsq_cnt1" />
    <counter name="a3xx_hlsq_cnt2" />
    <counter name="a3xx_hlsq_cnt3" />
    <counter name="a3xx_hlsq_cnt4" />
    <counter name="a3xx_hlsq_cnt5" />
  </counter_set>
  <category name="Adreno HLSQ Metrics" counter_set="a3xx_hlsq_cntX" per_cpu="no">
    <event event="0x5" title="Pixel throughput" name="2x2 pixel quads" />
    <event event="0x6" title="Pixel throughput" name="Pixels" />
    <event event="0x7" title="Vertex throughput" name="Vertices" />
  </category>
 */
#define HLSQ_COUNTERS 6
static struct counter_info hlsq_counters[HLSQ_COUNTERS];

/*
  <counter_set name="a3xx_tse_cntX">
    <counter name="a3xx_tse_cnt0" />
    <counter name="a3xx_tse_cnt1" />
  </counter_set>
  <category name="Adreno TSE Metrics" counter_set="a3xx_tse_cntX" per_cpu="no">
    <event event="0x0" title="Vertex throughput" name="Primitives" />
  </category>
 */
#define TSE_COUNTERS 2
static struct counter_info tse_counters[TSE_COUNTERS];

/*
  <counter_set name="a3xx_uche_cntX">
    <counter name="a3xx_uche_cnt0" />
    <counter name="a3xx_uche_cnt1" />
    <counter name="a3xx_uche_cnt2" />
    <counter name="a3xx_uche_cnt3" />
    <counter name="a3xx_uche_cnt4" />
    <counter name="a3xx_uche_cnt5" />
  </counter_set>
  <category name="Adreno UCHE Metrics" counter_set="a3xx_uche_cntX" per_cpu="no">
    <event event="0x8" title="Graphics cache reads" name="Read requests from TP" />
  </category>
 */
#define UCHE_COUNTERS 6
static struct counter_info uche_counters[UCHE_COUNTERS];

/*
  <counter_set name="a3xx_tp_cntX">
    <counter name="a3xx_tp_cnt0" />
    <counter name="a3xx_tp_cnt1" />
    <counter name="a3xx_tp_cnt2" />
    <counter name="a3xx_tp_cnt3" />
    <counter name="a3xx_tp_cnt4" />
    <counter name="a3xx_tp_cnt5" />
  </counter_set>
  <category name="Adreno TP Metrics" counter_set="a3xx_tp_cntX" per_cpu="no">
    <event event="0x0" title="Graphics cache reads" name="TP L1 cache requests" />
  </category>
 */
#define TP_COUNTERS 6
static struct counter_info tp_counters[TP_COUNTERS];

/*
  <counter_set name="a3xx_sp_cntX">
    <counter name="a3xx_sp_cnt0" />
    <counter name="a3xx_sp_cnt1" />
    <counter name="a3xx_sp_cnt2" />
    <counter name="a3xx_sp_cnt3" />
    <counter name="a3xx_sp_cnt4" />
    <counter name="a3xx_sp_cnt5" />
    <counter name="a3xx_sp_cnt6" />
    <counter name="a3xx_sp_cnt7" />
  </counter_set>
  <category name="Adreno SP Metrics" counter_set="a3xx_sp_cntX" per_cpu="no">
    <event event="0x8" title="VS Throughput" name="EFU Instructions" description="Elementary function instructions for valid vertex quads" />
    <event event="0x9" title="VS Throughput" name="Full ALU Instructions" description="Full-precision ALU instructions for vertex quads" />
    <event event="0xD" title="FS Throughput" name="EFU Instructions" description="Elementary function instructions for valid pixel quads" />
    <event event="0xE" title="FS Throughput" name="Full ALU Instructions" description="Full-precision ALU instructions for pixel quads" />
    <event event="0xF" title="FS Throughput" name="Half ALU Instructions" description="Half-precision ALU instructions for pixel quads" />
    <event event="0x10" title="FS Throughput" name="Barycentric Instructions" description="Barycentric ALU instructions for pixel quads" />
  </category>
 */
#define SP_COUNTERS 8
static struct counter_info sp_counters[SP_COUNTERS];

/*
  <counter_set name="a3xx_vbif_cntX">
    <counter name="a3xx_vbif_cnt0" />
    <counter name="a3xx_vbif_cnt1" />
  </counter_set>
  <category name="Adreno VBIF Metrics" counter_set="a3xx_vbif_cntX" per_cpu="no">
    <event event="20" title="AXI Memory" name="Total read requests" />
    <event event="41" title="AXI Memory" name="Total write requests" />
    <event event="60" title="AXI Memory" name="Number of beats read" />
    <event event="84" title="AXI Memory" name="Number of beats written" />
  </category>
 */
#define VBIF_COUNTERS 2
static struct counter_info vbif_counters[VBIF_COUNTERS];

#define MAX_COUNTERS (RBBM_COUNTERS + \
		HLSQ_COUNTERS + TSE_COUNTERS + UCHE_COUNTERS + \
		TP_COUNTERS + SP_COUNTERS + VBIF_COUNTERS)
static unsigned int a3xx_buffer[MAX_COUNTERS * 2];

static struct kgsl_device *pDevice;

static struct mutex sampling_mutex;

static void create_register_dirs(struct super_block *sb, struct dentry *root,
		struct counter_info *counters, int count, const char* format)
{
	int i;
	for (i = 0; i < count; i++)
	{
		char buf[32];
		struct dentry *dir;

		snprintf(buf, sizeof(buf), format, i);
		dir = gatorfs_mkdir(sb, root, buf);
		if (WARN_ON(!dir))
			return;

		gatorfs_create_ulong(sb, dir, "enabled", &counters[i].enabled);
		gatorfs_create_ulong(sb, dir, "event", &counters[i].event);
		gatorfs_create_ulong(sb, dir, "key", &counters[i].key);
	}
}

static int gator_events_a3xx_create_files(struct super_block *sb,
		struct dentry *root)
{
	unsigned int gpu_revision;

	gpu_revision = kgsl_gpuid(pDevice, NULL) & 0xffff;

	// Counters defined in this file are only valid on Adreno 3xx
	if (gpu_revision < 300 || gpu_revision >= 400)
	{
		return 0;
	}

	create_register_dirs(sb, root, rbbm_counters, RBBM_COUNTERS, "a3xx_rbbm_cnt%d");
	create_register_dirs(sb, root, hlsq_counters, HLSQ_COUNTERS, "a3xx_hlsq_cnt%d");
	create_register_dirs(sb, root, tse_counters,  TSE_COUNTERS,  "a3xx_tse_cnt%d");
	create_register_dirs(sb, root, uche_counters, UCHE_COUNTERS, "a3xx_uche_cnt%d");
	create_register_dirs(sb, root, tp_counters,   TP_COUNTERS,   "a3xx_tp_cnt%d");
	create_register_dirs(sb, root, sp_counters,   SP_COUNTERS,   "a3xx_sp_cnt%d");
	create_register_dirs(sb, root, vbif_counters, VBIF_COUNTERS, "a3xx_vbif_cnt%d");

	return 0;
}

static bool enable_counters(struct counter_info *counters,
		int count)
{
	int i;
	bool need_counters = false;

	for (i = 0; i < count; i++)
	{
		if (counters[i].enabled)
		{
			counters[i].last_val = 0xffffffff;
			counters[i].read_once = false;
			need_counters = true;

			kgsl_regwrite(pDevice, counters[i].select_offset, counters[i].event);
		}
	}

	return need_counters;
}

static unsigned int enable_counters_vbif(void)
{
	int i;
	unsigned int enable = 0;
	unsigned int selection = 0;

	for (i = 0; i < VBIF_COUNTERS; i++)
	{
		if (vbif_counters[i].enabled)
		{
			vbif_counters[i].last_val = 0xffffffff;
			vbif_counters[i].read_once = false;

			enable |= 1 << i;
			selection |= vbif_counters[i].event << (8 * i);
		}
	}
	kgsl_regwrite(pDevice, 0x3072, selection);

	return enable;
}

static int gator_events_a3xx_start(void)
{
	bool enable = false;
	unsigned int enable_vbif = 0;

	mutex_lock(&pDevice->mutex);
	kgsl_regwrite(pDevice, 0x80, 0);
	kgsl_regwrite(pDevice, 0x3070, 0);

	enable =  enable_counters(rbbm_counters, RBBM_COUNTERS)
			| enable_counters(hlsq_counters, HLSQ_COUNTERS)
			| enable_counters(tse_counters,  TSE_COUNTERS)
			| enable_counters(uche_counters, UCHE_COUNTERS)
			| enable_counters(tp_counters,   TP_COUNTERS)
			| enable_counters(sp_counters,   SP_COUNTERS);

	enable_vbif = enable_counters_vbif();

	if (enable)
	{
		kgsl_regwrite(pDevice, 0x80, 1);
	}
	if (enable_vbif)
	{
		kgsl_regwrite(pDevice, 0x3070, enable_vbif);
	}
	mutex_unlock(&pDevice->mutex);

	return 0;
}

static void gator_events_a3xx_stop(void)
{
	mutex_lock(&pDevice->mutex);
	kgsl_regwrite(pDevice, 0x80, 0);
	kgsl_regwrite(pDevice, 0x3070, 0);
	mutex_unlock(&pDevice->mutex);
}

static int read_registers(struct counter_info *counters,
		int count,
		unsigned int *buffer)
{
	int i;
	int len = 0;

	for (i = 0; i < count; i++)
	{
		if (counters[i].enabled)
		{
			unsigned int val = 0;

			if (mutex_is_locked(&pDevice->mutex) || !mutex_trylock(&pDevice->mutex))
				continue;
			if (pDevice->state != KGSL_STATE_ACTIVE)
			{
				mutex_unlock(&pDevice->mutex);
				continue;
			}
			kgsl_regread(pDevice, counters[i].read_offset, &val);
			mutex_unlock(&pDevice->mutex);

			if (counters[i].read_once)
			{
				buffer[len++] = counters[i].key;
				buffer[len++] = val - counters[i].last_val;
			}
			else
			{
				// Skip output for the first read - it doesn't always get reset
				counters[i].read_once = true;
			}
			counters[i].last_val = val;
		}
	}

	return len;
}

static int gator_events_a3xx_read(int **buffer)
{
	int len = 0;

	// Reading GPU, so only read from one CPU core?
	if (smp_processor_id())
		return 0;

	if (!mutex_trylock(&sampling_mutex))
		return 0;

	len += read_registers(rbbm_counters, RBBM_COUNTERS, a3xx_buffer + len);
	len += read_registers(hlsq_counters, HLSQ_COUNTERS, a3xx_buffer + len);
	len += read_registers(tse_counters,  TSE_COUNTERS,  a3xx_buffer + len);
	len += read_registers(uche_counters, UCHE_COUNTERS, a3xx_buffer + len);
	len += read_registers(tp_counters,   TP_COUNTERS,   a3xx_buffer + len);
	len += read_registers(sp_counters,   SP_COUNTERS,   a3xx_buffer + len);
	len += read_registers(vbif_counters, VBIF_COUNTERS, a3xx_buffer + len);

	if (buffer)
		*buffer = a3xx_buffer;

	mutex_unlock(&sampling_mutex);
	return len;
}

static struct gator_interface gator_events_a3xx_interface = {
		.create_files = gator_events_a3xx_create_files,
		.start = gator_events_a3xx_start,
		.stop = gator_events_a3xx_stop,
		.read = gator_events_a3xx_read,
};

static void init_registers(struct counter_info *counters,
		int count,
		unsigned int read_offset_base,
		unsigned int select_offset_base)
{
	int i;
	for (i = 0; i < count; i++)
	{
		counters[i].enabled = 0;
		counters[i].key = gator_events_get_key();
		counters[i].read_offset = read_offset_base + 2 * i;
		counters[i].select_offset = select_offset_base + i;
	}
}

int __init gator_events_a3xx_init(void)
{
	mutex_init(&sampling_mutex);
	pDevice = kgsl_get_device(0);

	init_registers(rbbm_counters, RBBM_COUNTERS, 0x92, 0x086);
	init_registers(hlsq_counters, HLSQ_COUNTERS, 0xa2, 0xe00);
	init_registers(tse_counters,  TSE_COUNTERS,  0xb2, 0xc88);
	init_registers(uche_counters, UCHE_COUNTERS, 0xba, 0xe84);
	init_registers(tp_counters,   TP_COUNTERS,   0xc6, 0xf04);
	init_registers(sp_counters,   SP_COUNTERS,   0xd2, 0xec4);
	init_registers(vbif_counters, VBIF_COUNTERS, 0x3073, 0x3072);

	return gator_events_install(&gator_events_a3xx_interface);
}
gator_events_init(gator_events_a3xx_init);
