/**
 * Copyright (c) 2012, The Linux Foundation. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 and
 * only version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 **/

#include <linux/init.h>
#include <linux/io.h>
#include <linux/ratelimit.h>
#include <linux/sched.h>
#include <linux/types.h>
#include <linux/unistd.h>

#include "gator.h"

#include "../gpu/msm/kgsl_device.h"

/* Fragment to add to events.xml:
  <category name="Adreno GPU Metrics" per_cpu="no">
    <event counter="adreno_gpu_freq" title="GPU Clock" name="Frequency Setting" display="average" average_selection="yes" units="Hz" description="Frequency setting of the GPU" />
    <event counter="adreno_vmalloc" title="GPU Memory" name="Kernel Memory" display="average" average_selection="yes" units="B" />
    <event counter="adreno_page_alloc" title="GPU Memory" name="Directly Allocated Pages" display="average" average_selection="yes" units="B" />
    <event counter="adreno_coherent" title="GPU Memory" name="Contiguous DMA Memory" display="average" average_selection="yes" units="B" />
    <event counter="adreno_mapped" title="GPU Memory" name="External Memory" display="average" average_selection="yes" units="B" />
  </category>
 */
enum AdrenoNamedCounters
{
	NAMED_COUNTER_GPU_FREQUENCY,
	NAMED_COUNTER_KGSL_VMALLOC,
	NAMED_COUNTER_KGSL_PAGE_ALLOC,
	NAMED_COUNTER_KGSL_COHERENT,
	NAMED_COUNTER_KGSL_MAPPED,

	NAMED_COUNTER_COUNT
};

static const char* counter_names[NAMED_COUNTER_COUNT] = {
		"adreno_gpu_freq",
		"adreno_vmalloc",
		"adreno_page_alloc",
		"adreno_coherent",
		"adreno_mapped",
};

static struct {
	unsigned long enabled;
	unsigned long key;
} adreno_named_counters[NAMED_COUNTER_COUNT];

static unsigned int adreno_buffer[NAMED_COUNTER_COUNT * 2];

static struct kgsl_device *pDevice;
extern struct kgsl_driver kgsl_driver;

static int gator_events_adreno_create_files(struct super_block *sb,
		struct dentry *root)
{
	int i;
	struct dentry *dir;

	for (i = 0; i < NAMED_COUNTER_COUNT; i++)
	{
		dir = gatorfs_mkdir(sb, root, counter_names[i]);
		if (WARN_ON(!dir))
			return -1;
		gatorfs_create_ulong(sb, dir, "enabled", &adreno_named_counters[i].enabled);
		gatorfs_create_ulong(sb, dir, "key", &adreno_named_counters[i].key);
	}

	return 0;
}

static int gator_events_adreno_start(void)
{
	// Nothing required here
	return 0;
}

static void gator_events_adreno_stop(void)
{
	// Nothing needed right now
}

static int gator_events_adreno_read(int **buffer)
{
	int i = 0;
	int len = 0;

	if (smp_processor_id())
		return 0;

	for (i = 0; i < NAMED_COUNTER_COUNT; i++)
	{
		if (adreno_named_counters[i].enabled)
		{
			adreno_buffer[len++] = adreno_named_counters[i].key;

			switch (i)
			{
			case NAMED_COUNTER_GPU_FREQUENCY:
				adreno_buffer[len++] = pDevice->pwrctrl.pwrlevels[pDevice->pwrctrl.active_pwrlevel].gpu_freq;
				break;
			case NAMED_COUNTER_KGSL_VMALLOC:
				adreno_buffer[len++] = kgsl_driver.stats.vmalloc;
				break;
			case NAMED_COUNTER_KGSL_PAGE_ALLOC:
				adreno_buffer[len++] = kgsl_driver.stats.page_alloc;
				break;
			case NAMED_COUNTER_KGSL_COHERENT:
				adreno_buffer[len++] = kgsl_driver.stats.coherent;
				break;
			case NAMED_COUNTER_KGSL_MAPPED:
				adreno_buffer[len++] = kgsl_driver.stats.mapped;
				break;
			}
		}
	}

	if (buffer)
		*buffer = adreno_buffer;

	return len;
}

static struct gator_interface gator_events_adreno_interface = {
		.create_files = gator_events_adreno_create_files,
		.start = gator_events_adreno_start,
		.stop = gator_events_adreno_stop,
		.read = gator_events_adreno_read,
};

int __init gator_events_adreno_init(void)
{
	int i;

	pDevice = kgsl_get_device(0);

	for (i = 0; i < NAMED_COUNTER_COUNT; i++)
	{
		adreno_named_counters[i].enabled = 0;
		adreno_named_counters[i].key = gator_events_get_key();
	}

	return gator_events_install(&gator_events_adreno_interface);
}
gator_events_init(gator_events_adreno_init);
