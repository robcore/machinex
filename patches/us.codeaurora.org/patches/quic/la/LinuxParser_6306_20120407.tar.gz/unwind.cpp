/* Copyright (c) 2011, Code Aurora Forum. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 and
 * only version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */


#include "linuxstructs.h"
#include "unwind.h"

struct unwind_idx *__start_unwind_idx;
struct unwind_idx *__stop_unwind_idx;

extern unsigned int page_offset;
extern unsigned int phys_offset;
extern FILE *outputpath;
extern int nosymbols;

extern struct unwind_idx *unwind_table;
extern struct unwind_idx *end_unwind_table;

#define dfprintf

int unwind_frame_generic(struct stackframe *frame)
{
		unsigned int high, low;
		unsigned int fp = frame->fp;

		dfprintf(outputpath, "unwind fram generic\n");

		/* only go to a higher address on the stack */
		low = frame->sp;
		unsigned int mask = ((unsigned int)(THREAD_SIZE)) - 1;

		high = (low + mask) & (~mask);

		/* check current frame pointer is within bounds */
		if (fp < (low + 12) || fp + 4 >= high)
			return -1;

		fstream *ebifile_fp = open_ebi(PHY((unsigned int)frame->fp));
		fstream *ebifile_sp = open_ebi(PHY((unsigned int)frame->sp));
		fstream *ebifile_pc = open_ebi(PHY((unsigned int)frame->pc));

		if(ebifile_fp == NULL) return -1;

		/* restore the registers from the stack frame */
		unsigned int fp_is_at;
		unsigned int sp_is_at;
		unsigned int pc_is_at;

		dfprintf(outputpath, "\nFPisAT: %x, SPisAT:%x, PCisAT:%x", fp_is_at, sp_is_at, pc_is_at);
		read_struct(&fp_is_at, 4, ebifile_fp, PHY(frame->fp - 12));
		read_struct(&sp_is_at, 4, ebifile_fp, PHY(frame->fp - 8));
		read_struct(&pc_is_at, 4, ebifile_fp, PHY(frame->fp - 4));

		dfprintf(outputpath, "\nFPisAT: %x, SPisAT:%x, PCisAT:%x", fp_is_at, sp_is_at, pc_is_at);

		frame->fp = fp_is_at;
		frame->sp = sp_is_at;
		frame->pc = pc_is_at;

		return 0;
}

void walk_stackframe_generic(struct stackframe *frame)
{
		while (1) {
			int ret, offset;

			char *symname = lookup(frame->pc, &offset);
			fprintf(outputpath, "[<%X>] %s+0x%x\n", frame->pc, symname, offset);

			ret = unwind_frame_generic(frame);
			if (ret < 0)
					break;
		}
}

void unwind_backtrace_generic(unsigned int sp, unsigned int fp, unsigned int pc)
{
	struct stackframe frame;

	frame.fp = fp;
	frame.pc = pc;
	frame.sp = sp;
	walk_stackframe_generic(&frame);
}

/* Convert a prel31 symbol to an absolute address */
unsigned int prel31_to_addr(unsigned int ptr)
{
	/* sign-extend to 32 bits */
	int value;
	read_struct(&value, 4, open_ebi(PHY(ptr)), PHY(ptr));
	int offset = (((int)value) << 1) >> 1;
	dfprintf(outputpath, "pre131 returning %x\n", ptr+(offset));
	return (ptr) + (offset);
}

/*
 * Binary search in the unwind index. The entries entries are
 * guaranteed to be sorted in ascending order by the linker.
 */
static struct unwind_idx *search_index(unsigned long addr,
					   struct unwind_idx *first,
					   struct unwind_idx *last)
{
	dfprintf(outputpath, "search_index(%08lx, %p, %p)\n", addr, first, last);

	if (addr < first->addr) {
		fprintf(outputpath, "unwind: Unknown symbol address %08lx\n", addr);
		return NULL;
	} else if (addr >= last->addr) {
		dfprintf(outputpath, "uhoh returning last unwind addr.\n");
		return last;
	}

	dfprintf(outputpath, "Binary search in the unwind table...\n");

	while (first < last - 1) {
		struct unwind_idx *mid = first + ((last - first + 1) >> 1);
		dfprintf(outputpath, "Jump: mid: %x\n", mid);
		fflush(stdout);
		if (addr < mid->addr)
			last = mid;
		else
			first = mid;
	}

	dfprintf(outputpath, "%s: first = %x\n", __FUNCTION__, first->addr);
	fflush(stdout);
	return first;
}

static struct unwind_idx *unwind_find_idx(unsigned long addr)
{
	struct unwind_idx *idx = NULL;
	unsigned long flags;

	dfprintf(outputpath, "unwind_find_idx(%08lx)\n", addr);
	dfprintf(outputpath, "Undinwd table: %x, end: %x\n", unwind_table->addr, end_unwind_table->addr);

	idx = search_index(addr, unwind_table,
				   end_unwind_table);

	dfprintf(outputpath, "%s: idx = %p\n", __FUNCTION__, idx);
	fflush(stdout);

	return idx;
}

static unsigned int unwind_get_byte(struct unwind_ctrl_block *ctrl)
{
	unsigned int ret, val;

	if (ctrl->entries <= 0) {
		fprintf(outputpath, "unwind: Corrupt unwind table\n");
		return 0;
	}

	read_struct(&val, 4, open_ebi(PHY(ctrl->insn)), PHY(ctrl->insn));
	ret = (val >> (ctrl->byte * 8)) & 0xff;

	if (ctrl->byte == 0) {
		ctrl->insn+=4;
		ctrl->entries--;
		ctrl->byte = 3;
	} else
		ctrl->byte--;

	return ret;
}

/*
 * Execute the current unwind instruction.
 */
static int unwind_exec_insn(struct unwind_ctrl_block *ctrl)
{
	unsigned int insn = unwind_get_byte(ctrl);

	dfprintf(outputpath, "%s: insn = %08x\n", __FUNCTION__, insn);
	fflush(stdout);

	if ((insn & 0xc0) == 0x00) {
		ctrl->vrs[SP] += ((insn & 0x3f) << 2) + 4;
		dfprintf(outputpath, "vrs[SP]=%x (%d)", ctrl->vrs[SP], __LINE__);
	}
	else if ((insn & 0xc0) == 0x40) {
		ctrl->vrs[SP] -= ((insn & 0x3f) << 2) + 4;
		dfprintf(outputpath, "vrs[SP]=%x (%d)", ctrl->vrs[SP], __LINE__);
	}
	else if ((insn & 0xf0) == 0x80) {
		unsigned int mask;
		unsigned int vsp = ctrl->vrs[SP];
		int load_sp, reg = 4;

		fstream *ebifile = open_ebi(PHY(vsp));

		if(!ebifile) return -URC_FAILURE;

		insn = (insn << 8) | unwind_get_byte(ctrl);
		mask = insn & 0x0fff;
		if (mask == 0) {
			fprintf(outputpath, "unwind: 'Refuse to unwind' instruction %04lx\n", insn);
			return -URC_FAILURE;
		}

		/* pop R4-R15 according to mask */
		load_sp = mask & (1 << (13 - 4));
		while (mask) {
			if (mask & 1) {
				read_struct(&ctrl->vrs[reg], 4, ebifile, PHY(vsp));
				vsp+=4;
			}
			mask >>= 1;
			reg++;
		}
		if (!load_sp)
			ctrl->vrs[SP] = vsp;

		dfprintf(outputpath, "vrs[SP]=%x (%d)", ctrl->vrs[SP], __LINE__);
	} else if ((insn & 0xf0) == 0x90 &&
		   (insn & 0x0d) != 0x0d) {
		ctrl->vrs[SP] = ctrl->vrs[insn & 0x0f];
		dfprintf(outputpath, "vrs[SP]=%x (%d)", ctrl->vrs[SP], __LINE__);
	}
	else if ((insn & 0xf0) == 0xa0) {
		unsigned int vsp = ctrl->vrs[SP];
		int reg;

		dfprintf(outputpath, "\nvsp = %x\n\n", vsp);
		fflush(stdout);

		fstream *ebifile = open_ebi(PHY((unsigned int)vsp));

		if(!ebifile) return -URC_FAILURE;

		/* pop R4-R[4+bbb] */
		for (reg = 4; reg <= 4 + (insn & 7); reg++) {
			read_struct(&ctrl->vrs[reg], 4, ebifile, PHY((unsigned int)vsp));
			dfprintf(outputpath, "[sui=%d] ctrl->vrs[reg]=%x\n", sizeof(unsigned int), ctrl->vrs[reg]);
			vsp+=4;
		}
		if (insn & 0x80) {
			read_struct(&ctrl->vrs[14], 4, ebifile, PHY((unsigned int)vsp));
			dfprintf(outputpath, "ctrl->vrs[14]=%x\n", ctrl->vrs[14]);
			vsp+=4;
		}
		ctrl->vrs[SP] = (unsigned long)vsp;
		dfprintf(outputpath, "vrs[SP]=%x (%d)", ctrl->vrs[SP], __LINE__);
	} else if (insn == 0xb0) {
		if (ctrl->vrs[PC] == 0)
			ctrl->vrs[PC] = ctrl->vrs[LR];
		/* no further processing */
		ctrl->entries = 0;
		dfprintf(outputpath, "vrs[PC]=%x (%d)", ctrl->vrs[PC], __LINE__);
	} else if (insn == 0xb1) {
		unsigned int mask = unwind_get_byte(ctrl);
		unsigned int vsp = ctrl->vrs[SP];
		int reg = 0;

		fstream *ebifile = open_ebi(PHY(vsp));

		if(!ebifile) return -URC_FAILURE;

		if (mask == 0 || mask & 0xf0) {
			fprintf(outputpath, "unwind: Spare encoding %04lx\n",
				   (insn << 8) | mask);
			return -URC_FAILURE;
		}

		/* pop R0-R3 according to mask */
		while (mask) {
			if (mask & 1) {
				read_struct(&ctrl->vrs[reg], 4, ebifile, PHY(vsp));
				vsp+=4;
			}
			mask >>= 1;
			reg++;
		}
		ctrl->vrs[SP] = vsp;
		dfprintf(outputpath, "vrs[SP]=%x (%d)", ctrl->vrs[SP], __LINE__);
	} else if (insn == 0xb2) {
		unsigned long uleb128 = unwind_get_byte(ctrl);

		ctrl->vrs[SP] += 0x204 + (uleb128 << 2);
		dfprintf(outputpath, "vrs[SP]=%x (%d)", ctrl->vrs[SP], __LINE__);
	} else {
		fprintf(outputpath, "unwind: Unhandled instruction %02lx\n", insn);
		return -URC_FAILURE;
	}

	dfprintf(outputpath, "%s: fp = %08lx sp = %08lx lr = %08lx pc = %08lx\n", __FUNCTION__,
		ctrl->vrs[FP], ctrl->vrs[SP], ctrl->vrs[LR], ctrl->vrs[PC]);
	fflush(stdout);

	return URC_OK;
}

/*
 * Unwind a single frame starting with *sp for the symbol at *pc. It
 * updates the *pc and *sp with the new values.
 */
int unwind_frame(struct stackframe *frame)
{
	unsigned long high, low;
	struct unwind_idx *idx;
	struct unwind_ctrl_block ctrl;

	/* only go to a higher address on the stack */
	low = frame->sp;

	high = ((low + (unsigned long)(THREAD_SIZE - 1)) & ~((unsigned long)THREAD_SIZE - 1)) + THREAD_SIZE;

	dfprintf(outputpath, "%s(pc = %08lx lr = %08lx sp = %08lx)\n", __FUNCTION__,
	 frame->pc, frame->lr, frame->sp);

	if (!kernel_text_address(frame->pc))
		return -URC_FAILURE;

	dfprintf(outputpath, "\nframe->pc = %x\n", frame->pc);

	idx = unwind_find_idx(frame->pc);
	if (!idx) {
		fprintf(outputpath, "unwind: Index not found %08lx\n", frame->pc);
		return -URC_FAILURE;
	} else dfprintf(outputpath, "\nidx.addr = %x, idx.insn = %x", idx->addr, idx->insn);

	dfprintf(outputpath, "idx found\n");

	ctrl.vrs[FP] = frame->fp;
	ctrl.vrs[SP] = frame->sp;
	ctrl.vrs[LR] = frame->lr;
	ctrl.vrs[PC] = 0;

	if (idx->insn == 1) {
		dfprintf(outputpath, "returning here 0\n");
		/* can't unwind */
		return -URC_FAILURE;
	}
	else if ((idx->insn & 0x80000000) == 0) {
		/* prel31 to the unwind table */
		dfprintf(outputpath, "\nprel31'ing %x\n", idx->addr_idx+4);
		ctrl.insn = prel31_to_addr((idx->addr_idx+4));
	}
	else if ((idx->insn & 0xff000000) == 0x80000000)
		/* only personality routine 0 supported in the index */
		ctrl.insn = idx->addr_idx+4;
	else {
		fprintf(outputpath, "unwind: Unsupported personality routine %08lx in the index at %p\n",
			   idx->insn, idx);
		return -URC_FAILURE;
	}

	fflush(stdout);

	/* check the personality routine */

	unsigned int val;
	read_struct(&val, 4, open_ebi(PHY((unsigned int)ctrl.insn)), PHY((unsigned int)ctrl.insn));

	if ((val & 0xff000000) == 0x80000000) {
		ctrl.byte = 2;
		ctrl.entries = 1;
	} else if ((val & 0xff000000) == 0x81000000) {
		ctrl.byte = 1;
		ctrl.entries = 1 + ((val & 0x00ff0000) >> 16);
	} else {
		dfprintf(outputpath, "unwind: Unsupported personality routine %08lx at %p\n",
			   val, ctrl.insn);
		return -URC_FAILURE;
	}

	while (ctrl.entries > 0) {
		int urc = unwind_exec_insn(&ctrl);
		dfprintf(outputpath, "ctrl.vrs[SP] = %x\n", ctrl.vrs[SP]);
		if (urc < 0)
			return urc;
		if (ctrl.vrs[SP] < low || ctrl.vrs[SP] >= high)
			return -URC_FAILURE;
	}

	dfprintf(outputpath, "Exec'ing %x\n", val);
	fflush(stdout);

	if (ctrl.vrs[PC] == 0)
		ctrl.vrs[PC] = ctrl.vrs[LR];

	fflush(stdout);

	/* check for infinite loop */
	if (frame->pc == ctrl.vrs[PC])
		return -URC_FAILURE;

	frame->fp = ctrl.vrs[FP];
	frame->sp = ctrl.vrs[SP];
	frame->lr = ctrl.vrs[LR];
	frame->pc = ctrl.vrs[PC];

	return URC_OK;
}

void unwind_backtrace(unsigned int sp, unsigned int fp, unsigned int pc)
{
	struct stackframe frame;
	unsigned long current_sp;
	int offset = 0;

	if (nosymbols) {
			printf("Cannot walk the stack without symbols.\n");
			return;
	}

	/* task blocked in __switch_to */
	frame.fp = fp;
	frame.sp = sp;
	/*
	 * The function calling __switch_to cannot be a leaf function
	 * so LR is recovered from the stack.
	 */
	frame.lr = 0;
	frame.pc = pc;

	while (1) {
		int urc;
		unsigned long where = frame.pc;
		int offset = 0;

		char *symname = lookup(frame.pc, &offset);
		dfprintf(outputpath, "pc: %x, Vpc: %x, Ppc: %x\n", frame.pc, VIRT(frame.pc), PHY(frame.pc));
		fprintf(outputpath, "	[<%X>] %s+0x%x\n", frame.pc, symname, offset);

		urc = unwind_frame(&frame);
		if (urc < 0)
			break;
	}
}
