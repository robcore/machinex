/* Copyright (c) 2012-2013, The Linux Foundation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above
 *       copyright notice, this list of conditions and the following
 *       disclaimer in the documentation and/or other materials provided
 *       with the distribution.
 *     * Neither the name of The Linux Foundation nor the names of its
 *       contributors may be used to endorse or promote products derived
 *       from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "mm_jpeg_dbg.h"
#include "mm_jpeg.h"
#include <errno.h>


#define AWB_DEBUG_BUFF_SIZE (2 * 400)

#define LOWER(a)               ((a) & 0xFFFF)
#define UPPER(a)               (((a)>>16) & 0xFFFF)
#define CHANGE_ENDIAN_16(a)  ((0x00FF & ((a)>>8)) | (0xFF00 & ((a)<<8)))

#define AWB_START_POSITION ((uint16_t)0x4B4AU)
#define AWB_END_POSITION   ((uint16_t)0x4B4AU)

#define AF_START_POSITION ((uint16_t)0x4641U)
#define AF_MID_POSITION   ((uint16_t)0x4641U)
#define AF_END_POSITION   ((uint16_t)0x4641U)



/** addExifEntry:
 *
 *  Arguments:
 *   @exif_info : Exif info struct
 *   @p_session: job session
 *   @tagid   : exif tag ID
 *   @type    : data type
 *   @count   : number of data in uint of its type
 *   @data    : input data ptr
 *
 *  Retrun     : int32_t type of status
 *               0  -- success
 *              none-zero failure code
 *
 *  Description:
 *       Function to add an entry to exif data
 *
 **/
int32_t addExifEntry(QOMX_EXIF_INFO *p_exif_info, exif_tag_id_t tagid,
  exif_tag_type_t type, uint32_t count, void *data)
{
    int32_t rc = 0;
    int32_t numOfEntries = p_exif_info->numOfEntries;
    QEXIF_INFO_DATA *p_info_data = p_exif_info->exif_data;
    if(numOfEntries >= MAX_EXIF_TABLE_ENTRIES) {
        ALOGE("%s: Number of entries exceeded limit", __func__);
        return -1;
    }

    p_info_data[numOfEntries].tag_id = tagid;
    p_info_data[numOfEntries].tag_entry.type = type;
    p_info_data[numOfEntries].tag_entry.count = count;
    p_info_data[numOfEntries].tag_entry.copy = 1;
    switch (type) {
    case EXIF_BYTE: {
      if (count > 1) {
        uint8_t *values = (uint8_t *)malloc(count);
        if (values == NULL) {
          ALOGE("%s: No memory for byte array", __func__);
          rc = -1;
        } else {
          memcpy(values, data, count);
          p_info_data[numOfEntries].tag_entry.data._bytes = values;
        }
      } else {
        p_info_data[numOfEntries].tag_entry.data._byte = *(uint8_t *)data;
      }
    }
    break;
    case EXIF_ASCII: {
      char *str = NULL;
      str = (char *)malloc(count + 1);
      if (str == NULL) {
        ALOGE("%s: No memory for ascii string", __func__);
        rc = -1;
      } else {
        memset(str, 0, count + 1);
        memcpy(str, data, count);
        p_info_data[numOfEntries].tag_entry.data._ascii = str;
      }
    }
    break;
    case EXIF_SHORT: {
      if (count > 1) {
        uint16_t *values = (uint16_t *)malloc(count * sizeof(uint16_t));
        if (values == NULL) {
          ALOGE("%s: No memory for short array", __func__);
          rc = -1;
        } else {
          memcpy(values, data, count * sizeof(uint16_t));
          p_info_data[numOfEntries].tag_entry.data._shorts = values;
        }
      } else {
        p_info_data[numOfEntries].tag_entry.data._short = *(uint16_t *)data;
      }
    }
    break;
    case EXIF_LONG: {
      if (count > 1) {
        uint32_t *values = (uint32_t *)malloc(count * sizeof(uint32_t));
        if (values == NULL) {
          ALOGE("%s: No memory for long array", __func__);
          rc = -1;
        } else {
          memcpy(values, data, count * sizeof(uint32_t));
          p_info_data[numOfEntries].tag_entry.data._longs = values;
        }
      } else {
        p_info_data[numOfEntries].tag_entry.data._long = *(uint32_t *)data;
      }
    }
    break;
    case EXIF_RATIONAL: {
      if (count > 1) {
        rat_t *values = (rat_t *)malloc(count * sizeof(rat_t));
        if (values == NULL) {
          ALOGE("%s: No memory for rational array", __func__);
          rc = -1;
        } else {
          memcpy(values, data, count * sizeof(rat_t));
          p_info_data[numOfEntries].tag_entry.data._rats = values;
        }
      } else {
        p_info_data[numOfEntries].tag_entry.data._rat = *(rat_t *)data;
      }
    }
    break;
    case EXIF_UNDEFINED: {
      uint8_t *values = (uint8_t *)malloc(count);
      if (values == NULL) {
        ALOGE("%s: No memory for undefined array", __func__);
        rc = -1;
      } else {
        memcpy(values, data, count);
        p_info_data[numOfEntries].tag_entry.data._undefined = values;
      }
    }
    break;
    case EXIF_SLONG: {
      if (count > 1) {
        int32_t *values = (int32_t *)malloc(count * sizeof(int32_t));
        if (values == NULL) {
          ALOGE("%s: No memory for signed long array", __func__);
          rc = -1;
        } else {
          memcpy(values, data, count * sizeof(int32_t));
          p_info_data[numOfEntries].tag_entry.data._slongs = values;
        }
      } else {
        p_info_data[numOfEntries].tag_entry.data._slong = *(int32_t *)data;
      }
    }
    break;
    case EXIF_SRATIONAL: {
      if (count > 1) {
        srat_t *values = (srat_t *)malloc(count * sizeof(srat_t));
        if (values == NULL) {
          ALOGE("%s: No memory for signed rational array", __func__);
          rc = -1;
        } else {
          memcpy(values, data, count * sizeof(srat_t));
          p_info_data[numOfEntries].tag_entry.data._srats = values;
        }
      } else {
        p_info_data[numOfEntries].tag_entry.data._srat = *(srat_t *)data;
      }
    }
    break;
    }

    // Increase number of entries
    p_exif_info->numOfEntries++;
    return rc;
}


int32_t releaseExifEntry(QOMX_EXIF_INFO *p_exif_info)
{
  uint32_t i = 0;
  for (i = 0; i < p_exif_info->numOfEntries; i++) {
  switch (p_exif_info->exif_data[i].tag_entry.type) {
  case EXIF_BYTE: {
    if (p_exif_info->exif_data[i].tag_entry.count > 1 &&
      p_exif_info->exif_data[i].tag_entry.data._bytes != NULL) {
      free(p_exif_info->exif_data[i].tag_entry.data._bytes);
      p_exif_info->exif_data[i].tag_entry.data._bytes = NULL;
    }
  }
  break;
  case EXIF_ASCII: {
    if (p_exif_info->exif_data[i].tag_entry.data._ascii != NULL) {
      free(p_exif_info->exif_data[i].tag_entry.data._ascii);
      p_exif_info->exif_data[i].tag_entry.data._ascii = NULL;
    }
  }
  break;
  case EXIF_SHORT: {
    if (p_exif_info->exif_data[i].tag_entry.count > 1 &&
      p_exif_info->exif_data[i].tag_entry.data._shorts != NULL) {
      free(p_exif_info->exif_data[i].tag_entry.data._shorts);
      p_exif_info->exif_data[i].tag_entry.data._shorts = NULL;
    }
  }
  break;
  case EXIF_LONG: {
    if (p_exif_info->exif_data[i].tag_entry.count > 1 &&
      p_exif_info->exif_data[i].tag_entry.data._longs != NULL) {
      free(p_exif_info->exif_data[i].tag_entry.data._longs);
      p_exif_info->exif_data[i].tag_entry.data._longs = NULL;
    }
  }
  break;
  case EXIF_RATIONAL: {
    if (p_exif_info->exif_data[i].tag_entry.count > 1 &&
      p_exif_info->exif_data[i].tag_entry.data._rats != NULL) {
      free(p_exif_info->exif_data[i].tag_entry.data._rats);
      p_exif_info->exif_data[i].tag_entry.data._rats = NULL;
    }
  }
  break;
  case EXIF_UNDEFINED: {
    if (p_exif_info->exif_data[i].tag_entry.data._undefined != NULL) {
      free(p_exif_info->exif_data[i].tag_entry.data._undefined);
      p_exif_info->exif_data[i].tag_entry.data._undefined = NULL;
    }
  }
  break;
  case EXIF_SLONG: {
    if (p_exif_info->exif_data[i].tag_entry.count > 1 &&
      p_exif_info->exif_data[i].tag_entry.data._slongs != NULL) {
      free(p_exif_info->exif_data[i].tag_entry.data._slongs);
      p_exif_info->exif_data[i].tag_entry.data._slongs = NULL;
    }
  }
  break;
  case EXIF_SRATIONAL: {
    if (p_exif_info->exif_data[i].tag_entry.count > 1 &&
      p_exif_info->exif_data[i].tag_entry.data._srats != NULL) {
      free(p_exif_info->exif_data[i].tag_entry.data._srats);
      p_exif_info->exif_data[i].tag_entry.data._srats = NULL;
    }
  }
  break;
  }

  } /*end of switch*/

  return 0;
}


/** processAAAInfo:
 *
 *  Arguments:
 *   @fd_data : ptr to face detection result struct
 *   @exif_info: Exif info struct
 *
 *  Return     : int32_t type of status
 *               NO_ERROR  -- success
 *              none-zero failure code
 *
 *  Description:
 *       process awb debug info
 *
 **/
int32_t processAAAInfo(cam_aaa_info_t *fd_data, QOMX_EXIF_INFO *exif_info)
{
  int rc = 0;
  uint16_t awb_debug_buff[AWB_DEBUG_BUFF_SIZE];
  memset(awb_debug_buff, 0xA4, sizeof(awb_debug_buff));

  cam_awb_gain_t *adj_gain       = &fd_data->awb_info.awb_adjust_gain;
  cam_awb_gain_t *preset_gain    = &fd_data->awb_info.preset_gain;
  cam_awb_exp_gains_t *exp_gains = &fd_data->awb_info.exp_gains;
  cam_awb_gain_t *gain_bef_lpf   = &fd_data->awb_info.rgb_gain_before_lpf;
  cam_awb_gain_t *awb_gains      = &fd_data->awb_info.awb_gains;
  cam_af_info_t  *afi            = &fd_data->af_info;

  uint16_t *awbBuf =  awb_debug_buff;
  uint16_t *afBuf = &awb_debug_buff[2*49 + 2*255 + 66];
  int index = 0;
  int i = 0;


  awbBuf[0] = CHANGE_ENDIAN_16(AWB_START_POSITION); //AWB log start position
  awbBuf[1] = CHANGE_ENDIAN_16(AWB_START_POSITION); //AWB log start position
  awbBuf[2] = CHANGE_ENDIAN_16(fd_data->awb_info.tuning_version);
  awbBuf[3] = CHANGE_ENDIAN_16(LOWER(adj_gain->sfR));
  awbBuf[4] = CHANGE_ENDIAN_16(UPPER(adj_gain->sfR));
  awbBuf[5] = CHANGE_ENDIAN_16(LOWER(adj_gain->sfB));
  awbBuf[6] = CHANGE_ENDIAN_16(UPPER(adj_gain->sfB));

  awbBuf[7] = 0; //Reserved
  awbBuf[8] = 0; //Reserved
  awbBuf[9] = 0; //Reserved
  awbBuf[10] = 0; //Reserved

  awbBuf[11] = CHANGE_ENDIAN_16(LOWER(preset_gain->sfR));
  awbBuf[12] = CHANGE_ENDIAN_16(UPPER(preset_gain->sfR));
  awbBuf[13] = CHANGE_ENDIAN_16(LOWER(preset_gain->sfG));
  awbBuf[14] = CHANGE_ENDIAN_16(UPPER(preset_gain->sfG));
  awbBuf[15] = CHANGE_ENDIAN_16(LOWER(preset_gain->sfB));
  awbBuf[16] = CHANGE_ENDIAN_16(UPPER(preset_gain->sfB));

  awbBuf[17] = 0; //Reserved
  awbBuf[18] = 0; //Reserved

  awbBuf[19] = CHANGE_ENDIAN_16(LOWER(exp_gains->sfTv));
  awbBuf[20] = CHANGE_ENDIAN_16(UPPER(exp_gains->sfTv));
  awbBuf[21] = CHANGE_ENDIAN_16(LOWER(exp_gains->sfSv));
  awbBuf[22] = CHANGE_ENDIAN_16(UPPER(exp_gains->sfSv));
  awbBuf[23] = CHANGE_ENDIAN_16(LOWER(exp_gains->sfBv));
  awbBuf[24] = CHANGE_ENDIAN_16(UPPER(exp_gains->sfBv));

  awbBuf[25] = CHANGE_ENDIAN_16(LOWER(fd_data->awb_info.color_temp));
  awbBuf[26] = CHANGE_ENDIAN_16(UPPER(fd_data->awb_info.color_temp));
  awbBuf[27] = 0; //Reserved
  awbBuf[28] = 0; //Reserved

  awbBuf[29] = CHANGE_ENDIAN_16(LOWER(gain_bef_lpf->sfR));
  awbBuf[30] = CHANGE_ENDIAN_16(UPPER(gain_bef_lpf->sfR));
  awbBuf[31] = CHANGE_ENDIAN_16(LOWER(gain_bef_lpf->sfG));
  awbBuf[32] = CHANGE_ENDIAN_16(UPPER(gain_bef_lpf->sfG));
  awbBuf[33] = CHANGE_ENDIAN_16(LOWER(gain_bef_lpf->sfB));
  awbBuf[34] = CHANGE_ENDIAN_16(UPPER(gain_bef_lpf->sfB));

  awbBuf[35] = CHANGE_ENDIAN_16(LOWER(awb_gains->sfR));
  awbBuf[36] = CHANGE_ENDIAN_16(UPPER(awb_gains->sfR));
  awbBuf[37] = CHANGE_ENDIAN_16(LOWER(awb_gains->sfG));
  awbBuf[38] = CHANGE_ENDIAN_16(UPPER(awb_gains->sfG));
  awbBuf[39] = CHANGE_ENDIAN_16(LOWER(awb_gains->sfB));
  awbBuf[40] = CHANGE_ENDIAN_16(UPPER(awb_gains->sfB));
  //CCM
  for (i=0 ;i<9; i++) {
      awbBuf[2*i + 41] =
          CHANGE_ENDIAN_16(LOWER(fd_data->awb_info.CCMatrix[i]));
      awbBuf[2*i + 42] =
          CHANGE_ENDIAN_16(UPPER(fd_data->awb_info.CCMatrix[i]));
  }

  //Grouping list
  awbBuf[2*8 + 43] = awbBuf[2*8 + 44] =
      CHANGE_ENDIAN_16(AWB_START_POSITION); // Indicator.

  for (i=0 ;i<256; i++){
      awbBuf[2*i + 2*8 + 45] =
          CHANGE_ENDIAN_16(LOWER(fd_data->awb_info.group_category[i]));
      awbBuf[2*i + 2*8 + 46] =
          CHANGE_ENDIAN_16(UPPER(fd_data->awb_info.group_category[i]));
  }

  //Status Info.
  awbBuf[2*255 + 63] = awbBuf[2*255 + 64] =
      CHANGE_ENDIAN_16(AWB_START_POSITION); // Indicator.

  for (i=0 ;i<49; i++){
      awbBuf[2*i + 2*255 + 65] =
          CHANGE_ENDIAN_16(LOWER(fd_data->awb_info.status_info[i]));
      awbBuf[2*i + 2*255 + 66] =
          CHANGE_ENDIAN_16(UPPER(fd_data->awb_info.status_info[i]));
  }


  awbBuf[2*48 + 2 * 255 + 67] =
      CHANGE_ENDIAN_16(AWB_END_POSITION); //AWB end log


  // AF START
  afBuf[0] = CHANGE_ENDIAN_16(LOWER(afi->af_version));
  afBuf[1] = CHANGE_ENDIAN_16(UPPER(afi->af_version));
  afBuf[2] = CHANGE_ENDIAN_16(AF_START_POSITION);
  afBuf[3] = CHANGE_ENDIAN_16(AF_START_POSITION);

  for (i=0 ; i < AF_MAX_EDGE_PROFILE_SIZE; i++) {
      afBuf[3 * i + 4] = CHANGE_ENDIAN_16(afi->lens_position[i]);
      afBuf[3 * i + 5] = CHANGE_ENDIAN_16(LOWER(afi->focus_value[i]));
      afBuf[3 * i + 6] = CHANGE_ENDIAN_16(UPPER(afi->focus_value[i]));
  }

  index = 3 * AF_MAX_EDGE_PROFILE_SIZE - 1;

  afBuf[index + 7] = CHANGE_ENDIAN_16(AF_MID_POSITION);
  afBuf[index + 8] = CHANGE_ENDIAN_16(AF_MID_POSITION);
  afBuf[index + 9] = CHANGE_ENDIAN_16 (afi->af_mode);
  afBuf[index + 10] = CHANGE_ENDIAN_16(afi->pan_pos);
  afBuf[index + 11] = CHANGE_ENDIAN_16(afi->af_status);
  afBuf[index + 12] = CHANGE_ENDIAN_16(afi->current_pos);
  afBuf[index + 13] = CHANGE_ENDIAN_16(afi->af_time);
  afBuf[index + 14] = CHANGE_ENDIAN_16(AF_END_POSITION);
  afBuf[index + 15] = CHANGE_ENDIAN_16(AF_END_POSITION);
  afBuf[index + 16] = CHANGE_ENDIAN_16(afi->af_driver_id);

  // AF END

  //Add to exif data
  rc = addExifEntry(exif_info, EXIFTAGID_EXIF_USER_COMMENT, EXIF_BYTE,
    sizeof(awb_debug_buff), awb_debug_buff);
  if (rc) {
    ALOGE("%s:%d]: Error adding Exif Entry", __func__, __LINE__);
  }
  return rc;
}
