/*--------------------------------------------------------------------------
Copyright (c) 2010, Code Aurora Forum. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of Code Aurora nor
      the names of its contributors may be used to endorse or promote
      products derived from this software without specific prior written
      permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NON-INFRINGEMENT ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
--------------------------------------------------------------------------*/

#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "SineSource.h"

#include <binder/IServiceManager.h>
#include <binder/ProcessState.h>
#include <media/IMediaPlayerService.h>
#include <media/stagefright/MediaDebug.h>
#include <media/stagefright/MediaDefs.h>
#include <media/stagefright/OMXClient.h>
//#include <media/stagefright/OMXCodec.h>
#include <media/IOMX.h>
#include <binder/MemoryDealer.h>
#include <OMX_Component.h>//needed to include this....

using namespace android;

FILE *inputBufferFile; //file pointer to open the file for inputfile;
FILE *outputBufferFile; //file pointer to open the file for inputfile;

namespace android {
  struct QCOMXCodecObserver : public BnOMXObserver	{
    public:
      QCOMXCodecObserver() {
        printf("In QCOMXCodecObserver()\n");
      };

      virtual void onMessage(const omx_message &msg);
      virtual void registerBuffers(const sp<IMemoryHeap> &mem) {
        //do nothing
      };

    protected:
      virtual ~QCOMXCodecObserver()	{
        printf("In ~QCOMXCodecObserver()\n");
      }
    private:
      QCOMXCodecObserver(const QCOMXCodecObserver &);
      QCOMXCodecObserver &operator=(const QCOMXCodecObserver &);
  };
};

///////////////////////////////////
//now Initialize the component
struct BufferInfo {
  IOMX::buffer_id mBuffer;
  bool mOwnedByComponent;
  sp<IMemory> mMem;
  size_t mSize;
  void *mData;
  MediaBuffer *mMediaBuffer;
};

//number of ports in the component
const int ktotalNoOfPorts = 2;

//vector to hold the number of buffers
Vector<BufferInfo> portBuffers[ktotalNoOfPorts];

//define the buffer index
enum {
  INPUT_BUFFER_INDEX = 0,
  OUTPUT_BUFFER_INDEX
};

//define the allocation type
enum {
  ALLOCATE_BUFFER = 0,
  USE_BUFFER
};

#define record_height 144
#define record_width  176

//define the buffer usage model for ports
int portBufferUsageModel[ktotalNoOfPorts] = {USE_BUFFER, USE_BUFFER};

IOMX::node_id node = 0; // node which will be return when call the allocateNode
sp<IOMX> omx;

template<class T>
static void InitOMXParams(T *params) {
  params->nSize = sizeof(T);
  params->nVersion.s.nVersionMajor = 1;
  params->nVersion.s.nVersionMinor = 0;
  params->nVersion.s.nRevision = 0;
  params->nVersion.s.nStep = 0;
}


static int timeStampLfile = 0;
static int Read_Yuv_Samples(BufferInfo *info)
{
  int sizeToRead = record_height * record_width * 3/2;
  info->mSize = fread(info->mData, 1, sizeToRead,inputBufferFile);
  if(!info->mSize )
  {
    printf("Bytes read Zero \n");
    return 0;
  }

  timeStampLfile += 33;

  printf("mBuffer %x, mData %p mSize - %d\n", info->mBuffer, info->mData, info->mSize);
  return info->mSize;
}


void QCOMXCodecObserver::onMessage(const omx_message &msg)
{
  printf("OnMessage \n");
  switch(msg.type) {
    case omx_message::EVENT:
      printf("event %d, data1 %ld, data2 %ld \n", msg.u.event_data.event, msg.u.event_data.data1, msg.u.event_data.data2);
      break;
    case omx_message::EMPTY_BUFFER_DONE:
      printf("buffer %p\n", msg.u.buffer_data);
      {
        IOMX::buffer_id buffer = msg.u.extended_buffer_data.buffer;
        Vector<BufferInfo> *buffers = &portBuffers[INPUT_BUFFER_INDEX];
        size_t i = 0;
        while (i < buffers->size() && (*buffers)[i].mBuffer != buffer) {
          ++i;
        }

        CHECK(i < buffers->size());
        if (!(*buffers)[i].mOwnedByComponent) {
          LOGW("We already own input buffer %p, yet received "
              "an EMPTY_BUFFER_DONE.", buffer);
        }

        buffers->editItemAt(i).mOwnedByComponent = false;

        int size = Read_Yuv_Samples(&buffers->editItemAt(i));
        status_t err = omx->emptyBuffer(
            node, (*buffers)[i].mBuffer, 0, size,
            0, timeStampLfile);

        if (err != OK) {
          printf("emptyBuffer failed w/ error 0x%08x \n", err);
          return;
        }
        buffers->editItemAt(i).mOwnedByComponent = true;
      }
      break;
    case omx_message::FILL_BUFFER_DONE:

      {
        IOMX::buffer_id buffer = msg.u.extended_buffer_data.buffer;
        Vector<BufferInfo> *buffers = &portBuffers[OUTPUT_BUFFER_INDEX];
        size_t i = 0;
        while (i < buffers->size() && (*buffers)[i].mBuffer != buffer) {
          ++i;
        }
        CHECK(i < buffers->size());
        BufferInfo *info = &buffers->editItemAt(i);

        printf("Inside FBD - buffer %p :range_offset %ld :range_length %ld :flags %ld \
            :timestamp %lld :platform_private %p :data_ptr %p info->mSize %d\n", \
            msg.u.extended_buffer_data.buffer, msg.u.extended_buffer_data.range_offset, msg.u.extended_buffer_data.range_length, msg.u.extended_buffer_data.flags, \
            msg.u.extended_buffer_data.timestamp, msg.u.extended_buffer_data.platform_private, msg.u.extended_buffer_data.data_ptr, info->mSize);

        if(NULL == outputBufferFile)
        {
          printf("Handle is not there \n");
          exit(0);
        }

        printf("Before writing \n");
        size_t temp = fwrite(info->mData, 1, msg.u.extended_buffer_data.range_length, outputBufferFile);
        printf("After writing \n");

        buffers->editItemAt(i).mOwnedByComponent = false;
        status_t err = omx->fillBuffer(node, buffer);
        if (err != OK) {
          printf("fillBuffer failed w/ error 0x%08x \n", err);
          return;
        }
        (buffers->editItemAt(i)).mOwnedByComponent = true;

      }
      break;
    default:
      printf("coming in default\n");
  }
};


int main(int argc, char *argv[]) {
  android::ProcessState::self()->startThreadPool();
  sp<IServiceManager> sm = defaultServiceManager();
  sp<IBinder> binder = sm->getService(String16("media.player"));
  sp<IMediaPlayerService> service = interface_cast<IMediaPlayerService>(binder);
  CHECK(service.get() != NULL);
  omx = service->getOMX();
  CHECK(omx.get() != NULL);
  int ret=0;
  List<IOMX::ComponentInfo> list; // list of componentName
  List<IOMX::ComponentInfo>::iterator it; // iterator to list through


  omx->listNodes(&list);
  for ( it = list.begin(); it != list.end(); ++it) {
    printf("%s\n",(*it).mName.string());
    if( 0 == strcmp("OMX.qcom.video.encoder.avc", (*it).mName.string() ))	{
      printf("Got the component\n");
      ret=1;
      break;
    }
    else {
      printf("Searching\n");
      //exit(0);
    }
  }
  CHECK_EQ(1, 1);

  /////////////////////////////////
  ///
  printf("Attempting to allocate OMX node '%s' \n", (*it).mName.string());
  sleep(10);
  sp<QCOMXCodecObserver> observer = new QCOMXCodecObserver;
  if(observer == NULL) {
    printf("Failed to create a observer object\n");
  }

  status_t err = omx->allocateNode((*it).mName.string(), observer, &node);
  CHECK_EQ(err, OK);
  printf("Successfully allocated OMX node '%s' \n", (*it).mName.string());

  sleep(10);
  //{
  /////////////////////////////////
  ////// Preparing the component
  /////////////////////////////////

  OMX_PARAM_PORTDEFINITIONTYPE def;
  InitOMXParams(&def);
  def.nPortIndex = 0;
  err = omx->getParameter(node, OMX_IndexParamPortDefinition, &def, sizeof(def));
  CHECK_EQ(err, OK);
  printf("Successfully got port definition parameter \n");

  //set the height and width
  def.format.video.nFrameHeight = record_height;
  def.format.video.nFrameWidth = record_width;

  err = omx->setParameter(node, OMX_IndexParamPortDefinition, &def, sizeof(def));
  CHECK_EQ(err, OK);
  printf("Successfully set port definition parameter \n");

  /////////////////////////////////
  ///
  def.nPortIndex = 1;
  err = omx->getParameter(node, OMX_IndexParamPortDefinition, &def, sizeof(def));
  CHECK_EQ(err, OK);
  printf("Successfully got port definition parameter \n");

  //tbd: def.format.video.nFrameWidth = m_sProfile.nFrameWidth;
  //tbd: def.format.video.nFrameHeight = m_sProfile.nFrameHeight;
  //tbd: def.format.video.nBitrate = m_sProfile.nBitrate;
  //tbd: def.format.video.xFramerate = m_sProfile.nFramerate << 16;

  err = omx->setParameter(node, OMX_IndexParamPortDefinition, &def, sizeof(def));
  CHECK_EQ(err, OK);
  printf("Successfully set port definition parameter \n");

  /////////////////////////////////
  ///
  printf("printing the values of the OMX_PARAM_PORTDEFINITION structure\n");
  printf("nSize member is %ld\n",def.nSize);
  printf("nPortIndex member is %ld\n",def.nPortIndex);
  printf("nBufferCountActual member is %ld\n",def.nBufferCountActual);
  printf("nBufferCountMin member is %ld\n",def.nBufferCountMin);
  printf("nBufferSize member is %ld\n",def.nBufferSize);
  printf("nBufferAlignment member is %ld\n",def.nBufferAlignment);
  printf("bEnabled member is %d\n",def.bEnabled);
  printf("bPopulated member is %d\n",def.bPopulated);
  printf("bBuffersContiguous member is %d\n",def.bBuffersContiguous);
  printf("nVersion  member is %ld\n",def.nVersion.nVersion);
  printf("eDir member is %d\n",def.eDir);
  printf("eDomain member is %d\n",def.eDomain);


  //tbd: color format
  //}

  //{

  //tbd: get and set the profile / level / codec specific data
  //OMX_VIDEO_PARAM_PROFILELEVELTYPE profileLevel; // OMX_IndexParamVideoProfileLevelCurrent
  //profileLevel.eProfile = 1; //OMX_VIDEO_AVCProfileBaseline;
  //profileLevel.eLevel =  3; //eLevel;
  //err = omx->setParameter(node, OMX_IndexParamVideoProfileLevelCurrent, &profileLevel, sizeof(profileLevel));

  //CHECK_EQ(err, OK);
  //printf("Successfully set the profile and level \n");

  //err = omx->getParameter(node, OMX_IndexParamVideoProfileLevelCurrent, &profileLevel, sizeof(profileLevel));
  //CHECK_EQ(err, OK);
  //printf("Successfully got the profile and level \n");
  //printf("Profile = %d level = %d\n",profileLevel.eProfile,profileLevel.eLevel);



  sp<MemoryDealer> mDealer[ktotalNoOfPorts];

  err = omx->sendCommand(node, OMX_CommandStateSet, OMX_StateIdle);
  CHECK_EQ(err, OK);
  printf("Moving to Idle State \n");

  for(int iPortIndex =0; iPortIndex < ktotalNoOfPorts; iPortIndex++ ) {
    OMX_PARAM_PORTDEFINITIONTYPE def;
    def.nPortIndex = iPortIndex;

    err = omx->getParameter(node, OMX_IndexParamPortDefinition, &def, sizeof(def));
    CHECK_EQ(err, OK);
    printf("Successfully got port definition parameter \n");

    size_t totalSize = def.nBufferCountActual * def.nBufferSize;
    mDealer[def.nPortIndex] = new MemoryDealer(totalSize, "QCOMXWrapper");

    for(int iCnt = 0;iCnt < def.nBufferCountActual; iCnt++) {
      BufferInfo info;
      info.mData = NULL;
      info.mSize = def.nBufferSize;
      IOMX::buffer_id buffer;

      sp<IMemory> mem = mDealer[def.nPortIndex]->allocate(def.nBufferSize);
      CHECK(mem.get() != NULL);

      if(USE_BUFFER == portBufferUsageModel[def.nPortIndex]) {
        err = omx->useBuffer(node, def.nPortIndex, mem, &buffer);
        printf("in use buffer def.nPortIndex - %d, iCnt - %d \n", def.nPortIndex, iCnt);
      }
      else if( ALLOCATE_BUFFER == portBufferUsageModel[def.nPortIndex]) {
        mem.clear();
        err = omx->allocateBuffer(
            node, def.nPortIndex, def.nBufferSize, &buffer,
            &info.mData);
        printf("buffer %p, mBuffer %p, info.mData %p\n", buffer, info.mBuffer, info.mData);
      }

      if (err != OK) {
        printf("Buffer allocation failed\n");
        return err;
      }
      printf("Successfully Allocate / use buufer on port no %d, buffer no %d\n", def.nPortIndex, iCnt);

      //assign the buffer to mData which is allocated locally and
      //uses as use buffer
      if (mem != NULL) {
        info.mData = mem->pointer();
        printf("info.mData %p\n", info.mData);
      }

      info.mBuffer = buffer;
      info.mOwnedByComponent = false;
      info.mMem = mem;
      info.mMediaBuffer = NULL;

      portBuffers[def.nPortIndex].push(info);

    }

  }
  sleep(20);
  printf("Moved to Idle \n");
  //} //end of initialization

  /////////////////////////////////
  /////Start Decoding
  //{
  err = omx->sendCommand(node, OMX_CommandStateSet, OMX_StateExecuting);
  CHECK_EQ(err, OK);
  printf("Moving to Executing State \n");

  inputBufferFile = fopen("/data/qcif.yuv", "rb");
  if(inputBufferFile == NULL) {
    printf("Failed to open the file\n");
  }
  outputBufferFile = fopen ("/data/output.264", "ab");
  if(outputBufferFile == NULL) {
    printf("Failed to open the file \n");
  }

  printf("------------- Opened the file ------------------------\n");
  sleep(20);
  printf("Moved to Executing \n");

  OMX_VIDEO_CONFIG_BITRATETYPE bitrate;
  bitrate.nPortIndex = OUTPUT_BUFFER_INDEX;
  bitrate.nEncodeBitrate = 64000;
  err = omx->setConfig(node, OMX_IndexConfigVideoBitrate, &bitrate, sizeof(bitrate));

  CHECK_EQ(err, OK);

  printf("After SetConfig \n");

  Vector<BufferInfo> *buffers = &portBuffers[OUTPUT_BUFFER_INDEX];
  for (size_t i = 0; i < buffers->size(); ++i) {
    if ((*buffers)[i].mOwnedByComponent == false) {
      printf("mBuffer %x mData %x\n", (*buffers)[i].mBuffer, (*buffers)[i].mData);
      status_t err = omx->fillBuffer(node, (*buffers)[i].mBuffer);
      if (err != OK) {
        printf("fillBuffer failed w/ error 0x%08x \n", err);
        return 0;
      }
      (buffers->editItemAt(i)).mOwnedByComponent = true;
    }
  }

  printf("Fill buffer is success\n");


  Vector<BufferInfo> *buffers1 = &portBuffers[INPUT_BUFFER_INDEX];
  for (size_t i = 0; i < buffers1->size(); ++i) {
    if ((*buffers1)[i].mOwnedByComponent == false) {

      int size = Read_Yuv_Samples(&buffers1->editItemAt(i));
      err = omx->emptyBuffer(
          node, (*buffers1)[i].mBuffer, 0, size,
          0, timeStampLfile);

      if (err != OK) {
        printf("emptyBuffer failed w/ error 0x%08x \n", err);
        return 0;
      }
      (buffers1->editItemAt(i)).mOwnedByComponent = true;
    }
  }
  //}

  sleep(1000);
  fclose(inputBufferFile);
  fclose(outputBufferFile);
  omx->freeNode(node);
  return 0;
}
