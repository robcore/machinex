/* Copyright (c) 2011, Code Aurora Forum. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 and
 * only version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

// wdog-get-regs.cpp : Defines the entry point for the console application.
//

#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <string>

#define lw_strtoul strtoul
#include <cstring>
#include <cstdlib>
#include <sys/stat.h>
#include "unwind.h"

#include "linuxstructs.h"
#include "unwind.h"

using namespace std;
#define MAX_STACK_WALKBACK 128
#define MAX_PROCESSES 400

#define IMEM_DEBUG_LOC 0x658
void (*arm_unwind_backtrace)(unsigned int, unsigned int, unsigned int)
	= unwind_backtrace;

typedef unsigned int uint32;

char nmpath[] = "arm-eabi-nm";
char gdbpath[] = "arm-eabi-gdb";
char gdbcmds[] = "cmds.txt";

uint32 current_c0; 
uint32 current_c1;
uint32 ebi_start;
unsigned int chip = -1;

char *ebi1cs1 = NULL, *ebics0 = NULL;
char *imem_c = NULL;

#define BM(msb, lsb)    (((((unsigned int)-1) << (31-msb)) >> (31-msb+lsb)) << lsb)
#define BVALSEL(msb, lsb, val)     ((val & BM(msb,lsb)) >> lsb)

static int offset_tasks, offset_comm, offset_stack,
	offset_thread_group, offset_pid, offset_state, offset_exit_state;;
char vmlinux_cmd[1024];
char vmlinuxpath[1024], ebics0_path[1024], ebi1cs1_path[1024];

unsigned int rev_lookup(const char *symname, unsigned int *size = NULL);
unsigned int get_real_offset(unsigned int offset);
fstream *open_ebi(unsigned int offset);
int open_ebi_ex(unsigned int offset, fstream **, unsigned int *begin);

unsigned int page_offset = PAGE_OFFSET;
unsigned int phys_offset = PHYS_OFFSET;
unsigned int linuxversion;

int more_than_512mb_ram = 0;
int one_ebi_file = 0;
struct unwind_idx *unwind_table;
struct unwind_idx *end_unwind_table;
int custom_phys_offset = 0;
unsigned int in_panic;
unsigned int imem_offset;

struct offset_rec {
	string sym;
	string mem;
	unsigned int offset;
	unsigned int szof;
};

struct range_struct {
	unsigned int begin;
	unsigned int end;
};

struct ramfile_s {
	fstream *f;
	struct range_struct range;
	struct stat *stFileInfo;			
	char ramfile_name[1024];
};

vector<ramfile_s> ramfiles;

struct hw_info {
	unsigned int hw_ascii_id;
	unsigned int hw_id;
	unsigned ebi_begin;
	unsigned int assumed_phys_offset;
	const char* ebi_start;
	const char* ebi_start_256mb;
	const char* ebi_start_512mb;
};

struct hw_info hw_ids[] = {
	{0x30363638, 8660, 0x40000000, 0x40200000, " 0x40000000 ",  " 0x50000000 ",  " 0x60000000 "},
	{0x30363938, 8960, 0x80000000, 0x80200000, " 0x80000000 ",  " 0x90000000 ",  " 0xA0000000 "},
};

#define TEMP_NAME "tempsdfwekrhewl2394728937.txt"
#define TEMP_NAME_RESULT "offsets79642340.txt"

map <string, int> offsetmap;

offset_rec offsets_required_2_6_35[] = {
	{"init_task", "comm", 0},	
	{"init_task", "pid", 0},
	{"init_task", "tasks", 0},
	{"init_task", "stack", 0},
	{"init_task", "thread_group", 0},
	{"init_task", "state", 0},
	{"init_task", "exit_state", 0},
	{"((struct workqueue_struct *)0x0)", "cpu_wq", 0},
	{"((struct workqueue_struct *)0x0)", "name", 0},
	{"((struct cpu_workqueue_struct *)0x0)", "worklist", 0},
	{"((struct cpu_workqueue_struct *)0x0)", "current_work", 0},
	{"((struct work_struct *)0x0)", "func", 0},
	{"((struct work_struct *)0x0)", "entry", 0},
	{"((struct cpu_workqueue_struct *)0x0)", "thread", 0},
	{"((struct irq_chip *)0x0)", "name", 0},
	{"irq_desc", "kstat_irqs", 0},
	{"((struct irqaction *)0x0)", "name", 0},
	{"irq_desc", "action", 0},
	{"irq_desc", "chip", 0},
	{"irq_desc", "irq_count", 0},
	{"irq_desc", "irq", 0},
	{"irq_desc", "handle_irq", 0},
	{"((struct vfsmount *)0x0)", "mnt_mountpoint", 0},
	{"((struct dentry *)0x0)", "d_subdirs", 0},
	{"((struct super_block *)0x0)", "s_root", 0},
	{"((struct vfsmount *)0x0)", "mnt_sb", 0},
	{"((struct delayed_work *)0x0)", "timer"},
	{"((struct timer_list *)0x0)", "expires"},
	{"sizeof(irq_desc[0])", "", 0, 1},
};

/*
	unsigned int per_cpu_offset_addr = rev_lookup("__per_cpu_offset");
	unsigned int global_cwq_sym_addr = rev_lookup("global_cwq");
	unsigned int idle_list_offset = get_offset_struct("((struct global_cwq *)0x0)", "idle_list");
	unsigned int busy_hash_offset = get_offset_struct("((struct global_cwq *)0x0)", "busy_hash");
	unsigned int scheduled_offset = get_offset_struct("((struct worker *)0x0)", "scheduled");
	unsigned int worker_task_offset = get_offset_struct("((struct worker *)0x0)", "task");
	unsigned int worker_entry_offset = get_offset_struct("((struct worker *)0x0)", "entry");
	unsigned int per_cpu_offset0, per_cpu_offset1, global_cwq_cpu0_addr, idle_list_addr[2], next_entry;
	unsigned int worker_task_addr, scheduled_addr, work_func_addr, work_function;
	unsigned int offset_comm = get_offset_struct("((struct task_struct *)0x0)", "comm");
	unsigned int work_entry_offset = get_offset_struct("((struct work_struct *)0x0)", "entry");
	unsigned int work_func_offset = get_offset_struct("((struct work_struct *)0x0)", "func");
	unsigned int unbound_gcwq_addr = rev_lookup("unbound_global_cwq");

*/

offset_rec offsets_required_2_6_38[] = {
	{"init_task", "comm", 0},	
	{"init_task", "pid", 0},
	{"init_task", "tasks", 0},
	{"init_task", "stack", 0},
	{"init_task", "thread_group", 0},
	{"init_task", "state", 0},
	{"init_task", "exit_state", 0},
	/*{"((struct workqueue_struct *)0x0)", "cpu_wq", 0},
	{"((struct workqueue_struct *)0x0)", "name", 0},
	{"((struct cpu_workqueue_struct *)0x0)", "worklist", 0},
	{"((struct cpu_workqueue_struct *)0x0)", "current_work", 0},
	{"((struct work_struct *)0x0)", "func", 0},
	{"((struct work_struct *)0x0)", "entry", 0},
	{"((struct cpu_workqueue_struct *)0x0)", "thread", 0},*/
	{"((struct irq_chip *)0x0)", "name", 0},
	{"irq_desc", "kstat_irqs", 0},
	{"((struct irqaction *)0x0)", "name", 0},
	{"irq_desc", "action", 0},
	{"irq_desc", "chip", 0},
	{"irq_desc", "irq_count", 0},
	{"irq_desc", "irq", 0},
	{"irq_desc", "handle_irq", 0},
	{"((struct vfsmount *)0x0)", "mnt_mountpoint", 0},
	{"((struct dentry *)0x0)", "d_subdirs", 0},
	{"((struct super_block *)0x0)", "s_root", 0},
	{"((struct vfsmount *)0x0)", "mnt_sb", 0},
	{"((struct work_struct *)0x0)", "func"},
	{"((struct work_struct *)0x0)", "entry"},
	{"((struct task_struct *)0x0)", "comm"},
	{"((struct worker *)0x0)", "entry"},
	{"((struct worker *)0x0)", "task"},
	{"((struct worker *)0x0)", "scheduled"},
	{"((struct global_cwq *)0x0)", "busy_hash"},
	{"((struct global_cwq *)0x0)", "idle_list"},
	{"((struct worker *)0x0)", "current_work"},
	{"((struct worker *)0x0)", "hentry"},
	{"((struct workqueue_struct *)0x0)", "cpu_wq"},
	{"((struct delayed_work *)0x0)", "timer"},
	{"((struct timer_list *)0x0)", "expires"},
	{"((struct global_cwq *)0x0)", "worklist"},
	{"sizeof(irq_desc[0])", "", 0, 1},
};

offset_rec offsets_required_30[] = {
        {"init_task", "comm", 0},       
        {"init_task", "pid", 0},
        {"init_task", "tasks", 0},
        {"init_task", "stack", 0},
        {"init_task", "thread_group", 0},
        {"init_task", "state", 0},
        {"init_task", "exit_state", 0},
        {"((struct irq_chip *)0x0)", "name", 0},
        {"irq_desc", "kstat_irqs", 0},
        {"((struct irqaction *)0x0)", "name", 0},
        {"irq_desc", "action", 0},
        {"irq_desc", "irq_data", 0},
        {"irq_desc", "irq_count", 0},
        //{"irq_desc", "irq", 0},
        {"irq_desc", "handle_irq", 0},
        {"((struct irq_data *)0x0)", "chip", 0},
        {"((struct irq_data *)0x0)", "irq", 0},
        {"((struct vfsmount *)0x0)", "mnt_mountpoint", 0},
        {"((struct dentry *)0x0)", "d_subdirs", 0},
        {"((struct super_block *)0x0)", "s_root", 0},
        {"((struct vfsmount *)0x0)", "mnt_sb", 0},
        {"((struct work_struct *)0x0)", "func"},
        {"((struct work_struct *)0x0)", "entry"},
        {"((struct task_struct *)0x0)", "comm"},
        {"((struct worker *)0x0)", "entry"},
        {"((struct worker *)0x0)", "task"},
        {"((struct worker *)0x0)", "scheduled"},
        {"((struct global_cwq *)0x0)", "busy_hash"},
        {"((struct global_cwq *)0x0)", "idle_list"},
        {"((struct worker *)0x0)", "current_work"},
        {"((struct worker *)0x0)", "hentry"},
		{"((struct cpu_workqueue_struct *)0x0)", "delayed_works"},
		{"((struct workqueue_struct *)0x0)", "cpu_wq"},
		{"((struct delayed_work *)0x0)", "timer"},
		{"((struct timer_list *)0x0)", "expires"},
		{"((struct global_cwq *)0x0)", "worklist"},
		{"sizeof(irq_desc[0])", "", 0, 1},
};

offset_rec *offsets_required = NULL;
unsigned int offsets_required_size;

void fill_offset_map()
{	
	fstream f1(TEMP_NAME, ios::out), f2;
	char gdb_cmd[4096];
	char gdbline[4096], *off;
	unsigned long offset;
	
	for(int i = 0; i < offsets_required_size/*sizeof(offsets_required)/sizeof(offset_rec)*/; i++) {
		//cout << "print &" << offsets_required[i].sym << "." << offsets_required[i].mem << endl;
		if(offsets_required[i].szof)
			f1 << "print " << offsets_required[i].sym << endl;
		else f1 << "print &" << offsets_required[i].sym << "." << offsets_required[i].mem << endl;
	}
	f1.close();

	//f1.flush();

	snprintf(gdb_cmd, 1024, "%s -x %s --batch %s > %s",
			 gdbpath, TEMP_NAME, vmlinuxpath, TEMP_NAME_RESULT);

	system(gdb_cmd);

	

	f2.open(TEMP_NAME_RESULT, ios::in);	

	int i = 0;
	while(!f2.eof())
	{
		f2.getline(gdbline, 1024);
	
		if(!(strnlen(gdbline, 1024)>0))
			break;
		int x = strnlen(gdbline, 1024);

		while(gdbline[x]!=' ')
			x--;
		off = gdbline + x;
		
		if(!offsets_required[i].szof)
		offset = strtoul(off, NULL, 16);
		else offset = strtoul(off, NULL, 10);
		
		if(!offsets_required[i].szof)
			offset -= rev_lookup(offsets_required[i].sym.c_str());

	
		offsets_required[i].offset = offset;
		i++;
	}

//	printf("OFFSET (%s.%s): %lx, %lx", sym, member, offset, rev_lookup(sym));*/
	//printf("Done.\n");
	f2.clear();
	//f2.flush();
	f2.close();
	return;	
}

unsigned int get_offset_struct(const char *sym, const char *member, int szof = 0)
{
	fstream f1, f2;
	char gdb_cmd[4096];
	char gdbline[4096], *off;
	unsigned long offset;
	
	for(int i = 0; i < offsets_required_size; i++) {
		//cout << "COMPARE: " << offsets_required[i].sym << endl;
		if( (offsets_required[i].sym.compare(sym)==0)
			&& (offsets_required[i].mem.compare(member)==0) )
				return offsets_required[i].offset;			
	}

	//cout << "Whoops, not present in the cache!\n";

	f1.open(TEMP_NAME, ios::out);
	f1 << endl << "print &" << sym << "." << member << endl;
	f1.close();

	snprintf(gdb_cmd, 1024, "%s -x %s --batch %s > %s",
			 gdbpath, TEMP_NAME, vmlinuxpath, TEMP_NAME_RESULT);

	system(gdb_cmd);

	f2.open(TEMP_NAME_RESULT, ios::in);
	


	f2.getline(gdbline, 1024);


	int x = strnlen(gdbline, 1024);

	while(gdbline[x]!=' ')
		x--;
	off = gdbline + x;
		
	if(!szof)
		offset = strtoul(off, NULL, 16);
	else offset = strtoul(off, NULL, 10);
		
	if(!szof)
		offset -= rev_lookup(sym);

/*	off = strtok(gdbline, "0x");
	off = strtok(NULL, "x");
	
	offset = strtoul(off, NULL, 16);*/
	f2.close();

	printf("OFFSET (%s.%s): %lx, %lx", sym, member, offset, rev_lookup(sym));

	return offset;	
}

struct sysmap_entry {
	unsigned int addr;
	char type[2];
	char symbol[256];
};

typedef struct tzbsp_dump_cpu_ctx_s
{
	uint32 mon_lr;
	uint32 mon_spsr;
	uint32 usr_r0;
	uint32 usr_r1;
	uint32 usr_r2;
	uint32 usr_r3;
	uint32 usr_r4;
	uint32 usr_r5;
	uint32 usr_r6;
	uint32 usr_r7;
	uint32 usr_r8;
	uint32 usr_r9;
	uint32 usr_r10;
	uint32 usr_r11;
	uint32 usr_r12;
	uint32 usr_r13;
	uint32 usr_r14;
	uint32 irq_spsr;
	uint32 irq_r13;
	uint32 irq_r14;
	uint32 svc_spsr;
	uint32 svc_r13;
	uint32 svc_r14;
	uint32 abt_spsr;
	uint32 abt_r13;
	uint32 abt_r14;
	uint32 und_spsr;
	uint32 und_r13;
	uint32 und_r14;
	uint32 fiq_spsr;
	uint32 fiq_r8;
	uint32 fiq_r9;
	uint32 fiq_r10;
	uint32 fiq_r11;
	uint32 fiq_r12;
	uint32 fiq_r13;
	uint32 fiq_r14;
} tzbsp_dump_cpu_ctx_t;

typedef struct tzbsp_dump_buf_s
{
	uint32 sc_status[2];
	tzbsp_dump_cpu_ctx_t sc_ns[2];
	tzbsp_dump_cpu_ctx_t sec;
} tzbsp_dump_buf_t;

tzbsp_dump_buf_t reg_dump;

unsigned int get_current(unsigned int sp)
{
	return (sp & ~(THREAD_SIZE - 1));
}

int big_debug = 0;

void *read_struct(void *buf, int size, fstream *file, int offset)
{
	/*if(offset > (phys_offset + 0x3fffffff)) {
		cout << "Bad offset found in ramdump.\n";
		exit(-1);
	}*/

	offset = get_real_offset(offset);

	//if (big_debug) printf("offset = %x", offset);
	/*if(!(offset >= 0 && offset <= 0x1FFFFFFF)) {
		cout << "Bad offset found in ramdump.\n";
		exit(-1);
	}*/	

	if(file==NULL) {
		cout << "INVALID ADDRESS. OPEN_EBI RETURNED ZERO. ABORTING.";		
	}

	file->seekg(offset, ios::beg);

	if(file->eof() || file->fail() || file->bad())
		return NULL;

	file->read((char *)buf, size);

	if(file->fail() || file->bad())
		return NULL;

	return buf;
}

vector<sysmap_entry> symbol_table;

char * lookup(unsigned int addr, int *offset = NULL)
{
	if(symbol_table.empty())
		return NULL;

	if(addr == 0) return NULL;

	if(addr > symbol_table[symbol_table.size()-1].addr) return NULL;
	if(addr < symbol_table[0].addr) return NULL;

	int low = 0;
	int high = symbol_table.size()-1;

	int mid = (low+high)/2;
	int premid = 0;

	while(!(addr >= symbol_table[mid].addr
		&& addr < symbol_table[mid+1].addr)) {

		if(addr < symbol_table[mid].addr)
			high = mid - 1;

		if(addr > symbol_table[mid].addr)
			low = mid + 1;

		mid = (high+low)/2;

		if(mid==premid)
			return NULL;
		premid = mid;
	}

	if(offset) *offset = addr - symbol_table[mid].addr;

	if(symbol_table[mid].type[0] == 'T' || symbol_table[mid].type[0] == 't')
		return symbol_table[mid].symbol;
	else
		return NULL;
}

char * linlookup(unsigned int addr, int *offset = NULL)
{
	if(symbol_table.empty())
		return NULL;

	if(addr == 0)
		return NULL;

	if(addr > symbol_table[symbol_table.size()-1].addr)
		return NULL;
	if(addr < symbol_table[0].addr)
		return NULL;

	for(unsigned int k = 0; k < symbol_table.size()-1; k++) {
		if(addr >= symbol_table[k].addr
			&& addr < symbol_table[k+1].addr) {

		if(offset)
			*offset = addr - symbol_table[k].addr;

		if(symbol_table[k].type[0]=='T' ||
				symbol_table[k].type[0]=='t')
			return symbol_table[k].symbol;
		}
	}
	return NULL;
}

unsigned int rev_lookup(const char *symname, unsigned int *size)
{
	if(symbol_table.empty())
		return 0;

	if(symname == NULL)
		return 0;

	for(unsigned int k = 0; k < symbol_table.size()-1; k++) {
		if(!strncmp(symbol_table[k].symbol, symname, 256)) {
			if(size) *size = symbol_table[k+1].addr - symbol_table[k].addr;
			return symbol_table[k].addr;
		}
	}
	return 0;
}

unsigned int rev_lookup_prefix(const char *symname_prefix, int prefix_len, unsigned int *size = 0)
{
	if(symbol_table.empty())
		return 0;

	if(symname_prefix == NULL)
		return 0;

	for(unsigned int k = 0; k < symbol_table.size()-1; k++) {
		if(!strncmp(symbol_table[k].symbol, symname_prefix, prefix_len)) {
			if(size) *size = symbol_table[k+1].addr - symbol_table[k].addr;
			return symbol_table[k].addr;
		}
	}
	return 0;
}

#define MAX_STACK_READ 256

void dump_single_stack(unsigned int spaddr, FILE *fp = NULL)
{
	int i, offset;
	fstream *ebifile = open_ebi(spaddr);

	if(!ebifile) return;
	
	unsigned int stack[MAX_STACK_READ] = {0};

	read_struct(&stack, MAX_STACK_READ, ebifile, spaddr);

	for(i = 0; i < MAX_STACK_WALKBACK; i++) {
		offset = 0;
		if(lookup(stack[i], &offset)) {
			if(offset) {
				if(fp)
				fprintf(fp, "[%08X] %08X -- %s+0x%x\n", VIRT(spaddr) + (4*i), stack[i], lookup(stack[i], &offset), offset);
				else printf("[%08X] %08X -- %s+0x%x\n", VIRT(spaddr) + (4*i), stack[i], lookup(stack[i], &offset), offset);
			}

		} //else printf("[%08X] %08X\n", VIRT(spaddr) + (4*i), stack[i]);

	}
}

void get_offsets()
{
	offset_tasks = get_offset_struct("init_task", "tasks");
	offset_comm = get_offset_struct("init_task", "comm");
	offset_stack = get_offset_struct("init_task", "stack");
	offset_thread_group = get_offset_struct("init_task", "thread_group");
	offset_pid = get_offset_struct("init_task", "pid");
	offset_state = get_offset_struct("init_task", "state");
	offset_exit_state = get_offset_struct("init_task", "exit_state");

	//printf("Offset of tasks: %x, offset_comm: %x, offset_stack: %x, offset_thread_group: %x", offset_tasks, offset_comm, offset_stack,
	//	offset_thread_group);


	unlink("offsets.1234");

}

int check_for_panic_stack(unsigned int sp, struct thread_info *thread, const char *taskname) {
	
	unsigned int pc=0, psize=0, lr, spx;
	unsigned int panic_addr = rev_lookup("panic", &psize);

	if(!open_ebi(PHY(sp)))
		return 0;

	for(unsigned int i=sp; i<=(sp+0x4000); i+=4) {
		read_struct(&pc, 4, open_ebi(PHY(i)), PHY(i));
		read_struct(&lr, 4, open_ebi(PHY(i+4)), PHY(i+4));
		read_struct(&spx, 4, open_ebi(PHY(i+8)), PHY(i+8));
		if(pc >= panic_addr && (pc <= (panic_addr + psize))) {
			printf("Faulting process discovered. Name: %s, attempting to retrieve stack now: spx=%x, pc=%x\n", taskname, (i+4), pc);	
			unwind_backtrace(i+4, 0, pc);
	
			/*fstream fp("regs_panic.cmm", ios::out);
			
			if(fp.is_open()) {
				fp << "r.s pc " << pc << "." << endl;
				fp << "r.s r13 " << i+4 << "." << endl;
			}

			fp.close();*/			
			return 1;
		}
	}

	for(unsigned int i=sp; i>=(sp+0x4000); i-=4) {
		read_struct(&pc, 4, open_ebi(PHY(i)), PHY(i));
		read_struct(&lr, 4, open_ebi(PHY(i+4)), PHY(i+4));
		read_struct(&spx, 4, open_ebi(PHY(i+8)), PHY(i+8));
		if(pc >= panic_addr && (pc <= (panic_addr + psize))) {
			printf("Faulting process discovered. Name: %s, attempting to retrieve stack now: spx=%x, pc=%x\n", taskname, (i+4), pc);	
			unwind_backtrace(i+4, 0, pc);

		fstream fp("regs_panic.cmm", ios::out);
			
			if(fp.is_open()) {
				fp << "r.s pc " << pc << "." << endl;
				fp << "r.s r13 " << i+4 << "." << endl;
			}

			fp.close();
			
			return 1;
		}
	}

	return 0;
}

void dump_thread_group(unsigned int init_thread_group, int pr)
{
	char thread_task_name[16];
	unsigned int orig_thread_group, next_thread_start, next_thread_comm, next_thread_pid, next_thread_stack;
	unsigned int thread_task_pid, addr_stack;
	unsigned int next_thread_state, next_thread_exit_state;
	unsigned int task_state, task_exit_state;
	struct thread_info threadinfo;
	static int tgindex = 1;
	int i = 0;
		
	orig_thread_group = init_thread_group;
	int count = 0;
	do {

		if(count++>100) {
			printf("Too many members in this thread group!\n");
			return;
		}

		FILE *f;

		if(pr) {
			
			f = fopen("raw_stack_dumps.txt", "a");

			if(f==0) {

				printf("[F] Couldn't open raw stack dumps file.\n");
				exit(-1);
			}
		}
		next_thread_start = init_thread_group - offset_thread_group;
		next_thread_comm = PHY(next_thread_start + offset_comm);
		next_thread_pid = PHY(next_thread_start + offset_pid);
		next_thread_stack = PHY(next_thread_start + offset_stack);
		next_thread_state = PHY(next_thread_start + offset_state);
		next_thread_exit_state = PHY(next_thread_start + offset_exit_state);

		if (!open_ebi(next_thread_comm))
			return;
		read_struct(thread_task_name, 16, open_ebi(next_thread_comm), next_thread_comm);
		read_struct((char *)&thread_task_pid, 4, open_ebi(next_thread_pid), next_thread_pid);
		read_struct((char *)&task_state, 4, open_ebi(next_thread_state), next_thread_state);
		read_struct((char *)&task_exit_state, 4, open_ebi(next_thread_exit_state), next_thread_exit_state);
		read_struct((char *)&addr_stack, 4, open_ebi(next_thread_stack), next_thread_stack);

		if(!open_ebi(PHY(addr_stack))) {
			return;
		}

		read_struct(&threadinfo, sizeof(struct thread_info), open_ebi(PHY(addr_stack)), PHY(addr_stack));

		if(threadinfo.cpu > 3 || threadinfo.cpu < 0) return;

		if(i++==0) 
			if(pr) printf("%d. Process: %s, cpu: %d, pid: %d, start: 0x%x\n==========================================================\n\n", tgindex++,
							thread_task_name, threadinfo.cpu, thread_task_pid, next_thread_start);
		
		if(pr) {
			printf("	Task name: %s, pid: %d, cpu: %d, \n	state: 0x%x, exit_state: 0x%x, stack_base: 0x%x\n", thread_task_name, thread_task_pid,
			threadinfo.cpu, task_state, task_exit_state, addr_stack);
			printf("	Stack: \n");
			arm_unwind_backtrace((threadinfo.cpu_context.sp), (threadinfo.cpu_context.fp), (threadinfo.cpu_context.pc));
			printf("----------------------------------------------------------\n");
			
			fprintf(f, "--------------------------\n");
			
			fprintf(f, "	Task name: %s, pid: %d, cpu: %d, \n	state: 0x%x, exit_state: 0x%x, stack_base: 0x%x\n", thread_task_name, thread_task_pid,
			threadinfo.cpu, task_state, task_exit_state, addr_stack);
			
			fprintf(f, "	Stack (sp = %x): \n", threadinfo.cpu_context.sp);
			
			dump_single_stack(PHY(threadinfo.cpu_context.sp), f);		
			
		}

		
		unsigned int panic_sp = 0;

		if(!pr && task_state==0)
			check_for_panic_stack(addr_stack, &threadinfo, thread_task_name);	
		
		//printf("%x\n", addr_stack);
		unsigned int stack_value;
		int p=0;

		if(pr) {
			
			fprintf(f, "SP: 0x%08x", threadinfo.cpu_context.sp);
			for(int k = threadinfo.cpu_context.sp; k < threadinfo.cpu_context.sp+256; k+=4) {
				//if(p>=256) break;
				if(p % 8 == 0)
					fprintf(f, "[%08x]: ", k);
				p++;
				read_struct(&stack_value, 4, open_ebi(PHY(k)), PHY(k));
				fprintf(f, " %08x", stack_value);
				if(p>=256) break;
			}
		}
		
		if(pr) {
			fprintf(f, "--------------------------\n");
			fclose(f);
		}

		read_struct((char *)&init_thread_group, 4, open_ebi(PHY(next_thread_start)), PHY(next_thread_start + offset_thread_group));

	}while(init_thread_group != orig_thread_group);

	//fclose(f);
	if(pr) printf("----------------------------------------------------------\n\n");
	
}

void do_dump_stacks(int pr = 1)
{
	unsigned int init_addr = rev_lookup("init_task");
	char init_task_name[16];
	char gdb_cmd[1024];
	unsigned int init_comm, init_pid, init_next_task, orig_init_next_task, cur_task, init_thread_group;
	int offset = 0;
	fstream *ebifile;
	unsigned int addr_stack, init_stack;
	unsigned int threadstack[256];
	struct thread_info threadinfo;
	char *lookupsym;
	int ret;

		if(pr) cout << "\n";
	if(pr) printf("Extracting per-thread-group information now.\n");

	get_offsets();
	if(pr) cout << endl;

	//printf(" INIT TASK is at %x\n", init_addr);

	init_comm = PHY(init_addr) + offset_comm;
	init_stack = PHY(init_addr) + offset_stack;
	init_next_task = PHY(init_addr) + offset_tasks;
	init_pid = PHY(init_addr) + offset_pid;
	init_thread_group = PHY(init_addr) + offset_thread_group;
	orig_init_next_task = VIRT(init_next_task);

	//printf("init_next_task: %x\n",init_next_task );
	//printf("init_thread_group: %x\n",init_thread_group );

	ebifile = open_ebi(init_comm);

	if(!ebifile || !ebifile->is_open()) {
		return;
	}

	int x = 0;
	do {
		if(!open_ebi(init_next_task)) {
			if(pr) cout << "init_next_task" <<  init_next_task;
			if(pr) cout << "[!] Process list corrupted. Aborting listing...\n";
			return;
		}

		//printf("Next task is ...\n");
		read_struct((char *)&init_next_task, 4, open_ebi(init_next_task), init_next_task);

		//printf("init_thread_group: %x\n",VIRT(init_thread_group));
		dump_thread_group(VIRT(init_thread_group), pr);

		init_thread_group = (PHY(init_next_task) - offset_tasks) + offset_thread_group;
		init_next_task = PHY(init_next_task);

		//printf("init_next_task = %x\n", VIRT(init_next_task));
		//printf("orig_next_task = %x\n", orig_init_next_task);
		//if(x++==1) orig_init_next_task = VIRT(init_next_task);
		if(x++ > MAX_PROCESSES) {
			if(pr) printf("Way too many processes. Aborting!\n");
			break;
		}
	}  while(VIRT(init_next_task) != orig_init_next_task);

	
}

void dump_logbuf()
{
	unsigned int logbuf_addr = rev_lookup("__log_buf");
	fstream *ebifile;	
	unsigned int cnt = 0;
	char ch = 30;
	
	ebifile = open_ebi(PHY(logbuf_addr));
	
	if(!ebifile || !ebifile->is_open()) {
		printf("Aborting logbuf dump.\n");
		return;
	}

	read_struct(&ch, 1, ebifile, PHY(logbuf_addr));
	cout << ch;
	while(cnt++<131072) {
		ebifile->read(&ch, 1);
		if(ch != 0) cout << ch;
	}
}

void get_current_info()
{
	fstream *ebifile = open_ebi(current_c0);
	struct thread_info ti0;
	struct thread_info ti1;

	if(ebifile==NULL) {
		printf("Couldn't get _current_ info on core 0.\n");
		return;
	}
	read_struct(&ti0, sizeof(struct thread_info), ebifile, current_c0);

	ebifile = open_ebi(current_c1);

	if(!ebifile) {
		printf("Couldn't get _current_ info on core 1.\n");
		return;
	}

	read_struct(&ti1, sizeof(struct thread_info), ebifile, current_c1);

	current_c0 = PHY((unsigned int)ti0.task) + 0xb8;
	current_c1 = PHY((unsigned int)ti1.task) + 0xb8;
}

unsigned int global_page_table[4096];
unsigned int secondary_page_tables[4096][256];

unsigned int rev_page_tables[4096][256];

void store_page_tables()
{
	unsigned int regval = 0;
	unsigned int i, j;
	unsigned int l1_pte_ptr, l2_pte_ptr;
	unsigned int l1_pte, smi_entries=0;
	unsigned int l2_pt_desc, l2_pt_base, l2_pt_entry;	
	unsigned int virt_address = 0x0;
	unsigned int l1_pte_counter;
	unsigned int msm_ttbr0 = 0;//= rev_lookup("msm_ttbr0");
	
	if(msm_ttbr0 == 0) {
		msm_ttbr0 = phys_offset + 0x4000;
		printf("Using default page table location!\n");
	} else msm_ttbr0 = PHY(msm_ttbr0);


	big_debug = 1;
	if(!open_ebi(msm_ttbr0))
		return;

	FILE *fp = fopen("pagetable.txt", "w");

	if(!fp) {
		printf("Couldn't create pagetable.txt to write page tables!\n");
		return;
	}

	if(msm_ttbr0 != (phys_offset + 0x4000))
		read_struct(&msm_ttbr0, 4, open_ebi(msm_ttbr0), msm_ttbr0);
	big_debug = 0;
	printf("Translation table base = %x\n", msm_ttbr0 & 0xFFFFF000);

	msm_ttbr0 &= 0xFFFFF000;
	int gb_i=0, se_i=0;
	/* 4096 Level 1 entries each describing 1 mb of memory */
	for(i = msm_ttbr0; i < msm_ttbr0+(4096*4); i+=4) {
		l1_pte_ptr = i;
		//l1_pte = *l1_pte_ptr;		
		if(!open_ebi(l1_pte_ptr))
			return;				
		if (i == msm_ttbr0) big_debug = 1;
		read_struct(&l1_pte, 4, open_ebi(l1_pte_ptr), l1_pte_ptr);
		big_debug = 0;
		global_page_table[gb_i] = l1_pte;

		switch (l1_pte & 0x3) {

		case 0x0:
		case 0x3:
			for(int k=0; k<256; k++) {
				//fprintf(fp, "%8.8X--%8.8X\t", virt_address, virt_address+0xfff);
				virt_address+=0x1000;
			}
		break;

		case 0x2:			
			if(!(l1_pte & 0x40000)) /* 1MB Section */
			{
				l1_pte_counter = l1_pte & 0xFFF00000;
				for(int k=0; k<256; k++) {
					fprintf(fp, "%8.8X--%8.8X\t", virt_address, virt_address+0xfff);
					virt_address+=0x1000;
					fprintf(fp, "A:%8.8X--%8.8X\t", l1_pte_counter, l1_pte_counter + 0xfff);
					
					/*if((virt_address - 0x1000) == 0xdfd50000)
						printf("[%x][%x] = 0xdfd50000, l1_pte_counter = %x, l1_pte = %x", BVALSEL(31, 20, l1_pte_counter), BVALSEL(19, 12, l1_pte_counter), l1_pte_counter, l1_pte);
					if((virt_address - 0x1000) == 0xdfd51000)
						printf("[%x][%x] = 0xdfd51000, l1_pte_counter = %x, l1_pte = %x", BVALSEL(31, 20, l1_pte_counter), BVALSEL(19, 12, l1_pte_counter), l1_pte_counter, l1_pte);
					if((virt_address - 0x1000) == 0xdfe51000)
						printf("[%x][%x] = 0xdfe51000, l1_pte_counter = %x, l1_pte = %x", BVALSEL(31, 20, l1_pte_counter), BVALSEL(20, 13, l1_pte_counter), l1_pte_counter, l1_pte);*/
					
					rev_page_tables[BVALSEL(31, 20, l1_pte_counter)][BVALSEL(19, 12, l1_pte_counter)] = virt_address - 0x1000;
					l1_pte_counter += 0x1000;
				}
			}
			else {  /* 16MB Supersection */
				printf("SUPERSECTION!!!! Tell _this_ tool owner NOW - SUPER IMPORTANT!\n");
				for(int k=0; k<256*16; k++) {					
					virt_address+=0x1000;					
				}
			}
		break;

		case 0x1:
		/* A Level 2 page table descriptor! */
		l2_pt_desc = l1_pte;
		l2_pt_base = l2_pt_desc & (~0x3ff);
			
		/*
		 * 256 level 2 entries each describing
		 * a 4k page.
		 */
		for (j = l2_pt_base; j < l2_pt_base+(256*4); j+=4) {		
			fprintf(fp, "%8.8X--%8.8X\t", virt_address, virt_address+0xfff);
			virt_address+=0x1000;

			l2_pte_ptr = j;
			

			if(!open_ebi(l2_pte_ptr))
				return;

			read_struct(&l2_pt_entry, 4, open_ebi(l2_pte_ptr), l2_pte_ptr);	
			secondary_page_tables[gb_i][se_i++] = l2_pt_entry;

			if(l2_pt_entry) {
				fprintf(fp, "A:%8.8X--%8.8X\t", (l2_pt_entry & ~0xFFF), (l2_pt_entry & ~0xFFF) + 0xfff);
				rev_page_tables[BVALSEL(31, 20, l2_pt_entry & ~0xFFF)][BVALSEL(20, 13, l2_pt_entry & ~0xFFF)] = virt_address - 0x1000;
			}
		}
		se_i=0;
		break;

		}
		gb_i++;
	}
	fclose(fp);
}



unsigned int get_phys(unsigned int virt_address)
{	
	unsigned int global_offset = BVALSEL(31, 20, virt_address);

	//printf("global_offset = %x\n", global_offset);

	unsigned int l1_pte = *(global_page_table + global_offset);
	unsigned int bit18 = (l1_pte & 0x40000) >> 18;
	unsigned int onemb_entry;
	unsigned int l2_pte;
	unsigned int l2_offset, entry4kb, entry64kb;

	unsigned int ret = 0;
	//printf("L1PTE = %x, bit18 = %x\n", l1_pte, bit18);

	switch(BVALSEL(1,0,l1_pte)) {

		case 0x1:
		//printf("Secondary page table entry.\n");		
		l2_offset = BVALSEL(19,12, virt_address);
		l2_pte = secondary_page_tables[global_offset][l2_offset];
	
		switch(BVALSEL(1,0,l2_pte)) {
			case 0x2:
			case 0x3:				 
				entry4kb = 
					(l2_pte & BM(31, 12)) + BVALSEL(11, 0, virt_address);
				ret = entry4kb;
				//printf("Entry 4kb page = %x", entry4kb);
			break;

			case 0x1:
				entry64kb = 
						(l2_pte & BM(31, 16)) + BVALSEL(15, 0, virt_address);
				ret = entry64kb;
					//printf("Entry 64kb page = %x", entry64kb);
			break;
		}
		
		break;

		case 0x2: 
		//printf("1MB page table entry.\n");
		onemb_entry = BM(31, 20) & l1_pte;
		onemb_entry += BVALSEL(19, 0, virt_address);
		//printf("onembentry = %x", onemb_entry);
		ret = onemb_entry;
		break;
	}

	//printf("PHYS = %x", ret);
	return ret;
}

unsigned int get_virt(unsigned int phys_address)
{
	
	unsigned int i = BVALSEL(31,20,phys_address);
	unsigned int j = BVALSEL(19,12,phys_address);
	//printf("VIRT(%x)[%x][%x]: %x\n", phys_address, BVALSEL(31,20,phys_address), BVALSEL(20,13,phys_address), rev_page_tables[i][j]);

//	printf("rev_page_tables[i][j]: %x\n", rev_page_tables[i][j] + (phys_address & 0xFFF));
	return rev_page_tables[i][j] + (phys_address & 0xFFF);
}

void check_for_panic() {
	
	
	unsigned int addr_in_panic = rev_lookup("in_panic");

	read_struct(&in_panic, 4, open_ebi(PHY(addr_in_panic)), PHY(addr_in_panic));

	if(in_panic == 0x1) {
		cout << "\n";
		printf("-------------------------------------------------\n");
		printf("[!] KERNEL PANIC detected!\n");
		printf("-------------------------------------------------\n");
	}

	do_dump_stacks(0);
}

void do_TZ_dump()
{
	unsigned int core0_sp;
	unsigned int core1_sp;
	unsigned int core0_irq_sp;
	unsigned int core0_stack[256];
	unsigned int core1_stack[256];
	unsigned int ebi_address;
	unsigned long long last_pet, last_ns = 0;
	unsigned int pet_delay_time;
	unsigned int dogstruct_addr, jiffies;
	unsigned int ctx_buffer_addr = 0;
	int offset;

	fstream *ebifile;
	
	fstream *imem_file = 0;
	unsigned int begin = 0;
	unsigned int seek_to;
	
	// Load the IMEM dump and fetch the address of the CPU context dump buffer

	if (hw_ids[chip].hw_id == 8660)
		ctx_buffer_addr = 0x2a05f000;
	else if (hw_ids[chip].hw_id == 8960)
		ctx_buffer_addr = 0x2a03f000;

	if (ctx_buffer_addr)
		(void)open_ebi_ex(ctx_buffer_addr, &imem_file, &begin);

	if(!imem_file) {
		printf("No imem file found.\n");
		return;
	}

	printf("Determining watchdog state now.\n\n");

	if(!imem_offset)
		// 'begin' points to the actual buffer start address specified on the command line
		seek_to = (ctx_buffer_addr - begin) + IMEM_DEBUG_LOC;
	else
		// Use imem offset specified on command line;
		seek_to = imem_offset;

	imem_file->seekg(seek_to, ios_base::beg);

	if(!imem_file->eof()) {
		imem_file->read((char *)&ebi_address, 4);
	} else return;

	cout << endl;
	printf("------------- Scorpion context extraction -------------\n\n");
	

	printf("[!] EBI Address found at offset 0x%x in IMEM: 0x%08X\n\n", seek_to, ebi_address);

	last_ns = rev_lookup_prefix("last_ns", strlen("last_ns"));
	last_pet = rev_lookup("last_pet");
	pet_delay_time = rev_lookup("delay_time");
	dogstruct_addr = rev_lookup("dogwork_struct");
	unsigned long timer_offset = get_offset_struct("((struct delayed_work *)0x0)", "timer");
	unsigned long timer_expires, timer_expires_offset = get_offset_struct("((struct timer_list *)0x0)", "expires");//rev_lookup("dogwork_struct");
	jiffies = rev_lookup("jiffies");

	read_struct(&timer_expires, 4, open_ebi(PHY(dogstruct_addr)), PHY(dogstruct_addr) + timer_offset + timer_expires_offset);
	read_struct(&jiffies, 4, open_ebi(PHY(jiffies)), PHY(jiffies));
   
	if (timer_expires > jiffies)
		printf("Pet function to be scheduled in %g seconds.\n", (timer_expires - jiffies) * 0.01);
	else printf("Pet function may have been blocked, jiffies is \n"
				"%g seconds after when it was supposed to be scheduled\n"
				"on the work queue.\n", (jiffies - timer_expires ) * 0.01 );
	
	if(last_ns && last_pet && open_ebi(PHY(pet_delay_time))) {
		read_struct(&last_ns, 8, open_ebi(PHY(last_ns)), PHY(last_ns));
		read_struct(&last_pet, 8, open_ebi(PHY(last_pet)), PHY(last_pet));	
		read_struct(&pet_delay_time, 4, open_ebi(PHY(pet_delay_time)), PHY(pet_delay_time));

		unsigned long long diff = last_ns - last_pet;

		printf("Most recent time that the watchdog was pet: %llu.%6lu\n", last_pet/1000000000,
			last_pet%1000000000);
		printf("Most recent timestamp read from the timer hardware: %llu.%6lu\n\n",
			last_ns/1000000000, last_ns%1000000000);
		if(last_ns > last_pet)
			printf("Pet delay time in this build is %u seconds.\n"
					"The watchdog was not pet for at least %llu.%6lu seconds\n\n", (pet_delay_time*10)/1000,
					diff/1000000000, diff%1000000000);

		printf("[W] The difference between the two timestamps above is NOT to be\n" 
				"[W] used to determine whether a watchdog bite occured.\n\n");		
	} else if(open_ebi(PHY(last_pet))) {
		read_struct(&last_pet, 8, open_ebi(PHY(last_pet)), PHY(last_pet));	
		printf("Most recent time that the watchdog was pet: %llu.%6lu\n\n", last_pet/1000000000,
			last_pet%1000000000);
	}
		
	ebifile = open_ebi(ebi_address);

	if(!ebifile || !ebifile->is_open()) {
		printf("[!] Address of TZ-dumped scorpion context looks bogus. \n"
				"[!] This may have been an apps  watchdog bite but there was \n"	
				"[!] no bark. Or it may have not been a watchdog reset at all.\n");
		printf("------------- END Scorpion context extraction -------------\n\n");
		return;
	}

	printf("[!] Address of TZ-dumped scorpion context looks valid." 
			"[!] This looks like an apps watchdog bark.\n\n");
	if(in_panic) 
		printf("[!] Careful, it looks like there was a panic as well.\n\n");

	read_struct(&reg_dump, sizeof(reg_dump), ebifile, ebi_address);

	if(reg_dump.sc_status[0] & TZBSP_SC_STATUS_NS)
		printf("CORE 0 was in the non-secure world.\n");

	if(reg_dump.sc_status[0] & TZBSP_SC_STATUS_WDT)
		printf("CORE 0 experienced a watchdog timeout.\n");

	if(reg_dump.sc_status[0] & TZBSP_SC_STATUS_SGI)
		printf("CORE 0 did not experience a watchdog timeout but some other core did.\n");

	cout << "\n";

	if(reg_dump.sc_status[1] & TZBSP_SC_STATUS_NS)
		printf("CORE 1 was in the non-secure world.\n");

	if(reg_dump.sc_status[1] & TZBSP_SC_STATUS_WDT)
		printf("CORE 1 experienced a watchdog timeout.\n");

	if(reg_dump.sc_status[1] & TZBSP_SC_STATUS_SGI)
		printf("CORE 1 did not experience a watchdog timeout but some other core did.\n");

	char *core0_sym = lookup(reg_dump.sc_ns[0].mon_lr, &offset);

	cout << "\n";

	if(core0_sym)
		printf("CORE 0 PC: %s+0x%02x <0x%08x>\n", core0_sym, offset, reg_dump.sc_ns[0].mon_lr);
	else printf("CORE 0 PC: %s <0x%08x>\n", core0_sym, reg_dump.sc_ns[0].mon_lr);
		
	offset = 0;
	core0_sym = lookup(reg_dump.sc_ns[0].svc_r14, &offset);
	if(core0_sym)
		printf("CORE 0 LR: %s+0x%02x <0x%08x>\n", core0_sym, offset, reg_dump.sc_ns[0].svc_r14);
	else
		printf("CORE 0 LR: %s <0x%08x>\n", core0_sym, reg_dump.sc_ns[0].svc_r14);

	cout << "\n";

	offset = 0;
	char *core1_sym = lookup(reg_dump.sc_ns[1].mon_lr, &offset);
	if(core1_sym)
		printf("CORE 1 PC: %s+0x%02x <0x%08x>\n", core1_sym, offset, reg_dump.sc_ns[1].mon_lr);
	else
		printf("CORE 1 PC: %s <0x%08x>\n", core1_sym, reg_dump.sc_ns[1].mon_lr);

	offset = 0;
	core1_sym = lookup(reg_dump.sc_ns[1].svc_r14, &offset);
	if(core1_sym)
		printf("CORE 1 LR: %s+0x%02x <0x%08x>\n", core1_sym, offset, reg_dump.sc_ns[1].svc_r14);
	else
		printf("CORE 1 LR: %s <0x%08x>\n", core1_sym, reg_dump.sc_ns[1].svc_r14);

	if(reg_dump.sc_ns[0].mon_lr == 0 && reg_dump.sc_ns[1].mon_lr == 0)
		printf("*** SORRY, THIS LOOKS LIKE A BAD DUMP. CONTINUING ANYWAY... ***\n");

	core0_sp = PHY(reg_dump.sc_ns[0].svc_r13);
	core1_sp = PHY(reg_dump.sc_ns[1].svc_r13);
	core0_irq_sp = PHY(reg_dump.sc_ns[1].irq_r13);

	current_c0 = PHY(get_current(reg_dump.sc_ns[0].svc_r13));
	current_c1 = PHY(get_current(reg_dump.sc_ns[1].svc_r13));

	cout << "\n";

	printf("CORE 0 current task: %08x\n", VIRT(current_c0));
	printf("CORE 1 current task: %08x\n", VIRT(current_c1));

	get_current_info();

	cout << "\n";

	printf("Core 0 ARM unwind stack:\n");
	arm_unwind_backtrace(reg_dump.sc_ns[0].svc_r13, 0, reg_dump.sc_ns[0].mon_lr);
	printf("CORE 0 raw stack dump (starting at %08X): \n", VIRT(core0_sp)); 
	dump_single_stack(core0_sp);
	
	cout << "\n";

	printf("Core1 ARM unwind stack:\n");
	arm_unwind_backtrace(reg_dump.sc_ns[1].usr_r11+4, 0, reg_dump.sc_ns[1].svc_r14);
	printf("CORE 1 raw stack dump (starting at %08X): \n", VIRT(core1_sp));
	dump_single_stack(core1_sp);
	
	cout << "\n";

	offset = 0;
	printf("***** REGISTER DUMP FOLLOWS ***** \n");
	printf("======== CORE 0 ==========\n");
	core0_sym = lookup(reg_dump.sc_ns[0].mon_lr, &offset);
	printf(" sc_ns[0].mon_lr = 0x%08X [%s+0x%04x]\n", reg_dump.sc_ns[0].mon_lr, core0_sym, core0_sym ? offset : 0);
	printf(" sc_ns[0].mon_spsr = 0x%08X\n", reg_dump.sc_ns[0].mon_spsr);
	printf(" sc_ns[0].usr_r0 = 0x%08X\n", reg_dump.sc_ns[0].usr_r0);
	printf(" sc_ns[0].usr_r1 = 0x%08X\n", reg_dump.sc_ns[0].usr_r1);
	printf(" sc_ns[0].usr_r2 = 0x%08X\n", reg_dump.sc_ns[0].usr_r2);
	printf(" sc_ns[0].usr_r3 = 0x%08X\n", reg_dump.sc_ns[0].usr_r3);
	printf(" sc_ns[0].usr_r4 = 0x%08X\n", reg_dump.sc_ns[0].usr_r4);
	printf(" sc_ns[0].usr_r5 = 0x%08X\n", reg_dump.sc_ns[0].usr_r5);
	printf(" sc_ns[0].usr_r6 = 0x%08X\n", reg_dump.sc_ns[0].usr_r6);
	printf(" sc_ns[0].usr_r7 = 0x%08X\n", reg_dump.sc_ns[0].usr_r7);
	printf(" sc_ns[0].usr_r8 = 0x%08X\n", reg_dump.sc_ns[0].usr_r8);
	printf(" sc_ns[0].usr_r9 = 0x%08X\n", reg_dump.sc_ns[0].usr_r9);
	printf(" sc_ns[0].usr_r10 = 0x%08X\n", reg_dump.sc_ns[0].usr_r10);
	printf(" sc_ns[0].usr_r11 = 0x%08X\n", reg_dump.sc_ns[0].usr_r11);
	printf(" sc_ns[0].usr_r12 = 0x%08X\n", reg_dump.sc_ns[0].usr_r12);
	printf(" sc_ns[0].usr_r13 = 0x%08X\n", reg_dump.sc_ns[0].usr_r13);
	printf(" sc_ns[0].usr_r14 = 0x%08X\n", reg_dump.sc_ns[0].usr_r14);
	printf(" sc_ns[0].irq_spsr = 0x%08X\n", reg_dump.sc_ns[0].irq_spsr);
	printf(" sc_ns[0].irq_r13 = 0x%08X\n", reg_dump.sc_ns[0].irq_r13);

	offset = 0;
	core0_sym = lookup(reg_dump.sc_ns[0].irq_r14, &offset);
	printf(" sc_ns[0].irq_r14 = 0x%08X [%s+0x%04x]\n", reg_dump.sc_ns[0].irq_r14, core0_sym, core0_sym ? offset : 0);
	printf(" sc_ns[0].svc_spsr = 0x%08X\n", reg_dump.sc_ns[0].svc_spsr);
	printf(" sc_ns[0].svc_r13 = 0x%08X\n", reg_dump.sc_ns[0].svc_r13);

	offset = 0;
	core0_sym = lookup(reg_dump.sc_ns[0].svc_r14, &offset);
	printf(" sc_ns[0].svc_r14 = 0x%08X [%s+0x%04x]\n", reg_dump.sc_ns[0].svc_r14, core0_sym, core0_sym ? offset : 0);
	printf(" sc_ns[0].abt_spsr = 0x%08X\n", reg_dump.sc_ns[0].abt_spsr);
	printf(" sc_ns[0].abt_r13 = 0x%08X\n", reg_dump.sc_ns[0].abt_r13);

	offset = 0;
	core0_sym = lookup(reg_dump.sc_ns[0].abt_r14, &offset);
	printf(" sc_ns[0].abt_r14 = 0x%08X [%s+0x%04x]\n", reg_dump.sc_ns[0].abt_r14, core0_sym, core0_sym ? offset : 0);
	printf(" sc_ns[0].und_spsr = 0x%08X\n", reg_dump.sc_ns[0].und_spsr);
	printf(" sc_ns[0].und_r13 = 0x%08X\n", reg_dump.sc_ns[0].und_r13);

	offset = 0;
	core0_sym = lookup(reg_dump.sc_ns[0].und_r14, &offset);
	printf(" sc_ns[0].und_r14 = 0x%08X [%s+0x%04x]\n", reg_dump.sc_ns[0].und_r14, core0_sym, core0_sym ? offset : 0);
	printf(" sc_ns[0].fiq_spsr = 0x%08X\n", reg_dump.sc_ns[0].fiq_spsr);
	printf(" sc_ns[0].fiq_r8 = 0x%08X\n", reg_dump.sc_ns[0].fiq_r8);
	printf(" sc_ns[0].fiq_r9 = 0x%08X\n", reg_dump.sc_ns[0].fiq_r9);
	printf(" sc_ns[0].fiq_r10 = 0x%08X\n", reg_dump.sc_ns[0].fiq_r10);
	printf(" sc_ns[0].fiq_r11 = 0x%08X\n", reg_dump.sc_ns[0].fiq_r11);
	printf(" sc_ns[0].fiq_r12 = 0x%08X\n", reg_dump.sc_ns[0].fiq_r12);
	printf(" sc_ns[0].fiq_r13 = 0x%08X\n", reg_dump.sc_ns[0].fiq_r13);
	printf(" sc_ns[0].fiq_r14 = 0x%08X\n", reg_dump.sc_ns[0].fiq_r14);

	offset = 0;
	cout << "\n";
	printf("======== CORE 1 ==========\n");
	core1_sym = lookup(reg_dump.sc_ns[1].mon_lr, &offset);
	printf(" sc_ns[1].mon_lr = 0x%08X [%s+0x%04x]\n", reg_dump.sc_ns[1].mon_lr, core1_sym, core1_sym ? offset : 0);

	printf(" sc_ns[1].mon_spsr = 0x%08X\n", reg_dump.sc_ns[1].mon_spsr);
	printf(" sc_ns[1].usr_r0 = 0x%08X\n", reg_dump.sc_ns[1].usr_r0);
	printf(" sc_ns[1].usr_r1 = 0x%08X\n", reg_dump.sc_ns[1].usr_r1);
	printf(" sc_ns[1].usr_r2 = 0x%08X\n", reg_dump.sc_ns[1].usr_r2);
	printf(" sc_ns[1].usr_r3 = 0x%08X\n", reg_dump.sc_ns[1].usr_r3);
	printf(" sc_ns[1].usr_r4 = 0x%08X\n", reg_dump.sc_ns[1].usr_r4);
	printf(" sc_ns[1].usr_r5 = 0x%08X\n", reg_dump.sc_ns[1].usr_r5);
	printf(" sc_ns[1].usr_r6 = 0x%08X\n", reg_dump.sc_ns[1].usr_r6);
	printf(" sc_ns[1].usr_r7 = 0x%08X\n", reg_dump.sc_ns[1].usr_r7);
	printf(" sc_ns[1].usr_r8 = 0x%08X\n", reg_dump.sc_ns[1].usr_r8);
	printf(" sc_ns[1].usr_r9 = 0x%08X\n", reg_dump.sc_ns[1].usr_r9);
	printf(" sc_ns[1].usr_r10 = 0x%08X\n", reg_dump.sc_ns[1].usr_r10);
	printf(" sc_ns[1].usr_r11 = 0x%08X\n", reg_dump.sc_ns[1].usr_r11);
	printf(" sc_ns[1].usr_r12 = 0x%08X\n", reg_dump.sc_ns[1].usr_r12);
	printf(" sc_ns[1].usr_r13 = 0x%08X\n", reg_dump.sc_ns[1].usr_r13);
	printf(" sc_ns[1].usr_r14 = 0x%08X\n", reg_dump.sc_ns[1].usr_r14);
	printf(" sc_ns[1].irq_spsr = 0x%08X\n", reg_dump.sc_ns[1].irq_spsr);
	printf(" sc_ns[1].irq_r13 = 0x%08X\n", reg_dump.sc_ns[1].irq_r13);

	offset = 0;
	core1_sym = lookup(reg_dump.sc_ns[1].irq_r14, &offset);
	printf(" sc_ns[0].irq_r14 = 0x%08X [%s+0x%04x]\n", reg_dump.sc_ns[1].irq_r14, core1_sym, core1_sym ? offset : 0);
	printf(" sc_ns[1].svc_spsr = 0x%08X\n", reg_dump.sc_ns[1].svc_spsr);
	printf(" sc_ns[1].svc_r13 = 0x%08X\n", reg_dump.sc_ns[1].svc_r13);

	offset = 0;
	core1_sym = lookup(reg_dump.sc_ns[1].svc_r14, &offset);
	printf(" sc_ns[0].svc_r14 = 0x%08X [%s+0x%04x]\n", reg_dump.sc_ns[1].svc_r14, core1_sym, core1_sym ? offset : 0);
	printf(" sc_ns[1].abt_spsr = 0x%08X\n", reg_dump.sc_ns[1].abt_spsr);
	printf(" sc_ns[1].abt_r13 = 0x%08X\n", reg_dump.sc_ns[1].abt_r13);

	offset = 0;
	core1_sym = lookup(reg_dump.sc_ns[1].abt_r14, &offset);
	printf(" sc_ns[0].abt_r14 = 0x%08X [%s+0x%04x]\n", reg_dump.sc_ns[1].abt_r14, core1_sym, core1_sym ? offset : 0);
	printf(" sc_ns[1].und_spsr = 0x%08X\n", reg_dump.sc_ns[1].und_spsr);
	printf(" sc_ns[1].und_r13 = 0x%08X\n", reg_dump.sc_ns[1].und_r13);

	offset = 0;
	core1_sym = lookup(reg_dump.sc_ns[1].und_r14, &offset);
	printf(" sc_ns[0].und_r14 = 0x%08X [%s+0x%04x]\n", reg_dump.sc_ns[1].und_r14, core1_sym, core1_sym ? offset : 0);
	printf(" sc_ns[1].fiq_spsr = 0x%08X\n", reg_dump.sc_ns[1].fiq_spsr);
	printf(" sc_ns[1].fiq_r8 = 0x%08X\n", reg_dump.sc_ns[1].fiq_r8);
	printf(" sc_ns[1].fiq_r9 = 0x%08X\n", reg_dump.sc_ns[1].fiq_r9);
	printf(" sc_ns[1].fiq_r10 = 0x%08X\n", reg_dump.sc_ns[1].fiq_r10);
	printf(" sc_ns[1].fiq_r11 = 0x%08X\n", reg_dump.sc_ns[1].fiq_r11);
	printf(" sc_ns[1].fiq_r12 = 0x%08X\n", reg_dump.sc_ns[1].fiq_r12);
	printf(" sc_ns[1].fiq_r13 = 0x%08X\n", reg_dump.sc_ns[1].fiq_r13);
	printf(" sc_ns[1].fiq_r14 = 0x%08X\n", reg_dump.sc_ns[1].fiq_r14);

	printf("------------- END Scorpion context extraction -------------\n\n");
}

void load_symbols()
{
	int ret = system(vmlinux_cmd);
	char sysmapline[256];

	if(ret) {
		printf("**** UNABLE TO CONSTRUCT SYMBOL TABLE. NO SYMBOLS FOR YOU.\n\n");
		return;
	}

	fstream sysmap;
	sysmap.open("System.map.x1234", ios::in);

	while(!sysmap.eof() && !sysmap.bad() && !sysmap.fail()) {

		sysmap.getline(sysmapline, 256);
		if(sysmapline[0] == ' ') continue;

		char *address = strtok(sysmapline, " ");
		if(address == NULL) break;
		sysmap_entry *entry = new sysmap_entry;
		entry->addr = strtoul(address, NULL, 16);
		strcpy(entry->type, strtok(NULL, " "));
		strcpy(entry->symbol, strtok(NULL, " "));
		symbol_table.push_back(*entry);
      
		// Since we copied the contents of "entry" into "symbol_table" we can discard it
		delete entry;
	}
	sysmap.close();

	if(symbol_table.empty()) {
		printf("**** UNABLE TO CONSTRUCT SYMBOL TABLE. NO SYMBOLS FOR YOU.\n\n");
	}

	unlink("System.map.x1234");

}

void load_main_unwind_table()
{
	unsigned int start = rev_lookup("__start_unwind_idx");
	unsigned int end = rev_lookup("__stop_unwind_idx");
	unsigned int i;

	printf("Init'ing unwind table. Start = [0x%X], End = [0x%X].\n", start, end);

	unwind_table = new unwind_idx[(end-start)/sizeof(unwind_table) + 1];

	end_unwind_table = &unwind_table[(end-start)/sizeof(unwind_table)-1];

	//printf("PHY Start = %x\n", PHY(start));

	if(!start)
		printf("[W] Unwind table not found.\n");

	fstream *ebifile = open_ebi(PHY(start));

	if (!ebifile) {
		printf("Unable to load unwind table. Fopen failed.\n");
		return;
	}	

	for(i = 0; i <= (((end-start))/(sizeof(struct unwind_idx)-4)); i++) {
		read_struct(&unwind_table[i], sizeof(struct unwind_idx)-4, ebifile, PHY((start + i*(sizeof(struct unwind_idx)-4))));
		//printf("uw: %x\n", (start + i*sizeof(struct unwind_idx)));
		unwind_table[i].addr_idx = start + i*(sizeof(struct unwind_idx)-4);
		//if(!unwind_table[i].addr_idx) {printf("\n\n\n\BLAHAAAHAHA\n\n\n");exit(-1);}
		if((unwind_table[i].addr & page_offset) != page_offset) {i--; break;}		
	}

	end_unwind_table = unwind_table+i;
}

void print_clocks_35()
{
	unsigned int clocks_ptr = rev_lookup("soc_clk_local_tbl");
	

}

void print_workqueue_state_38()
{
	unsigned int per_cpu_offset_addr = rev_lookup("__per_cpu_offset");
	unsigned int global_cwq_sym_addr = rev_lookup("global_cwq");
	unsigned int system_wq_addr = rev_lookup("system_long_wq");
	unsigned int idle_list_offset = get_offset_struct("((struct global_cwq *)0x0)", "idle_list");
	unsigned int worklist_offset = get_offset_struct("((struct global_cwq *)0x0)", "worklist");
	unsigned int busy_hash_offset = get_offset_struct("((struct global_cwq *)0x0)", "busy_hash");
	unsigned int scheduled_offset = get_offset_struct("((struct worker *)0x0)", "scheduled");
	unsigned int worker_task_offset = get_offset_struct("((struct worker *)0x0)", "task");
	unsigned int worker_entry_offset = get_offset_struct("((struct worker *)0x0)", "entry");
	unsigned int per_cpu_offset0, per_cpu_offset1, global_cwq_cpu0_addr, idle_list_addr[2], worklist_addr[2], next_entry;
	unsigned int worker_task_addr, scheduled_addr, work_func_addr, work_function;
	unsigned int offset_comm = get_offset_struct("((struct task_struct *)0x0)", "comm");
	unsigned int work_entry_offset = get_offset_struct("((struct work_struct *)0x0)", "entry");
	unsigned int work_hentry_offset = get_offset_struct("((struct worker *)0x0)", "hentry");
	unsigned int work_func_offset = get_offset_struct("((struct work_struct *)0x0)", "func");
	unsigned int current_work_offset = get_offset_struct("((struct worker *)0x0)", "current_work");
	
	unsigned int cpu_wq_offset = get_offset_struct("((struct workqueue_struct *)0x0)", "cpu_wq");
	unsigned int unbound_gcwq_addr = rev_lookup("unbound_global_cwq");
	char taskname[16];
	unsigned int busy_hash[128], worker_addr, current_work_addr, current_work_func, next_busy_worker;
	unsigned int next_work_entry;

	read_struct(&per_cpu_offset0, 4, open_ebi(PHY(per_cpu_offset_addr)), PHY(per_cpu_offset_addr));
	read_struct(&per_cpu_offset1, 4, open_ebi(PHY(per_cpu_offset_addr)), PHY(per_cpu_offset_addr + 4));
	global_cwq_cpu0_addr = global_cwq_sym_addr + per_cpu_offset0;

	read_struct(&idle_list_addr[0], 4, open_ebi(PHY(global_cwq_cpu0_addr)), PHY(global_cwq_cpu0_addr + idle_list_offset));
	read_struct(&idle_list_addr[1], 4, open_ebi(PHY(unbound_gcwq_addr)), PHY(unbound_gcwq_addr + idle_list_offset));

	read_struct(&worklist_addr[0], 4, open_ebi(PHY(global_cwq_cpu0_addr)), PHY(global_cwq_cpu0_addr + worklist_offset));
	read_struct(&worklist_addr[1], 4, open_ebi(PHY(unbound_gcwq_addr)), PHY(unbound_gcwq_addr + worklist_offset));

	read_struct(busy_hash, 64*4, open_ebi(PHY(global_cwq_cpu0_addr)), PHY(global_cwq_cpu0_addr + busy_hash_offset));
	read_struct(busy_hash + 64, 64*4, open_ebi(PHY(unbound_gcwq_addr)), PHY(unbound_gcwq_addr + busy_hash_offset));
	
	for(int k=0; k<128; k++) {
		next_busy_worker = busy_hash[k];
		//printf("busy_hash:%x\n", busy_hash[k]);
		if(busy_hash[k] != 0) {
			int cnt = 0;
			do {
				worker_addr = next_busy_worker - work_hentry_offset;
				read_struct(&worker_task_addr, 4, open_ebi(PHY(worker_addr)), PHY(worker_addr + worker_task_offset));

				if(!worker_task_addr) break;
				read_struct(&taskname, 16, open_ebi(PHY(worker_task_addr + offset_comm)), PHY(worker_task_addr + offset_comm));
				read_struct(&scheduled_addr, 4, open_ebi(PHY(worker_addr)), PHY(worker_addr + scheduled_offset));
				read_struct(&current_work_addr, 4, open_ebi(PHY(worker_addr)), PHY(worker_addr + current_work_offset));
				read_struct(&current_work_func, 4, open_ebi(PHY(current_work_addr)), PHY(current_work_addr + work_func_offset));

				printf("BUSY Workqueue worker: %s, current_work: %s\n", taskname, lookup(current_work_func));

				if(scheduled_addr == (worker_addr + scheduled_offset)) goto skip;

				next_work_entry = scheduled_addr;
				do {
					read_struct(&work_func_addr, 4, open_ebi(PHY(next_work_entry)), PHY(next_work_entry - work_hentry_offset + work_func_offset));
					read_struct(&next_work_entry, 4, open_ebi(PHY(next_work_entry)), PHY(next_work_entry));				

					printf("entry: %p, workfuncaddr: %p, %s\n", next_work_entry, PHY(work_func_addr), lookup(work_func_addr));
					
				}while(next_work_entry != scheduled_addr);
				if(cnt++>200) break;
skip:				
				read_struct(&next_busy_worker, 4, open_ebi(PHY(worker_addr)), PHY(worker_addr + work_hentry_offset));
				
			}while(next_busy_worker != 0);
		}
	}

	for(int i=0; i<2; i++) {		
		next_entry = idle_list_addr[i];
		int cnt = 0;
		do {		
			worker_addr = next_entry - worker_entry_offset;
//			printf("PHY(next_ent) = %x\n", PHY(next_entry));
			read_struct(&worker_task_addr, 4, open_ebi(PHY(next_entry)), PHY(next_entry - worker_entry_offset + worker_task_offset));		
			if(!worker_task_addr) break;
			read_struct(&taskname, 16, open_ebi(PHY(worker_task_addr + offset_comm)), PHY(worker_task_addr + offset_comm));
			read_struct(&scheduled_addr, 4, open_ebi(PHY(worker_addr)), PHY(next_entry - worker_entry_offset + scheduled_offset));			
			read_struct(&next_entry, 4, open_ebi(PHY(next_entry)), PHY(next_entry));			
//			printf("PHY(next_ent) = %x\n", PHY(next_entry));
			read_struct(&current_work_addr, 4, open_ebi(PHY(worker_addr)), PHY(worker_addr + current_work_offset));
			if(current_work_addr)
				read_struct(&current_work_func, 4, open_ebi(PHY(current_work_addr)), PHY(current_work_addr + work_func_offset));
			else current_work_func = 0;
			if(next_entry == idle_list_addr[i]) break;

			printf("IDLE Workqueue worker: %s, current_work: %s\n", taskname, lookup(current_work_func));
			
			if(scheduled_addr == (worker_addr + scheduled_offset)) continue;
			if(cnt++>200) break;
			unsigned int next_work_entry = scheduled_addr;			
			int cnt2 = 0;
			do {
				read_struct(&work_func_addr, 4, open_ebi(PHY(next_work_entry)), PHY(next_work_entry - work_entry_offset + work_func_offset));
				read_struct(&next_work_entry, 4, open_ebi(PHY(next_work_entry)), PHY(next_work_entry));				

				printf("entry: %p, workfuncaddr: %p, %s\n", next_work_entry, PHY(work_func_addr), lookup(work_func_addr));
				if(next_work_entry == scheduled_addr) break;		
				if(cnt2++>200) break;
			}while(next_work_entry != scheduled_addr);

		}while(next_entry != idle_list_addr[i]);	
	}

	printf("Pending workqueue info: \n");

	for(int i=0; i<2; i++) {
		next_work_entry = worklist_addr[i];
		int cnt = 0;
		do {
				read_struct(&work_func_addr, 4, open_ebi(PHY(next_work_entry)), PHY(next_work_entry - work_entry_offset + work_func_offset));
				read_struct(&next_work_entry, 4, open_ebi(PHY(next_work_entry)), PHY(next_work_entry));				

				if (PHY(work_func_addr))
					if(i==0) printf("Pending unbound entry: %s\n", lookup(work_func_addr));
					else printf("Pending bound entry: %s\n", lookup(work_func_addr));
				if(next_work_entry == worklist_addr[i]) break;		
				if(cnt++>200) break;
			}while(next_work_entry != worklist_addr[i]);		
	}


	/*printf("Delayed workqueue info (It's probably ok to find the wdog pet function here): \n");

	unsigned cpu_wq_addr = 0, system_wq;
	read_struct(&system_wq, 4, open_ebi(PHY(system_wq_addr)), PHY(system_wq_addr));
	read_struct(&cpu_wq_addr, 4, open_ebi(PHY(system_wq)), PHY(system_wq) + cpu_wq_offset);
	read_struct(&worklist_addr[0], 4, open_ebi(PHY(cpu_wq_addr)), PHY(cpu_wq_addr) + per_cpu_offset1 + delayed_work_offset);

	printf("cpu_wq_addr: %x, worklist= %x\n", cpu_wq_addr, worklist_addr[0]);

	for(int i=0; i<1; i++) {
		next_work_entry = worklist_addr[i];
		int cnt = 0;
		do {
				read_struct(&work_func_addr, 4, open_ebi(PHY(next_work_entry)), PHY(next_work_entry - work_entry_offset + work_func_offset));
				read_struct(&next_work_entry, 4, open_ebi(PHY(next_work_entry)), PHY(next_work_entry));				

				
				if(next_work_entry == worklist_addr[i]) break;		

				if (PHY(work_func_addr))
					if(i==0) printf("Delayed entry: %s\n", lookup(work_func_addr));
					else printf("Pending bound entry: %s\n", lookup(work_func_addr));
				if(cnt++>200) break;
			}while(next_work_entry != worklist_addr[i]);		
	}*/
	
}

void print_workqueue_state()
{
	unsigned int keventd_wq_addr = rev_lookup("keventd_wq");
	unsigned int keventd_wq;
	unsigned int cpu_wq_offset = get_offset_struct("((struct workqueue_struct *)0x0)", "cpu_wq");
	unsigned int wq_name_offset = get_offset_struct("((struct workqueue_struct *)0x0)", "name");
	unsigned int worklist_offset = get_offset_struct("((struct cpu_workqueue_struct *)0x0)", "worklist");
	unsigned int work_func_offset = get_offset_struct("((struct work_struct *)0x0)", "func");
	unsigned int work_entry_offset = get_offset_struct("((struct work_struct *)0x0)", "entry");
	unsigned int thread_offset = get_offset_struct("((struct cpu_workqueue_struct *)0x0)", "thread");
	unsigned int cur_work_offset = get_offset_struct("((struct cpu_workqueue_struct *)0x0)", "current_work");
	unsigned int cpuwqaddr, worklistaddr, workfuncaddr, threadaddr, wq_name_addr, current_work_addr;
	char wq_name[16];
	unsigned int cpuwqsize = 64, current_work;
	unsigned int pcpu_base_addr = rev_lookup("pcpu_base_addr");
	unsigned int per_cpu_start_addr = rev_lookup("__per_cpu_start");
	unsigned int per_cpu_offset_addr = rev_lookup("__per_cpu_offset");
	unsigned int pcpu_base, per_cpu_start, per_cpu_offset[2];
	unsigned int next_entry, c=0;

	//printf("cpu_wq_offset: %x, worklist_offset: %x, keventd_wq: %x, workfuncoffset: %x\n",
	//		cpu_wq_offset, worklist_offset, keventd_wq_addr, work_func_offset);
	
	fstream *f1 = open_ebi(PHY(keventd_wq_addr));

	if(!f1) {
		printf("Sorry, keventd_wq's invalid. Workqueue state cannot be retrieved!\n");
		return;
	}
	
	read_struct(&keventd_wq, 4, f1, PHY(keventd_wq_addr));
	printf("keventd_wq: %x\n", keventd_wq);

	f1 = open_ebi(PHY(keventd_wq));

	if(!f1) {
		return;
	}

	read_struct(&cpuwqaddr, 4, f1, PHY(keventd_wq + cpu_wq_offset));
	read_struct(&wq_name_addr, 4, f1, PHY(keventd_wq + wq_name_offset));

	if(!open_ebi(PHY(wq_name_addr))) {
		return;
	}

	read_struct(wq_name, 16, open_ebi(PHY(wq_name_addr)), PHY(wq_name_addr));
	
	f1 = open_ebi(PHY(cpuwqaddr));

	if(!f1) {
		return;
	}
	//printf("cpuwqaddr: %x, cur_work_offset: %x\n", cpuwqaddr, cur_work_offset);	

	read_struct(&current_work_addr, 4, f1, PHY(cpuwqaddr + cur_work_offset));
	//printf("current_work_addr: %x\n", current_work_addr);

	if(current_work_addr > 0) {
		if(!open_ebi(current_work_addr)) return;
		read_struct(&current_work, 4, open_ebi(current_work_addr), PHY(current_work_addr + work_func_offset));
		printf("Current work(if any): %s\n", lookup(current_work));
	}

	read_struct(&per_cpu_offset, 8, open_ebi(PHY(per_cpu_offset_addr)), PHY(per_cpu_offset_addr));

	//printf("offset of core 0: %x, offset of core 1: %x\n", per_cpu_offset[0], per_cpu_offset[1]);
	cpuwqaddr = cpuwqaddr + per_cpu_offset[0];//pcpu_base_addr - per_cpu_start_addr;
	
	read_struct(&worklistaddr, 4, open_ebi(PHY(cpuwqaddr + worklist_offset)), PHY(cpuwqaddr + worklist_offset));		

	//printf("worklistaddr: %x\n", worklistaddr);
	
	f1 = open_ebi(PHY(worklistaddr));	
	next_entry = worklistaddr;
	do {
		
		read_struct(&workfuncaddr, 4, open_ebi(PHY(next_entry)), PHY(next_entry - work_entry_offset + work_func_offset));
		printf("%d. %s (at 0x%X)\n", ++c, lookup(workfuncaddr), workfuncaddr);
		if(c++ > 100) {
			printf("Too many entries!\n");
			break;
		}
		read_struct(&next_entry, 4, open_ebi(PHY(next_entry)), PHY(next_entry));

	}while(next_entry != worklistaddr);
}

void print_irq_state()
{
	unsigned int desc_size = 128, irqnum, irq_desc_size = 0, irq_count, irq_count_offset, chip, action=0, kstat_irqs_addr=0;
	unsigned int irq_desc = rev_lookup("irq_desc", &irq_desc_size);
	unsigned int h_irq_offset = get_offset_struct("irq_desc", "handle_irq");
	unsigned int irq_num_offset = get_offset_struct("irq_desc", "irq");
	irq_count_offset = get_offset_struct("irq_desc", "irq_count");
	unsigned int irq_chip_offset = get_offset_struct("irq_desc", "chip");
	unsigned int irq_action_offset = get_offset_struct("irq_desc", "action");
	unsigned int action_name_offset = get_offset_struct("((struct irqaction *)0x0)", "name");	
	unsigned int kstat_irqs_offset = get_offset_struct("irq_desc", "kstat_irqs");	
	unsigned int chip_name_offset = get_offset_struct("((struct irq_chip *)0x0)", "name");
	unsigned int irq_desc_entry_size = get_offset_struct("sizeof(irq_desc[0])", "", 1);
	unsigned int name_addr, chip_name_addr;
	unsigned int irq_stats[2];
	char name[48], chip_name[48];

	//printf("IRQ_DESC size = %x, offset = %d, offset2 = %d, actnameoff = %x, irqdescsize = %d\n", desc_size, h_irq_offset, irq_num_offset, action_name_offset, irq_desc_size);

	fstream *f1 = open_ebi(PHY(irq_desc));

	if(!f1) return;

	printf("%4s %10s %10s %30s %10s", "IRQ", "CPU0", "CPU1", "Name", "Chip\n");
	printf("=====================================================================\n");
	for(int i=16*128; i< irq_desc_size; i+=irq_desc_entry_size) {
		
		read_struct(&irqnum, 4, f1, PHY(irq_desc)+i+irq_num_offset);
		read_struct(&irq_count, 4, f1, PHY(irq_desc)+i+irq_count_offset);		
		read_struct(&action, 4, f1, PHY(irq_desc)+i+irq_action_offset); 		
		read_struct(&kstat_irqs_addr, 4, f1, PHY(irq_desc)+i+kstat_irqs_offset); 
		read_struct(&irq_stats, 8, f1, PHY(kstat_irqs_addr)); 	
		read_struct(&chip, 4, f1, PHY(irq_desc)+i+irq_chip_offset); 	
	
		if(!open_ebi(PHY(chip))) 
			return;

		read_struct(&chip_name_addr, 4, open_ebi(PHY(chip)), PHY(chip)+chip_name_offset);
		
		if(!open_ebi(PHY(chip_name_addr)))
			return;
		
		read_struct(&chip_name, 48, open_ebi(PHY(chip_name_addr)), PHY(chip_name_addr));

		if(action != 0) {			
			read_struct(&name_addr, 4, open_ebi(PHY(action)), PHY(action)+action_name_offset);

			if (!open_ebi(PHY(name_addr)))
				return;
			read_struct(&name, 48, open_ebi(PHY(name_addr)), PHY(name_addr));
			printf("%4d %10d %10d %30s %10s\n", irqnum, irq_stats[0], irq_stats[1], name, chip_name);
		}
	}	
}

void print_irq_state_38()
{
	unsigned int per_cpu_offset_addr = rev_lookup("__per_cpu_offset");
	unsigned int desc_size = 128, irqnum, irq_desc_size = 0, irq_count, irq_count_offset, chip, action=0, kstat_irqs_addr=0;
	unsigned int irq_desc = rev_lookup("irq_desc", &irq_desc_size);
	unsigned int h_irq_offset = get_offset_struct("irq_desc", "handle_irq");
	unsigned int irq_num_offset = get_offset_struct("irq_desc", "irq");
	irq_count_offset = get_offset_struct("irq_desc", "irq_count");
	unsigned int irq_chip_offset = get_offset_struct("irq_desc", "chip");
	unsigned int irq_action_offset = get_offset_struct("irq_desc", "action");
	unsigned int action_name_offset = get_offset_struct("((struct irqaction *)0x0)", "name");	
	unsigned int kstat_irqs_offset = get_offset_struct("irq_desc", "kstat_irqs");	
	unsigned int chip_name_offset = get_offset_struct("((struct irq_chip *)0x0)", "name");
	unsigned int irq_desc_entry_size = get_offset_struct("sizeof(irq_desc[0])", "", 1);
	unsigned int name_addr, chip_name_addr;
	unsigned int irq_stats[2];
	char name[48], chip_name[48];
	unsigned int per_cpu_offset1, per_cpu_offset0;

	read_struct(&per_cpu_offset0, 4, open_ebi(PHY(per_cpu_offset_addr)), PHY(per_cpu_offset_addr));
	read_struct(&per_cpu_offset1, 4, open_ebi(PHY(per_cpu_offset_addr)), PHY(per_cpu_offset_addr + 4));
	//printf("IRQ_DESC size = %x, offset = %d, offset2 = %d, actnameoff = %x, irqdescsize = %d\n", desc_size, h_irq_offset, irq_num_offset, action_name_offset, irq_desc_size);

	fstream *f1 = open_ebi(PHY(irq_desc));

	if(!f1) return;

	
	printf("%4s %10s %10s %30s %10s", "IRQ", "CPU0", "CPU1", "Name", "Chip\n");
	printf("=====================================================================\n");
	for(int i=16*128; i< irq_desc_size; i+=irq_desc_entry_size) {
		
		read_struct(&irqnum, 4, f1, PHY(irq_desc)+i+irq_num_offset);
		read_struct(&irq_count, 4, f1, PHY(irq_desc)+i+irq_count_offset);		
		read_struct(&action, 4, f1, PHY(irq_desc)+i+irq_action_offset); 		
		read_struct(&kstat_irqs_addr, 4, f1, PHY(irq_desc)+i+kstat_irqs_offset); 
		read_struct(&irq_stats, 4, f1, PHY(kstat_irqs_addr + per_cpu_offset0)); 	
		read_struct(&irq_stats[1], 4, f1, PHY(kstat_irqs_addr + per_cpu_offset1)); 	
		read_struct(&chip, 4, f1, PHY(irq_desc)+i+irq_chip_offset); 	
		//printf("0, irq_desc + i +action_offset = %x\n", PHY(irq_desc + i + irq_action_offset));
		if(!open_ebi(PHY(chip)))
			return;
		//printf("1\n");
		read_struct(&chip_name_addr, 4, open_ebi(PHY(chip)), PHY(chip)+chip_name_offset);
		
		if(!open_ebi(PHY(chip_name_addr)))
			return;
		
		read_struct(&chip_name, 48, open_ebi(PHY(chip_name_addr)), PHY(chip_name_addr));
//printf("2 action=%x\n", action);
		//if(!open_ebi(PHY(action)))
		//	return;
//printf("3\n");
		if(action != 0) {			
			read_struct(&name_addr, 4, open_ebi(PHY(action)), PHY(action)+action_name_offset);
//printf("4, %x, %x\n", PHY(action), PHY(name_addr));
			if(!open_ebi(PHY(name_addr)))
				return;
//printf("5\n");
			read_struct(&name, 48, open_ebi(PHY(name_addr)), PHY(name_addr));
			printf("%4d %10d %10d %30s %10s\n", irqnum, irq_stats[0], irq_stats[1], name, chip_name);
		}
	}	
}

void print_irq_state_3_0()
{
		unsigned int per_cpu_offset_addr = rev_lookup("__per_cpu_offset");
        unsigned int desc_size = 160, irqnum, irq_desc_size = 0, irq_count, irq_count_offset, chip, action=0, kstat_irqs_addr=0;
        unsigned int irq_desc = rev_lookup("irq_desc", &irq_desc_size);
        unsigned int h_irq_offset = get_offset_struct("irq_desc", "handle_irq");
        unsigned int irq_num_offset = get_offset_struct("((struct irq_data *)0x0)", "irq");
        unsigned int irq_data_offset = get_offset_struct("irq_desc", "irq_data");
        irq_count_offset = get_offset_struct("irq_desc", "irq_count");
        unsigned int irq_chip_offset = get_offset_struct("((struct irq_data *)0x0)", "chip");
        unsigned int irq_action_offset = get_offset_struct("irq_desc", "action");
        unsigned int action_name_offset = get_offset_struct("((struct irqaction *)0x0)", "name");       
        unsigned int kstat_irqs_offset = get_offset_struct("irq_desc", "kstat_irqs");   
        unsigned int chip_name_offset = get_offset_struct("((struct irq_chip *)0x0)", "name");
		unsigned int irq_desc_entry_size = get_offset_struct("sizeof(irq_desc[0])", "", 1);
        unsigned int name_addr, chip_name_addr;
        unsigned int irq_stats[2];
        char name[48], chip_name[48];
        unsigned int per_cpu_offset1, per_cpu_offset0;

       read_struct(&per_cpu_offset0, 4, open_ebi(PHY(per_cpu_offset_addr)), PHY(per_cpu_offset_addr));
        read_struct(&per_cpu_offset1, 4, open_ebi(PHY(per_cpu_offset_addr)), PHY(per_cpu_offset_addr + 4));	
        //printf("IRQ_DESC addr = %x (phy = %x), size = %x, offset = %d, offset2 = %d, actnameoff = %x, irqdescsize = %d\n", irq_desc, PHY(irq_desc), desc_size, h_irq_offset, irq_num_offset, action_name_offset, irq_desc_size);

        fstream *f1 = open_ebi(PHY(irq_desc));

        if(!f1) return;

        printf("%4s %10s %10s %30s %10s", "IRQ", "CPU0", "CPU1", "Name", "Chip\n");
        printf("=====================================================================\n");
        for(int i=0; i< irq_desc_size; i+=irq_desc_entry_size) {
                
                read_struct(&irqnum, 4, f1, PHY(irq_desc)+ i + irq_data_offset + irq_num_offset);
				//printf("irqnum = %x\n", irqnum);
                read_struct(&irq_count, 4, f1, PHY(irq_desc)+i+irq_count_offset);               
                read_struct(&action, 4, f1, PHY(irq_desc)+i+irq_action_offset);                 
                read_struct(&kstat_irqs_addr, 4, f1, PHY(irq_desc)+i+kstat_irqs_offset); 
                read_struct(&irq_stats, 4, f1, PHY(kstat_irqs_addr + per_cpu_offset0));         
                read_struct(&irq_stats[1], 4, f1, PHY(kstat_irqs_addr + per_cpu_offset1));      
                read_struct(&chip, 4, f1, PHY(irq_desc)+i+irq_data_offset+irq_chip_offset);     

                //printf("0, irq_desc + i + irq_chip_offset = %x, chip=%x\n", PHY(irq_desc + i + irq_data_offset + irq_chip_offset),  chip);
                if(!open_ebi(PHY(chip)))
                        return;
                //printf("1\n");
                read_struct(&chip_name_addr, 4, open_ebi(PHY(chip)), PHY(chip)+chip_name_offset);
                
                if(!open_ebi(PHY(chip_name_addr)))
                        return;
                
                read_struct(&chip_name, 48, open_ebi(PHY(chip_name_addr)), PHY(chip_name_addr));
				//printf("2 action=%x\n", action);
                //if(!open_ebi(PHY(action)))
                  //    return;
				//printf("3\n");
                if(action != 0) {                       
                        read_struct(&name_addr, 4, open_ebi(PHY(action)), PHY(action)+action_name_offset);
						//printf("4, %x, %x\n", PHY(action), PHY(name_addr));
                        if(!open_ebi(PHY(name_addr)))
                                return;
						//printf("5\n");
                        read_struct(&name, 48, open_ebi(PHY(name_addr)), PHY(name_addr));
						printf("%4d %10d %10d %30s %10s\n", irqnum, irq_stats[0], irq_stats[1], name, chip_name);
                }
        }       
}

                          

int determine_version()
{
	unsigned int linuxbansym_addr = rev_lookup("linux_banner");
	unsigned int linuxban_addr;
	char linuxban[256];

	fstream *f1 = open_ebi(PHY(linuxbansym_addr));
	
	if(f1) {
		//printf("Couldn't locate the linux banner.\n");
		//exit(0);
		read_struct(linuxban, 256, f1, PHY(linuxbansym_addr));

		//printf("linuxban_address: %x, phy: %x\n", linuxbansym_addr, PHY(linuxbansym_addr));
	
		if(linuxban[0] == 'L' && linuxban[1] == 'i') {
			printf("Linux banner from the ramdump:\n%s", linuxban);			
		} else {
			printf("[F] Error reading linux version. Are you using the right vmlinux? \n");
			cerr << "[F] You've got the wrong vmlinux. I cannot continue, even though the Force is still with me. \n";
			exit(-1);
		}
	} else {
		printf("Couldn't locate the linux banner.\n");
		exit(-1);
	}

	if(linuxban[14] == '3') {
		printf("LINUX VERSION 3.[something]\n");
                linuxversion = 30;
                offsets_required = offsets_required_30;
                 offsets_required_size = sizeof(offsets_required_30)/sizeof(offset_rec);
    } else if(linuxban[19] == '8') {
		printf("LINUX VERSION 2.6.38.[something]\n");
		linuxversion = 38;
		offsets_required = offsets_required_2_6_38;
		offsets_required_size = sizeof(offsets_required_2_6_38)/sizeof(offset_rec);
	} else {
		printf("LINUX VERSION 2.6.35.[something]\n");
		linuxversion = 35;
		offsets_required = offsets_required_2_6_35;
		offsets_required_size = sizeof(offsets_required_2_6_35)/sizeof(offset_rec);
	}

	/* Check if this is 8960 
	f1 = open_ebi(linuxbansym_addr - page_offset + 0x80200000);
	read_struct(linuxban, 256, f1, linuxbansym_addr - page_offset + 0x80200000);	
	
	if(linuxban[0] == 'L' && linuxban[1] == 'i') {
		printf("Linux banner from the 8960 ramdump: %s", linuxban);
		return 0;
	}
	
	// Check if this is 8660 
	f1 = open_ebi(linuxbansym_addr - page_offset + 0x40200000);
	read_struct(linuxban, 256, f1, linuxbansym_addr - page_offset + 0x40200000);

	if(linuxban[0] == 'L' && linuxban[1] == 'i') {
		printf("Linux banner from the 8660 ramdump: %s", linuxban);
		return 0;
	}*/
	return 0;
}

fstream fout;

void create_t32sim_launcher()
{

	char physoff[10];


	sprintf(physoff, "%x", phys_offset+0x4000);

	if (chip == -1)
		return;

	string launch_config = 
		"OS=\nID=T32_1000002\nTMP=C:\\TEMP\nSYS=C:\\T32\nHELP=C:\\T32\\pdf\n\nPBI=SIM\nSCREEN=\nFONT=SMALL\nHEADER=Trace32-ScorpionSimulator\nPRINTER=WINDOWS";

	string startup_script = ("sys.cpu SCORPION\n");
	startup_script += ("sys.u\n");

	for(int i=0; i < ramfiles.size(); i++) {
		size_t szconv;
		char fname[1024];
		char fsize[10];
		char *wname = ramfiles[i].ramfile_name;
		strcpy(fname, wname);
		startup_script += "d.load.binary ";
		
		char temp[20];
		sprintf(temp, "%x", ramfiles[i].range.begin);

		startup_script += fname;
		startup_script += " 0x";
		startup_script += temp;
		startup_script += "\n";
	}
	
	startup_script += string("PER.S.F C15:0x2 %L 0xFFFFC000 0x4000 0x");
	startup_script += string(physoff);
	startup_script += string("\n");
	startup_script += string("mmu.on\n");
	startup_script += string("mmu.scan\n");
	startup_script += string("d.load.elf ");

	startup_script += string(vmlinuxpath);
			
	startup_script += string(" /nocode\n");
	startup_script += string("task.config c:\\t32\\demo\\arm\\kernel\\linux\\linux.t32\n");
	startup_script += string("menu.reprogram c:\\t32\\demo\\arm\\kernel\\linux\\linux.men\n");
	startup_script += string("task.dtask\n");
	startup_script += string("v.v  %ASCII %STRING linux_banner\n");
	string batch_file = "start c:\\t32\\t32MARM.exe -c t32_config.t32, t32_startup_script.cmm";

	fout.open("t32_startup_script.cmm", ios::out);
	fout << startup_script;
	
	if(in_panic) { 
		fout << "do regs_panic.cmm\n";
		fout << "v.f\n";
	}

	fout.close();

	fout.open("t32_config.t32", ios::out);
	fout << launch_config;
	
	fout.close();

	fout.open("launch_t32.bat", ios::out);
	fout << batch_file;
	
	fout.close();

	printf("Created T32 Simulator launcher.\n");
	
}

void create_t32_regs(void)
{
	int core;

	for (core = 0; core <= 1; core++) {
		char fname[20];
		snprintf(fname, sizeof(fname), "regs_core%d.cmm", core);
		fout.open(fname, ios::out);
		fout << "REGISTER.SET PP 0x" << hex << reg_dump.sc_ns[core].mon_lr << endl;
		fout << "REGISTER.SET SPSR 0x" << hex << reg_dump.sc_ns[core].mon_spsr << endl;

		fout << "REGISTER.SET R0 0x" << hex << reg_dump.sc_ns[core].usr_r0 << endl;
		fout << "REGISTER.SET R1 0x" << hex << reg_dump.sc_ns[core].usr_r1 << endl;
		fout << "REGISTER.SET R2 0x" << hex << reg_dump.sc_ns[core].usr_r2 << endl;
		fout << "REGISTER.SET R3 0x" << hex << reg_dump.sc_ns[core].usr_r3 << endl;
		fout << "REGISTER.SET R4 0x" << hex << reg_dump.sc_ns[core].usr_r4 << endl;
		fout << "REGISTER.SET R5 0x" << hex << reg_dump.sc_ns[core].usr_r5 << endl;
		fout << "REGISTER.SET R6 0x" << hex << reg_dump.sc_ns[core].usr_r6 << endl;
		fout << "REGISTER.SET R7 0x" << hex << reg_dump.sc_ns[core].usr_r7 << endl;
		fout << "REGISTER.SET R8 0x" << hex << reg_dump.sc_ns[core].usr_r8 << endl;
		fout << "REGISTER.SET R9 0x" << hex << reg_dump.sc_ns[core].usr_r9 << endl;
		fout << "REGISTER.SET R10 0x" << hex << reg_dump.sc_ns[core].usr_r10 << endl;
		fout << "REGISTER.SET R11 0x" << hex << reg_dump.sc_ns[core].usr_r11 << endl;
		fout << "REGISTER.SET R12 0x" << hex << reg_dump.sc_ns[core].usr_r12 << endl;
		fout << "REGISTER.SET R13 0x" << hex << reg_dump.sc_ns[core].usr_r13 << endl;
		fout << "REGISTER.SET R14 0x" << hex << reg_dump.sc_ns[core].usr_r14 << endl;

		fout << "REGISTER.SET SPSR_IRQ 0x" << hex << reg_dump.sc_ns[core].irq_spsr << endl;
		fout << "REGISTER.SET R13_IRQ 0x" << hex << reg_dump.sc_ns[core].irq_r13 << endl;
		fout << "REGISTER.SET R14_IRQ 0x" << hex << reg_dump.sc_ns[core].irq_r14 << endl;

		fout << "REGISTER.SET SPSR_SVC 0x" << hex << reg_dump.sc_ns[core].svc_spsr << endl;
		fout << "REGISTER.SET R13_SVC 0x" << hex << reg_dump.sc_ns[core].svc_r13 << endl;
		fout << "REGISTER.SET R14_SVC 0x" << hex << reg_dump.sc_ns[core].svc_r14 << endl;

		fout << "REGISTER.SET SPSR_ABT 0x" << hex << reg_dump.sc_ns[core].abt_spsr << endl;
		fout << "REGISTER.SET R13_ABT 0x" << hex << reg_dump.sc_ns[core].abt_r13 << endl;
		fout << "REGISTER.SET R14_ABT 0x" << hex << reg_dump.sc_ns[core].abt_r14 << endl;

		fout << "REGISTER.SET SPSR_UND 0x" << hex << reg_dump.sc_ns[core].und_spsr << endl;
		fout << "REGISTER.SET R13_UND 0x" << hex << reg_dump.sc_ns[core].und_r13 << endl;
		fout << "REGISTER.SET R14_UND 0x" << hex << reg_dump.sc_ns[core].und_r14 << endl;

		fout << "REGISTER.SET SPSR_FIQ 0x" << hex << reg_dump.sc_ns[core].fiq_spsr << endl;
		fout << "REGISTER.SET R8_FIQ 0x" << hex << reg_dump.sc_ns[core].fiq_r8 << endl;
		fout << "REGISTER.SET R9_FIQ 0x" << hex << reg_dump.sc_ns[core].fiq_r9 << endl;
		fout << "REGISTER.SET R10_FIQ 0x" << hex << reg_dump.sc_ns[core].fiq_r10 << endl;
		fout << "REGISTER.SET R11_FIQ 0x" << hex << reg_dump.sc_ns[core].fiq_r11 << endl;
		fout << "REGISTER.SET R12_FIQ 0x" << hex << reg_dump.sc_ns[core].fiq_r12 << endl;
		fout << "REGISTER.SET R13_FIQ 0x" << hex << reg_dump.sc_ns[core].fiq_r13 << endl;
		fout << "REGISTER.SET R14_FIQ 0x" << hex << reg_dump.sc_ns[core].fiq_r14 << endl;

		fout << endl << "ENDDO" << endl;

		fout.close();
	}
}

void determine_hw_version()
{
	unsigned int hw_bytes = 0;
	unsigned int counter = 0;

	fstream *ebics0_file = open_ebi(ebi_start);
	
	do {
		ebics0_file->seekg(counter);
		ebics0_file->read((char *)&hw_bytes, 4);
		
		//if (counter >= 0x4100 && counter <= 0x4200)
			//printf(" %x ", hw_bytes);

		for (int i = 0; i < (sizeof(hw_ids)/sizeof(hw_ids[0])); i++)
			if (hw_bytes == hw_ids[i].hw_ascii_id) {
				printf("Hardware match: %d\n", hw_ids[i].hw_id);
				chip = i;
				if (!custom_phys_offset) {
					printf ("Now setting phys_offset to %x\n", hw_ids[i].assumed_phys_offset);
					phys_offset = hw_ids[i].assumed_phys_offset;
				}
						
				return;
			}
		
		counter ++;
	} while (counter <= 0x200000);

	printf("Couldn't figure out which chip this is.\n");
}


#define sel_strtoul strtoul




#define sel_strcpy strcpy


int parse_arguments(int argc, char* argv[])
{
	int done = 0, i=1;

	if(argc < 6) {
		printf("Need at least one dump file and a vmlinux to proceed.\nPlease check your arguments.\n");
		exit(-1);
	}

	do {	

			int start = i;
			
		if(!strcmp(argv[i], "-e") || !strcmp(argv[i], "-es")) {
			struct stat *stFileInfo = new struct stat;			
			
			if ((i+2) >= argc) {
				printf("Expected ram file and start address after -e.\nPlease check your arguments.\n");
				exit(-1);
			}

			fstream *f1 = new fstream(argv[i+1], ios::in|ios::binary);
			if(!f1->is_open()) {
				printf("Unable to open dump file %s.\nPlease check your arguments.\n", argv[i+1]);
				exit(-1);
			}

			unsigned int begin = sel_strtoul(argv[i+2], 0, 16);

			if(!begin || begin==-1) {
				printf("%s is an invalid range.\nPlease check your arguments.\n", argv[i+2]);
				exit(-1);
			}


			int statRet = stat(argv[i+1], stFileInfo);			
			ramfile_s *rf = new ramfile_s();
			rf->f = f1;
			rf->range.begin = begin;
			
			rf->range.end = begin + stFileInfo->st_size - 1;
			rf->stFileInfo = stFileInfo;

			
			sel_strcpy(rf->ramfile_name, argv[i+1]);


			ramfiles.push_back(*rf);
			printf("RAM file %s representing memory at %x--%x processed.\n", argv[i+1], rf->range.begin, rf->range.end);

			if(!strcmp(argv[i], "-es")) {

				ebi_start = begin;
				done |=4;
			}

			i+=3;
			done |= 1;
         
			delete rf;
         
			continue;
		}


			if(!strcmp(argv[i], "-v")) {


			if ((i+1) >= argc) {
				printf("Expected vmlinux file after -v.\nPlease check your arguments.\n");
				exit(-1);
			}

			fstream *f1 = new fstream(argv[i+1], ios::in|ios::binary);
			if(!f1->is_open()) {
				printf("Unable to open  vmlinux at %s.\nPlease check your arguments.\n", argv[i+1]);
				exit(-1);
			}

			size_t szconv;
			
			strcpy(vmlinuxpath, argv[i+1]);

			snprintf(vmlinux_cmd, 512,
							"%s --numeric-sort %s > System.map.x1234",
							nmpath, vmlinuxpath);

			i+=2;
			done |= 2;
         
			delete f1;
			continue;
		}


				if(!strcmp(argv[i], "-phy")) {

			if ((i+1) >= argc) {
				printf("Expected physical offset after -phy.\nPlease check your arguments.\n");
				exit(-1);
			}

			phys_offset = sel_strtoul(argv[i+1], 0, 16);
			custom_phys_offset = 1;

			if(phys_offset == 0 || phys_offset == -1) {
				printf("Unable to parse physical offset %s.\nPlease check your arguments.\n", argv[i+1]);
				exit(-1);
			}

			i+=2;
			continue;
		}




			if(!strcmp(argv[i], "-offbark")) {

				if ((i+1) >= argc) {
				printf("Expected IMEM offset after -offbark.\nPlease check your arguments.\n");
				exit(-1);
			}

			imem_offset = sel_strtoul(argv[i+1], 0, 16);
			
			if(imem_offset == 0 || imem_offset == -1) {
				printf("Unable to parse physical offset %s.\nPlease check your arguments.\n", argv[i+1]);
				exit(-1);
			}

			i+=2;
			continue;
		}


			if(!strcmp(argv[i], "-page")) {


			if ((i+1) >= argc) {
				printf("Expected page offset after -page.\nPlease check your arguments.\n");
				exit(-1);
			}

			unsigned int page_offset = sel_strtoul(argv[i+1], 0, 16);

			if(page_offset == 0 || page_offset == -1) {
				printf("Unable to parse page offset %s.\nPlease check your arguments.\n", argv[i+1]);
				exit(-1);
			}

			i+=2;
			continue;
		}		

		if (i==start) {
			printf("Unrecognized argument %s.\nPlease check your arguments.\n", argv[i]);
			exit(-1);
		} 

		
	} while(i!=argc);

	if(done!=7) {
			printf("Need atleast a dump file and a vmlinux and an ebi_start (-es) argument.\nPlease check your arguments.\n");
			exit(-1);
	}

	int error=0;
	for(unsigned int i=0; i<ramfiles.size(); i++) {
		for(unsigned int j=0; j<ramfiles.size(); j++) {
			if(i==j)
				continue;
			
			if (ramfiles[i].range.begin == ramfiles[j].range.begin) {
				error=1;
				break;
			}

			if (ramfiles[i].range.begin == ramfiles[j].range.begin) {
				error = 1;
				break;
			}

			if (ramfiles[i].range.begin == ramfiles[j].range.end) {
				error = 1;
				break;
			}

			if (ramfiles[i].range.end == ramfiles[j].range.begin) {
				error = 1;
				break;
			}

			if (ramfiles[i].range.begin < ramfiles[j].range.begin) {				
				if (!(ramfiles[i].range.end < ramfiles[j].range.begin)) {
					error = 1;
					break;
				}
			}

			if (ramfiles[j].range.begin < ramfiles[i].range.begin) {				
				if (!(ramfiles[j].range.end < ramfiles[i].range.begin)) {
					error = 1;
					break;
				}
			}
		}
	}

	if (error) {
		printf("Overlapping or invalid memory ranges specified for ram files.\nPlease check your arguments.\n");
		exit(-1);
	}

	return 0;
}

int open_ebi_ex(unsigned int offset, fstream **f, unsigned int * begin) {

	for(unsigned int i=0; i<ramfiles.size(); i++)
		if(offset >= ramfiles[i].range.begin &&  offset <= ramfiles[i].range.end) {
			if (begin)
				*begin = ramfiles[i].range.begin;
			if (f)
				*f = ramfiles[i].f;
			return 0;
		}

	return -1;
}

void cleanup_ramfiles(void)
{
	ramfile_s rf;

	while (!ramfiles.empty()) {
		rf = ramfiles.back();
		delete rf.stFileInfo;
		delete rf.f;
		ramfiles.pop_back();
	}
}

fstream *open_ebi(unsigned int offset)
{
	fstream *f;

	if (open_ebi_ex(offset, &f, NULL) == 0)
		return f;

	return NULL;
}

unsigned int get_real_offset(unsigned int offset)
{
	for(unsigned int i=0; i<ramfiles.size(); i++)
		if(offset >= ramfiles[i].range.begin &&  offset <= ramfiles[i].range.end)
			return offset - ramfiles[i].range.begin;

	return 0;
}




int main(int argc, char* argv[])
{
	unsigned int ebi_address = 0;
	unsigned int pc_value = 0;
	size_t szconv;
	char gdb_cmd[1024];
	fstream cf;
	int count = 0, no_tz = 0;

	

	FILE *f = fopen("raw_stack_dumps.txt", "w");

	if(!f){
		cout << "Couldn't create a file in the current folder. Please run this tool from a place where it can create files.";
		exit(-1);
	}
	
	fclose(f);


	printf("Booting up.\n");
	printf("Parsing arguments.\n");

	parse_arguments(argc, argv);
	
	printf("------------------------- Begin sanity information -------------------------\n");

	determine_hw_version();

	store_page_tables();

	printf("Page tables retrieved.\n");

	load_symbols();
	
	printf("Symbols retrieved.\n");
	
	load_main_unwind_table();

	printf("Unwind table retrieved.\n");

	determine_version();	

	//get_virt(get_phys(0xDFD50000));
	//get_virt(get_phys(0xE2500000));
	printf("Filling offset map now.\n");
	fill_offset_map();
	printf("Structure offsets retrieved.\n");

	printf("Done with sanity checks.\n");

	printf("-------------------------- End sanity information --------------------------\n");

	check_for_panic();

	create_t32sim_launcher();
	
	do_TZ_dump();

	create_t32_regs();

	do_dump_stacks(1);

	printf("Extracting kernel log buffer content now.\n");

	dump_logbuf();	

	cout << "\n\n";
	printf("=========================== IRQ STATE ===============================\n");
	if(linuxversion == 35)		
		print_irq_state();
	else if (linuxversion == 38)
		print_irq_state_38();
	else if (linuxversion == 30)                
		print_irq_state_3_0();

	cout << "\n";
	printf("======================= WORKQUEUE STATE ============================\n");
	if(linuxversion == 35)		
		print_workqueue_state();
	else if (linuxversion == 38)
		print_workqueue_state_38();
	else if (linuxversion == 30)                
		print_workqueue_state_38();
   
	cleanup_ramfiles();
	delete [] unwind_table;
   
	return 0;
}
