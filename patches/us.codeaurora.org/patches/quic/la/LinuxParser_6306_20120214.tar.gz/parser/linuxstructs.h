/* Copyright (c) 2011, Code Aurora Forum. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 and
 * only version 2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef _LINUX_STRUCTS
#define _LINUX_STRUCTS

#include <fstream>
using namespace std;

typedef unsigned int __u32;

struct cpu_context_save {
    __u32   r4;
    __u32   r5;
    __u32   r6;
    __u32   r7;
    __u32   r8;
    __u32   r9;
    __u32   sl;
    __u32   fp;
    __u32   sp;
    __u32   pc;
    __u32   extra[2];               /* Xscale 'acc' register, etc */
};

struct task_struct {
    volatile long state;    /* -1 unrunnable, 0 runnable, >0 stopped */
    void *stack;
};

struct thread_info {
    unsigned int           flags;          /* low level flags */
    int                     preempt_count;  /* 0 => preemptable, <0 => bug */
    unsigned int            addr_limit;     /* address limit */
    //struct task_struct      *task;          /* main task structure */
    unsigned int task;
    //void      *exec_domain;   /* execution domain */
	unsigned int exec_domain;   /* execution domain */
    unsigned int                   cpu;            /* cpu */
    unsigned int                   cpu_domain;     /* cpu domain */
    struct cpu_context_save cpu_context;    /* cpu context */
    unsigned int                   syscall;        /* syscall number */
    unsigned char                    used_cp[16];    /* thread used copro */
    unsigned int           tp_value;
    /*struct crunch_state     crunchstate;
     *  union fp_state          fpstate __attribute__((aligned(8)));
     *  union vfp_state         vfpstate;
     *  #ifdef CONFIG_ARM_THUMBEE
     *  unsigned int           thumbee_state;
     *  #endif
     *  struct restart_block    restart_block;*/
};

#define core_kernel_text(X) X
#define kernel_text_address(X) X
//struct task_struct *current;

struct stackframe {
    unsigned int fp;
    unsigned int sp;
    unsigned int lr;
    unsigned int pc;
};

enum regs {
    FP = 11,
    SP = 13,
    LR = 14,
    PC = 15
};

struct list_head {
    //struct list_head *next, *prev;
    unsigned int next;
    unsigned int prev;
};

enum unwind_reason_code {
    URC_OK = 0,         /* operation completed successfully */
    URC_CONTINUE_UNWIND = 8,
    URC_FAILURE = 9         /* unspecified failure of some kind */
};

struct unwind_idx {
    unsigned int addr;
    unsigned int insn;
	unsigned int addr_idx;
};

struct unwind_table {
    struct list_head list;
    //struct unwind_idx *start;
    //struct unwind_idx *stop;
    unsigned int unwind_idx_start_p;
    unsigned int unwind_idx_stop_p;
    unsigned int begin_addr;
    unsigned int end_addr;
};

struct unwind_ctrl_block {
    unsigned int vrs[16];      /* virtual register set */
    unsigned int insn;        /* pointer to the current instructions word */
    int entries;            /* number of entries left to interpret */
    int byte;           /* current byte number in the instructions word */
};

#define THREAD_SIZE 8192
#define TZBSP_SC_STATUS_NS      0x01
#define TZBSP_SC_STATUS_WDT     0x02
#define TZBSP_SC_STATUS_SGI     0x04

#define THREAD_SIZE 8192

#define PAGE_OFFSET 0xC0000000
#define PHYS_OFFSET 0x40200000

unsigned int get_phys(unsigned int);
unsigned int get_virt(unsigned int);

#define PHY(x) get_phys(x)//((x - page_offset) + phys_offset)
#define VIRT(x) get_virt(x)//((x - phys_offset) + page_offset)
#define EBI_OFF(x) ((x & 0x0FFFFFFF))

fstream *open_ebi(unsigned int address);
void *read_struct(void *buf, int size, fstream *file, int offset);
char * lookup(unsigned int addr, int *offset);

#endif
