/*
 * Copyright (C) 2010 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 *
 * Copyright (c) 2013, The Linux Foundation. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above
 *       copyright notice, this list of conditions and the following
 *       disclaimer in the documentation and/or other materials provided
 *       with the distribution.
 *     * Neither the name of The Linux Foundation nor the names of its
 *       contributors may be used to endorse or promote products derived
 *       from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 * BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <fcntl.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <cutils/memory.h>

#include <utils/Log.h>

#include <binder/IPCThreadState.h>
#include <binder/ProcessState.h>
#include <binder/IServiceManager.h>

#include <gui/Surface.h>
#include <gui/ISurface.h>
#include <gui/SurfaceComposerClient.h>
#include <gralloc_priv.h>

using namespace android;

namespace android {
};

#define MSMVFB_WAIT_UPDATE	_IOW('F', 325, int)

int main(int argc, char** argv)
{	
    int result = 0;
    status_t err;

    // create a client to surfaceflinger
    sp<SurfaceComposerClient> client = new SurfaceComposerClient();

    ALOGD("[hk] createSurface\n");
    sp<SurfaceControl> surfaceControl1 = client->createSurface(String8("Test Surface"), 1920, 1080, HAL_PIXEL_FORMAT_RGBA_8888, 0);

    Parcel parcel1;
    SurfaceControl::writeSurfaceToParcel(surfaceControl1, &parcel1);
    parcel1.setDataPosition(0);
    sp<Surface> surface1 = Surface::readFromParcel(parcel1);

    sp<ANativeWindow> window1 = surface1.get();

    ALOGD("set GRALLOC_USAGE_EXTERNAL_VIRTUALFB\n");
    err  = native_window_set_usage(window1.get(), GRALLOC_USAGE_HW_TEXTURE | GRALLOC_USAGE_EXTERNAL_VIRTUALFB);
    if(err == 0)
    {
        ALOGE("native_window_set_usage success");
    }
    else
    {
        ALOGE("native_window_set_usage failed: %s (%d)", strerror(-err), -err);
    }
    err = native_window_set_buffer_count(window1.get(), 3);
    if(err != 0)
        ALOGE("set_buffer_count failed..!!");

    ALOGD("[hk] setLayer, setPosition\n");
    client->openGlobalTransaction();

    surfaceControl1->setLayer(300000);
    surfaceControl1->setPosition(0, 0);
    client->closeGlobalTransaction();

    unsigned int color[4];
    color[0] = 0xFF0000FF;
    color[1] = 0xFF00FF00;
    color[2] = 0xFFFF0000;
    color[3] = 0xFFFF00FF;

    ssize_t bpr;
    int fd;
    int update;

    fd = open("/dev/graphics/fb3", O_RDWR);

    for (int i=0 ; i < 3; i++) {
        Surface::SurfaceInfo info1;
        surface1->lock(&info1);
        bpr = info1.s * bytesPerPixel(HAL_PIXEL_FORMAT_RGBA_8888);
        android_memset32((uint32_t*)info1.bits, 0xffffffff, bpr*info1.h);
        surface1->unlockAndPost();
    }
    //char dumpFilename[128];
    //int count =0;
    while(1) {
        Surface::SurfaceInfo info1;
        surface1->lock(&info1);

        printf("Waiting update !!!\n");
        ioctl(fd, MSMVFB_WAIT_UPDATE, &update);

        //ssize_t bpr = info1.s * bytesPerPixel(info1.format);
        //ALOGE(" TEst app running.. bpr = %d height = %d size = %d",
        //                                 (int)bpr ,(int) info1.h, (uint32_t)(bpr * info1.h));
        ////Write the Ubuntu frame to a file
        //sprintf(dumpFilename, "/data/ubuntu%d.raw",count++);
        //count = count%3;
        //FILE* fp = fopen(dumpFilename, "w+");
        //if (NULL != fp) {
        //    result = (bool) fwrite((void*)info1.bits, (bpr * info1.h), 1, fp);
        //    fclose(fp);
        //}
        
        printf("updated !!!\n");
        
        surface1->unlockAndPost();
    }

    close(fd);

    return 0;
}
