Steps to apply the patches
========================
1) Copy opencore.patch to <root>/android/
2) cd <root>/android
3) patch -p1 < kernel_rxmute.patch
4) patch -p1 < userspace_rxmute.patch

The patches modifies the following files,

userspace_rxmute.patch

/hardware/msm7k/libaudio-qsd8k/AudioHardware.cpp

kernel_rxmute.patch

/kernel/arch/arm/mach-msm/include/mach/msm_qdsp6_audio.h
/kenrel/arch/arm/mach-msm/qdsp6/audio_ctl.c
/kernel/arch/arm/mach-msm/qdsp6/q6audio.c


Note : If you see any issue while applying the patch, please manualy apply the changes.
