/* Copyright (c) 2009, Code Aurora Forum. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of Code Aurora Forum nor
 *       the names of its contributors may be used to endorse or promote
 *       products derived from this software without specific prior written
 *       permission.
 *
 * Alternatively, provided that this notice is retained in full, this software
 * may be relicensed by the recipient under the terms of the GNU General Public
 * License version 2 ("GPL") and only version 2, in which case the provisions of
 * the GPL apply INSTEAD OF those given above.  If the recipient relicenses the
 * software under the GPL, then the identification text in the MODULE_LICENSE
 * macro must be changed to reflect "GPLv2" instead of "Dual BSD/GPL".  Once a
 * recipient changes the license terms to the GPL, subsequent recipients shall
 * not relicense under alternate licensing terms, including the BSD or dual
 * BSD/GPL terms.  In addition, the following license statement immediately
 * below and between the words START and END shall also then apply when this
 * software is relicensed under the GPL:
 *
 * START
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 2 and only version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 * END
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 */


#include <linux/delay.h>
#include <linux/types.h>
#include <linux/i2c.h>
#include <linux/uaccess.h>
#include <linux/miscdevice.h>
#include <linux/kernel.h>
#include <media/msm_camera.h>
#include <mach/gpio.h>
#include <mach/camera.h>
#include "t8et5.h"

/*=============================================================
	SENSOR REGISTER DEFINES
==============================================================*/
#define Q8                                         0x00000100
#define Q10                                        0x00000400
typedef unsigned char byte;

#define T8ET5_MODEL_ID                             0x28
#define T8ET5_AF_I2C_SLAVE_ID                      (0x18 >> 1)

/* T8ET5 product ID register address */
/* toshiba t8et5 version ID register address */
#define T8ET5_REG_MODEL_ID                         0x3A

/* Time in milisecs for waiting for the sensor to reset */
#define T8ET5_RESET_DELAY_MSECS                    66
#define T8ET5_DEFAULT_CLOCK_RATE                   24000000

/* Registers*/
#define T8ET5_GAIN_MSB                             0x03
#define T8ET5_GAIN_LSB                             0x04

#define T8ET5_AEC_MSB                              0x01
#define T8ET5_AEC_LSB                              0x02

/* Register Update Delay in ms */
#define T8ET5_REGISTER_UPDATE_DELAY                300
/*----------------------------------------------------------------------------
                        Test Pattern
----------------------------------------------------------------------------*/
/* Color bar pattern selection */
#define T8ET5_COLOR_BAR_PATTERN_SEL_REG            0x313f
/* Color bar enabling control */
#define T8ET5_COLOR_BAR_ENABLE_REG                 0x3150

#define T8ET5_FULL_SIZE_WIDTH                      2608
#define T8ET5_FULL_SIZE_HEIGHT                     1960
#define T8ET5_QTR_SIZE_WIDTH                       868
#define T8ET5_QTR_SIZE_HEIGHT                      652

#define T8ET5_HRZ_FULL_BLK_PIXELS                  646
#define T8ET5_VER_FULL_BLK_LINES                   52
#define T8ET5_HRZ_QTR_BLK_PIXELS                   2386
#define T8ET5_VER_QTR_BLK_LINES                    118

/* AF Total steps parameters */
#define T8ET5_STEPS_NEAR_TO_CLOSEST_INF            50
#define T8ET5_TOTAL_STEPS_NEAR_TO_FAR              50
/* AF Tuning Parameters */
#define T8ET5_DAMPING_THRESHOLD                    10
#define T8ET5_DAMPING_COARSE_STEP                  4
#define T8ET5_DAMPING_FINE_STEP                    10
#define T8ET5_HW_DAMPING                           0
#define TRUE                                       1
#define FALSE                                      0
/*============================================================================
                             TYPE DECLARATIONS
============================================================================*/

/* 16bit address - 8 bit context register structure */
typedef struct reg_addr_val_pair_struct
{
  uint16_t  reg_addr;
  byte reg_val;
} reg_struct_type;

enum t8et5_test_mode_t {
	TEST_OFF,
	TEST_1,
	TEST_2,
	TEST_3
};

enum t8et5_resolution_t {
	QTR_SIZE,
	FULL_SIZE,
	INVALID_SIZE
};

/*============================================================================
                        EXTERNAL VARIABLES DECLARATIONS
============================================================================*/
static uint16_t t8et5_focus_debug = 0;//FALSE;
static uint16_t t8et5_use_default_damping = 1;//TRUE;
static uint16_t t8et5_use_threshold_damping = 1;//TRUE;   //set to FALSE if too slow
uint16_t t8et5_step_pos_tbl[T8ET5_TOTAL_STEPS_NEAR_TO_FAR + 1];
static void t8et5_setup_af_tbl(void);

static uint16_t stored_gain = 0;
static uint32_t stored_line_length_ratio = 1 * Q8;

/* FIXME: Changes from here */
struct t8et5_work_t {
	struct work_struct work;
};

static struct  t8et5_work_t *t8et5_sensorw;
static struct  i2c_client *t8et5_client;

struct t8et5_ctrl_t {
	const struct  msm_camera_sensor_info *sensordata;

	uint32_t sensormode;
	uint32_t fps_divider; 		/* init to 1 * 0x00000400 */
	uint32_t pict_fps_divider; 	/* init to 1 * 0x00000400 */
	uint16_t fps;

	int16_t  curr_lens_pos;
	uint16_t curr_step_pos;
	uint16_t my_reg_gain;
	uint32_t my_reg_line_count;
	uint16_t total_lines_per_frame;

	enum t8et5_resolution_t prev_res;
	enum t8et5_resolution_t pict_res;
	enum t8et5_resolution_t curr_res;
	enum t8et5_test_mode_t  set_test;

	unsigned short imgaddr;
};

static struct t8et5_ctrl_t *t8et5_ctrl;
static DECLARE_WAIT_QUEUE_HEAD(t8et5_wait_queue);
DECLARE_MUTEX(t8et5_sem);

/*=============================================================*/

/*  70MHz PCLK @ 24MHz MCLK */
static reg_struct_type t8et5_init_settings_array[] =
{
	{0x00, 0x01}, //MODE_SEL / VREVON / HREVON / SWRST / GRHOLD /(2)/(1)/OUT_FORMAT;
	{0x01, 0x02}, //INTGTIM[15:8];
	{0x02, 0x10}, //INTGTIM[7:0];
	{0x03, 0x00}, //(7)/(6)/(5)/(4)/ ANAGAIN[11:8];
	{0x04, 0x20}, //ANAGAIN[7:0];
	{0x05, 0x01}, //(7)/(6)/(5)/(4)/(3)/(2)/ MWBGAINGR[9:8];
	{0x06, 0x00}, //MWBGAINGR[7:0];
	{0x07, 0x01}, //(7)/(6)/(5)/(4)/(3)/(2)/ MWBGAINR[9:8];
	{0x08, 0x00}, //MWBGAINR[7:0];
	{0x09, 0x01}, //(7)/(6)/(5)/(4)/(3)/(2)/ MWBGAINB[9:8];
	{0x0A, 0x00}, //MWBGAINB[7:0];
	{0x0B, 0x01}, //(7)/(6)/(5)/(4)/(3)/(2)/ MWBGAINBR[9:8];
	{0x0C, 0x00}, //MWBGAINBR[7:0];
	{0x0D, 0x40}, //(7)/ PIXCKDIV[2:0] /(4)/ SYSCKDIV[2:0];
	{0x0E, 0x01}, //(7)/(6)/(5)/(4)/(3)/(2)/ PRECKDIV[1:0];
	{0x0F, 0x00}, //(7)/(6)/(5)/(4)/(3)/ OPSYSDIV[2:0];
	{0x10, 0x00}, //(7)/(6)/(5)/(4)/(3)/(2)/(1) PLLMULT[8];
	{0x11, 0x32}, //PLLMULT[7:0];
	{0x12, 0x03}, //TTLLINE[15:8];
	{0x13, 0x02}, //TTLLINE[7:0];
	{0x14, 0x0C}, //(7)/(6)/ TTLDOT[13:8];
	{0x15, 0xB6}, //TTLDOT[7:0];
	{0x16, 0x00}, //--;
	{0x17, 0x00}, //--;
	{0x18, 0x00}, //--;
	{0x19, 0x00}, //--;
	{0x1A, 0x00}, //--;
	{0x1B, 0x00}, //--;
	{0x1C, 0x00}, //--;
	{0x1D, 0x00}, //--;
	{0x1E, 0x03}, //(7)/(6)/(5)/(4)/ HOUTSIZ[11:8];
	{0x1F, 0x64}, //HOUTSIZ[7:0];
	{0x20, 0x02}, //(7)/(6)/(5)/(4)/(3)/ VOUTSIZ[10:8];
	{0x21, 0x8C}, //VOUTSIZ[7:0];
	{0x22, 0x82}, //HANABIN /(6)/(5)/(4)/(3)/ VMONI[2:0];
	{0x23, 0x01}, //(7)/(6)/(5)/(4)/(3)/(2)/ SCALMODE[1:0];
	{0x24, 0x18}, //MVALUE[7:0];
	{0x25, 0x00}, //--;
	{0x26, 0x02}, //TPAT_SEL[2:0]/(4)/(3)/(2)/ TPAT_R[9:8];
	{0x27, 0xC0}, //TPAT_R[7:0];
	{0x28, 0x02}, //(7)/(6)/(5)/(4)/(3)/(2)/ TPAT_GR[9:8];
	{0x29, 0xC0}, //TPAT_GR[7:0];
	{0x2A, 0x02}, //(7)/(6)/(5)/(4)/(3)/(2)/ TPAT_B[9:8];
	{0x2B, 0xC0}, //TPAT_B[7:0];
	{0x2C, 0x02}, //(7)/(6)/(5)/(4)/(3)/(2)/ TPAT_GB[9:8];
	{0x2D, 0xC0}, //TPAT_GB[7:0];
	{0x2E, 0x00}, //(7)/(6)/(5)/(4)/ CURHW[11:8];
	{0x2F, 0x00}, //CURHW[7:0];
	{0x30, 0x00}, //(7)/(6)/(5)/(4)/ CURHST[11:8];
	{0x31, 0x00}, //CURHST[7:0];
	{0x32, 0x00}, //(7)/(6)/(5)/(4)/(3)/ CORVW[10:8];
	{0x33, 0x00}, //CORVW[7:0];
	{0x34, 0x00}, //(7)/(6)/(5)/(4)/(3)/ CURVST[10:8];
	{0x35, 0x00}, //CURVST[7:0];
	{0x36, 0x00}, //(7)/(6)/(5)/(4)/ ANA_GA_MIN[11:8];
	{0x37, 0x00}, //ANA_GA_MIN[7:0];
	{0x38, 0x00}, //(7)/(6)/(5)/(4)/ ANA_GA_MAX[11:8];
	{0x39, 0x00}, //ANA_GA_MAX[7:0];
	{0x3A, 0x00}, //VerNUM[7:5];
	{0x3B, 0x00}, //--;
	{0x3C, 0x00}, //--;
	{0x3D, 0x00}, //--;
	{0x3E, 0x00}, //--;
	{0x3F, 0x00}, //--;
	{0x40, 0xC8}, //--;
	{0x41, 0x63}, //--;
	{0x42, 0x35}, //--;
	{0x43, 0x26}, //--;
	{0x44, 0x23}, //--;
	{0x45, 0x0A}, //--;
	{0x46, 0x20}, //--;
	{0x47, 0x0C}, //--;
	{0x48, 0x03}, //--;
	{0x49, 0x00}, //--;
	{0x4A, 0x00}, //--;
	{0x4B, 0x00}, //--;
	{0x4C, 0x00}, //--;
	{0x4D, 0x00}, //--;
	{0x4E, 0x00}, //--;
	{0x4F, 0x00}, //--;
	{0x50, 0x04}, //--;
	{0x51, 0x84}, //--;
	{0x52, 0x34}, //--;
	{0x53, 0x14}, //--;
	{0x54, 0x34}, //--;
	{0x55, 0x68}, //--;
	{0x56, 0x05}, //--;
	{0x57, 0x40}, //--;
	{0x58, 0x00}, //--;
	{0x59, 0x34}, //--;
	{0x5A, 0x66}, //--;
	{0x5B, 0x00}, //--;
	{0x5C, 0x00}, //--;
	{0x5D, 0x12}, //--;
	{0x5E, 0x46}, //--;
	{0x5F, 0x69}, //--;
	{0x60, 0x78}, //--;
	{0x61, 0x05}, //--;
	{0x62, 0x40}, //--;
	{0x63, 0xC2}, //--;
	{0x64, 0x82}, //--;
	{0x65, 0xAA}, //--;
	{0x66, 0x00}, //--;
	{0x67, 0x00}, //--;
	{0x68, 0x20}, //--;
	{0x69, 0x08}, //--;
	{0x6B, 0x00}, //--;
	{0x6C, 0x00}, //--;
	{0x6D, 0x00}, //--;
	{0x6E, 0x00}, //--;
	{0x6F, 0x00}, //--;
	{0x70, 0x30}, //--;
	{0x71, 0x80}, //--;
	{0x72, 0x00}, //--;
	{0x73, 0xC0}, //WBPCMODE/BBPCMOED/(5)/(4)/(3)/(2)/(1)/ABPCTH;
	{0x74, 0x03}, //BBPCLV[7:0]; 0x10
	{0x75, 0x03}, //WBPCLV[7:0]; 0x10
	{0x76, 0x00}, //--;
	{0x77, 0x00}, //--;
	{0x78, 0x00}, //--;
	{0x79, 0x00}, //--;
	{0x7A, 0x00}, //--;
	{0x7B, 0x00}, //--;
	{0x7C, 0x5F}, //--;
	{0x7D, 0x0F}, //LSSCON ///(4)/;
	{0x7E, 0x00}, //LSHGA[3:0] / LSVGA[3:0];
	{0x7F, 0x00}, //LSHOFS[7:0];
	{0x80, 0x00}, //LSVOFS[7:0];
	{0x81, 0x00}, //LSALGR[7:0];
	{0x82, 0x00}, //LSALGB[7:0];
	{0x83, 0x00}, //LSALR[7:0];
	{0x84, 0x00}, //LSALB[7:0];
	{0x85, 0x00}, //LSARGR[7:0];
	{0x86, 0x00}, //LSARGB[7:0];
	{0x87, 0x00}, //LSARR[7:0];
	{0x88, 0x00}, //LSARB[7:0];
	{0x89, 0x00}, //LSAUGR[7:0];
	{0x8A, 0x00}, //LSAUGB[7:0];
	{0x8B, 0x00}, //LSAUR[7:0];
	{0x8C, 0x00}, //LSAUB[7:0];
	{0x8D, 0x00}, //LSADGR[7:0];
	{0x8E, 0x00}, //LSADGB[7:0];
	{0x8F, 0x00}, //LSADR[7:0];
	{0x90, 0x00}, //LSADB[7:0];
	{0x91, 0x00}, //LSBLGR[7:0];
	{0x92, 0x00}, //LSBLGB[7:0];
	{0x93, 0x00}, //LSBLR[7:0];
	{0x94, 0x00}, //LSBLB[7:0];
	{0x95, 0x00}, //LSBRGR[7:0];
	{0x96, 0x00}, //LSBRGB[7:0];
	{0x97, 0x00}, //LSBRR[7:0];
	{0x98, 0x00}, //LSBRB[7:0];
	{0x99, 0x00}, //LSCUGR[7:0];
	{0x9A, 0x00}, //LSCUGB[7:0];
	{0x9B, 0x00}, //LSCUR[7:0];
	{0x9C, 0x00}, //LSCUB[7:0];
	{0x9D, 0x00}, //LSCDGR[7:0];
	{0x9E, 0x00}, //LSCDGB[7:0];
	{0x9F, 0x00}, //LSCDR[7:0];
	{0xA0, 0x00}, //LSCDB[7:0];
	{0xA1, 0x00}, //LSDLGR[7:0];
	{0xA2, 0x00}, //LSDLGB[7:0];
	{0xA3, 0x00}, //LSDLR[7:0];
	{0xA4, 0x00}, //LSDLB[7:0];
	{0xA5, 0x00}, //LSDRGR[7:0];
	{0xA6, 0x00}, //LSDRGB[7:0];
	{0xA7, 0x00}, //LSDRR[7:0];
	{0xA8, 0x00}, //LSDRB[7:0];
	{0xA9, 0x00}, //LSEUGR[7:0];
	{0xAA, 0x00}, //LSEUGB[7:0];
	{0xAB, 0x00}, //LSEUR[7:0];
	{0xAC, 0x00}, //LSEUB[7:0];
	{0xAD, 0x00}, //LSEDGR[7:0];
	{0xAE, 0x00}, //LSEDGB[7:0];
	{0xAF, 0x00}, //LSEDR[7:0];
	{0xB0, 0x00}, //LSEDB[7:0];
	{0xB1, 0x00}, //--;
	{0xB2, 0x00}, //--;
	{0xB3, 0x00}, //--;
	{0xB4, 0x00}, //--;
	{0xB5, 0x00}, //--;
	{0xB6, 0x00}, //--;
	{0xB7, 0xFF}, //--;
	{0xB8, 0x00}, //--;
	{0xB9, 0x00}, //--;
	{0xBA, 0x00}, //--;
	{0xBB, 0x00}, //--;
	{0xBC, 0x00}, //--;
	{0xBD, 0x00}, //--;
	{0xBE, 0x00}, //--;
	{0xBF, 0x00}, //--;
	{0xC0, 0x80}, //--;
	{0xC1, 0x00}, //--;
	{0xC2, 0x44}, //(7)/(6)/(5)/(4)/(3)/ MIPI1L /(1)/(0);
	{0xC3, 0x04}, //--;
	{0xC4, 0x03}, //(7)/(6)/(5)/(4)/(3)/(2)/ PARALLEL_OUT_SW[1:0];
	{0xC5, 0x78}, //--;
	{0xC6, 0x95}, //--;
	{0xC7, 0x55}, //--;
	{0xC8, 0x56}, //--;
	{0xC9, 0xA7}, //--;
	{0xCA, 0x04}, //(7)/(6)/(5)/(4)/(3)/ PARALLEL_MODE /(1)/(0);
	{0xCB, 0x00}, //--;
	{0xCC, 0x11}, //FS_CODE[7:0];
	{0xCD, 0x44}, //FE_CODE[7:0];
	{0xCE, 0x22}, //LS_CODE[7:0];
	{0xCF, 0x33}, //LE_CODE[7:0];
	{0xD0, 0x30}, //--;
	{0xD1, 0x00}, //--;
	{0xD2, 0x01}, //--;
	{0xD3, 0x00}, //--;
	{0xD4, 0x00}, //--;
	{0xD5, 0x00}, //--;
	{0xD6, 0x00}, //--;
	{0xD7, 0x10}, //--;
	{0xD8, 0xFF}, //--;
	{0xD9, 0x00}, //--;
	{0xDA, 0x10}, //--;
	{0xDB, 0xFF}, //--;
	{0xDC, 0x81}, //--;
	{0xDD, 0x00}, //--;
	{0xDE, 0x00}, //--;
	{0xDF, 0x00}, //--;
	{0xE0, 0x01}, //--;
	{0xE1, 0x00}, //--;
	{0xE2, 0x00}, //--;
	{0xE3, 0x00}, //--;
	{0xE4, 0x00}, //--;
	{0xE5, 0x00}, //--;
	{0xE6, 0x00}, //--;
	{0xE7, 0x00}, //--;
	{0xE8, 0x00}, //--;
	{0xE9, 0x00}, //--;
	{0xEA, 0x00}, //--;
	{0xEB, 0x00}, //--;
	{0xEC, 0x00}, //--;
	{0xED, 0x00}, //--;
	{0xEE, 0x00}, //--;
	{0xEF, 0x00}, //--;
	{0xF0, 0x90}, //--;
	{0xF1, 0x00}, //--;
	{0xF2, 0x54}, //--;
	{0xF3, 0x00}, //--;
	{0xF4, 0x00}, //--;
	{0xF5, 0x00}, //--;
	{0xF6, 0x80}, //--;
	{0xF7, 0x00}, //--;
	{0xF8, 0x00}, //--;
	{0xF9, 0x00}, //--;
	{0xFA, 0x00}, //--;
	{0xFB, 0x00}, //--;
	{0xFC, 0x00}, //--;
	{0xFD, 0x00}, //--;
	{0xFE, 0x00}, //--;
	{0xFF, 0x00}, //--;
	{0x00, 0x81}, //MODE_SEL / VREVON / HREVON / SWRST / GRHOLD /(2)/(1)/OUT_FORMAT;,
};


/* 864x656; 24MHz MCLK 70MHz PCLK*/
static reg_struct_type t8et5_qtr_settings_array[] =
{
  {0x12,0x03},//TTLLINE[15:8];
  {0x13,0x02},//TTLLINE[7:0];
  {0x14,0x0C},//(7)/(6)/ TTLDOT[13:8];
  {0x15,0xB6},//TTLDOT[7:0];
  {0x1E,0x03},//(7)/(6)/(5)/(4)/ HOUTSIZ[11:8];
  {0x1F,0x64},//HOUTSIZ[7:0];
  {0x20,0x02},//(7)/(6)/(5)/(4)/(3)/ VOUTSIZ[10:8];
  {0x21,0x8C},//VOUTSIZ[7:0];
  {0x22,0x82},//HANABIN /(6)/(5)/(4)/(3)/ VMONI[2:0];
  {0x23,0x01},//(7)/(6)/(5)/(4)/(3)/(2)/ SCALMODE[1:0];
  {0x24,0x18},//MVALUE[7:0];
};

/* 2592x1968 Sensor Raw; 24MHz MCLK 70MHz PCLK*/
static reg_struct_type t8et5_full_settings_array[] =
{
  {0x12,0x07},//TTLLINE[15:8];
  {0x13,0xDC},//TTLLINE[7:0];
  {0x14,0x0c},//(7)/(6)/ TTLDOT[13:8]; 0xc 0xb
  {0x15,0xb6},//TTLDOT[7:0]; 0xb6 0x5c
  {0x1E,0x0A},//(7)/(6)/(5)/(4)/ HOUTSIZ[11:8];
  {0x1F,0x30},//HOUTSIZ[7:0];
  {0x20,0x07},//(7)/(6)/(5)/(4)/(3)/ VOUTSIZ[10:8];
  {0x21,0xA8},//VOUTSIZ[7:0];
  {0x22,0x00},//HANABIN /(6)/(5)/(4)/(3)/ VMONI[2:0];
  {0x23,0x00},//(7)/(6)/(5)/(4)/(3)/(2)/ SCALMODE[1:0];
  {0x24,0x00},//MVALUE[7:0];
};



/* LGIT module */

static reg_struct_type t8et5_lens_shading_array[] =
{
	{0x0040, 0x00CA}, //--;
	{0x0041, 0x0063}, //--;
	{0x0042, 0x0035}, //--;
	{0x0043, 0x0016}, //--;
	{0x0044, 0x0023}, //--;
	{0x0045, 0x000A}, //--;
	{0x0046, 0x0020}, //--;
	{0x0047, 0x000C}, //--;
	{0x0048, 0x0003}, //--;
	{0x0049, 0x0000}, //--;
	{0x004A, 0x0000}, //--;
	{0x004B, 0x0000}, //--;
	{0x004C, 0x0000}, //--;
	{0x004D, 0x0000}, //--;
	{0x004E, 0x0000}, //--;
	{0x004F, 0x0000}, //--;
	{0x0050, 0x0004}, //--;
	{0x0051, 0x0084}, //--;
	{0x0052, 0x0034}, //--;
	{0x0053, 0x0014}, //--;
	{0x0054, 0x0034}, //--;
	{0x0055, 0x0068}, //--;
	{0x0056, 0x0005}, //--;
	{0x0057, 0x0040}, //--;
	{0x0058, 0x0000}, //--;
	{0x0059, 0x0034}, //--;
	{0x005A, 0x0066}, //--;
	{0x005B, 0x0000}, //--;
	{0x005C, 0x0000}, //--;
	{0x005D, 0x0012}, //--;
	{0x005E, 0x0046}, //--;
	{0x005F, 0x0069}, //--;
	{0x0060, 0x0078}, //--;
	{0x0061, 0x0005}, //--;
	{0x0062, 0x0040}, //--;
	{0x0063, 0x00C2}, //--;
	{0x0064, 0x0082}, //--;
	{0x0065, 0x00AA}, //--;
	{0x0066, 0x0000}, //--;
	{0x0067, 0x0000}, //--;
	{0x0068, 0x0020}, //--;
	{0x0069, 0x0008}, //--;
	{0x006B, 0x0000}, //--;
	{0x006C, 0x0000}, //--;
	{0x006D, 0x0000}, //--;
	{0x006E, 0x0000}, //--;
	{0x006F, 0x0000}, //--;
	{0x0070, 0x0030}, //--;
	{0x0071, 0x0080}, //--;
	{0x0072, 0x0000}, //--;
	{0x0073, 0x00C0}, //WBPCMODE/BBPCMOED/(5)/(4)/(3)/(2)/(1)/ABPCTH;
	{0x0074, 0x0003}, //BBPCLV[7:0];
	{0x0075, 0x0003}, //WBPCLV[7:0];
	{0x0076, 0x0000}, //--;
	{0x0077, 0x0000}, //--;
	{0x0078, 0x0000}, //--;
	{0x0079, 0x0000}, //--;
	{0x007A, 0x0000}, //--;
	{0x007B, 0x0000}, //--;
	{0x007C, 0x005F}, //--;
	{0x007D, 0x00AF}, //LSSCON ///(4)/;
	{0x007E, 0x0000}, //LSHGA[3:0] / LSVGA[3:0];
	{0x007F, 0x0000}, //LSHOFS[7:0];
	{0x0080, 0x0000}, //LSVOFS[7:0];
	{0x0081, 0x000A}, //LSALGR[7:0];
	{0x0082, 0x000A}, //LSALGB[7:0];
	{0x0083, 0x0000}, //LSALR[7:0];
	{0x0084, 0x000A}, //LSALB[7:0];
	{0x0085, 0x000B}, //LSARGR[7:0];
	{0x0086, 0x000B}, //LSARGB[7:0];
	{0x0087, 0x0000}, //LSARR[7:0];
	{0x0088, 0x0004}, //LSARB[7:0];
	{0x0089, 0x0005}, //LSAUGR[7:0];
	{0x008A, 0x0005}, //LSAUGB[7:0];
	{0x008B, 0x0000}, //LSAUR[7:0];
	{0x008C, 0x0007}, //LSAUB[7:0];
	{0x008D, 0x0005}, //LSADGR[7:0];
	{0x008E, 0x0005}, //LSADGB[7:0];
	{0x008F, 0x0000}, //LSADR[7:0];
	{0x0090, 0x0004}, //LSADB[7:0];
	{0x0091, 0x001F}, //LSBLGR[7:0];
	{0x0092, 0x001F}, //LSBLGB[7:0];
	{0x0093, 0x0026}, //LSBLR[7:0];
	{0x0094, 0x0011}, //LSBLB[7:0];
	{0x0095, 0x0023}, //LSBRGR[7:0];
	{0x0096, 0x0023}, //LSBRGB[7:0];
	{0x0097, 0x003D}, //LSBRR[7:0];
	{0x0098, 0x0024}, //LSBRB[7:0];
	{0x0099, 0x0015}, //LSCUGR[7:0];
	{0x009A, 0x0015}, //LSCUGB[7:0];
	{0x009B, 0x001F}, //LSCUR[7:0];
	{0x009C, 0x0014}, //LSCUB[7:0];
	{0x009D, 0x0016}, //LSCDGR[7:0];
	{0x009E, 0x0016}, //LSCDGB[7:0];
	{0x009F, 0x0020}, //LSCDR[7:0];
	{0x00A0, 0x0011}, //LSCDB[7:0];
	{0x00A1, 0x0000}, //LSDLGR[7:0];
	{0x00A2, 0x0000}, //LSDLGB[7:0];
	{0x00A3, 0x0000}, //LSDLR[7:0];
	{0x00A4, 0x0000}, //LSDLB[7:0];
	{0x00A5, 0x0000}, //LSDRGR[7:0];
	{0x00A6, 0x0000}, //LSDRGB[7:0];
	{0x00A7, 0x0020}, //LSDRR[7:0];
	{0x00A8, 0x0000}, //LSDRB[7:0];
	{0x00A9, 0x0000}, //LSEUGR[7:0];
	{0x00AA, 0x0000}, //LSEUGB[7:0];
	{0x00AB, 0x0000}, //LSEUR[7:0];
	{0x00AC, 0x0000}, //LSEUB[7:0];
	{0x00AD, 0x0000}, //LSEDGR[7:0];
	{0x00AE, 0x0000}, //LSEDGB[7:0];
	{0x00AF, 0x0000}, //LSEDR[7:0];
	{0x00B0, 0x0000}, //LSEDB[7:0];
	{0x00B1, 0x0000}, //--;
	{0x00B2, 0x0000}, //--;
	{0x00B3, 0x0000}, //--;
	{0x00B4, 0x0000}, //--;
	{0x00B5, 0x0000}, //--;
	{0x00B6, 0x0000}, //--;
	{0x00B7, 0x00FF}, //--;
	{0x00B8, 0x0000}, //--;
	{0x00B9, 0x0000}, //--;
	{0x00BA, 0x0000}, //--;
	{0x00BB, 0x0000}, //--;
	{0x00BC, 0x0000}, //--;
	{0x00BD, 0x0000}, //--;
	{0x00BE, 0x0000}, //--;
	{0x00BF, 0x0000}, //--;
	{0x00C0, 0x0080}, //--;
	{0x00C1, 0x0000}, //--;
	{0x00C2, 0x0044}, //(7)/(6)/(5)/(4)/(3)/ MIPI1L /(1)/(0);
	{0x00C3, 0x0004}, //--;
	{0x00C4, 0x0003}, //(7)/(6)/(5)/(4)/(3)/(2)/ PARALLEL_OUT_SW[1:0];
	{0x00C5, 0x0078}, //--;
	{0x00C6, 0x0095}, //--;
	{0x00C7, 0x0055}, //--;
	{0x00C8, 0x0056}, //--;
	{0x00C9, 0x00A7}, //--;
	{0x00CA, 0x0004}, //(7)/(6)/(5)/(4)/(3)/ PARALLEL_MODE /(1)/(0);
	{0x00CB, 0x0000}, //--;
	{0x00CC, 0x0011}, //FS_CODE[7:0];
	{0x00CD, 0x0044}, //FE_CODE[7:0];
	{0x00CE, 0x0022}, //LS_CODE[7:0];
	{0x00CF, 0x0033}, //LE_CODE[7:0];
	{0x00D0, 0x0030}, //--;
	{0x00D1, 0x0000}, //--;
	{0x00D2, 0x0001}, //--;
	{0x00D3, 0x0000}, //--;
	{0x00D4, 0x0000}, //--;
	{0x00D5, 0x0000}, //--;
	{0x00D6, 0x0000}, //--;
	{0x00D7, 0x0010}, //--;
	{0x00D8, 0x00FF}, //--;
	{0x00D9, 0x0000}, //--;
	{0x00DA, 0x0010}, //--;
	{0x00DB, 0x00FF}, //--;
	{0x00DC, 0x0081}, //--;
	{0x00DD, 0x0000}, //--;
	{0x00DE, 0x0000}, //--;
	{0x00DF, 0x0000}, //--;
	{0x00E0, 0x0001}, //--;
	{0x00E1, 0x0000}, //--;
	{0x00E2, 0x0000}, //--;
	{0x00E3, 0x0042}, //--;
	{0x00E4, 0x0003}, //--;
	{0x00E5, 0x00BE}, //--;
	{0x00E6, 0x002E}, //--;
	{0x00E7, 0x00D2}, //--;
	{0x00E8, 0x0030}, //--;
	{0x00E9, 0x0012}, //--;
	{0x00EA, 0x0000}, //--;
	{0x00EB, 0x0000}, //--;
	{0x00EC, 0x0000}, //--;
	{0x00ED, 0x0000}, //--;
	{0x00EE, 0x0000}, //--;
	{0x00EF, 0x0000}, //--;
	{0x00F0, 0x0090}, //--;
	{0x00F1, 0x0000}, //--;
	{0x00F2, 0x0054}, //--;
	{0x00F3, 0x0000}, //--;
	{0x00F4, 0x0000}, //--;
	{0x00F5, 0x0000}, //--;
	{0x00F6, 0x0080}, //--;
	{0x00F7, 0x0080}, //--;
	{0x00F8, 0x0000}, //--;
	{0x00F9, 0x0000}, //--;
	{0x00FA, 0x0000}, //--;
	{0x00FB, 0x0000}, //--;
	{0x00FC, 0x0000}, //--;
	{0x00FD, 0x0000}, //--;
	{0x00FE, 0x0000}, //--;
	{0x00FF, 0x0000}, //--;
	{0x0000, 0x0081}, //MODE_SEL / VREVON / HREVON / SWRST / GRHOLD /(2)/(1)/OUT_FORMAT;
};

/*=============================================================*/

static int t8et5_i2c_rxdata(unsigned short saddr,
	unsigned char *rxdata, int length)
{
	struct i2c_msg msgs[] = {
	{
		.addr   = saddr << 1,
		.flags = 0,
		.len   = 1,
		.buf   = rxdata,
	},
	{
		.addr  = saddr << 1,
		.flags = I2C_M_RD,
		.len   = 2,
		.buf   = rxdata,
	},
	};

	if (i2c_transfer(t8et5_client->adapter, msgs, 2) < 0) {
		CDBG("t8et5_i2c_rxdata failed saddr = 0x%x!\n",saddr);
		return -EIO;
	}

	return 0;
}

static int32_t t8et5_i2c_txdata(unsigned short saddr,
				 unsigned char *txdata, int length)
{
	struct i2c_msg msg[] = {
		{
		 .addr = saddr << 1,
		 .flags = 0,
		 .len = length,
		 .buf = txdata,
		 },
	};

     CDBG("calling t8et5_i2c_txdata saddr = 0x%x!\n",saddr);
	if (i2c_transfer(t8et5_client->adapter, msg, 1) < 0) {
		CDBG("t8et5_i2c_txdata faild 0x%x\n", t8et5_client->addr);
		return -EIO;
	}

	return 0;
}


static int32_t t8et5_i2c_read(unsigned short raddr,
				   unsigned short *rdata, int rlen)
{
	int32_t rc = 0;
	unsigned char buf[2];

	if (!rdata)
		return -EIO;

	memset(buf, 0, sizeof(buf));

	buf[0] = raddr;

	rc = t8et5_i2c_rxdata(t8et5_client->addr, buf, rlen);

	if (rc < 0) {
		CDBG("t8et5_i2c_read 0x%x failed!\n", raddr);
		return rc;
	}
    else
    	CDBG("t8et5_i2c_read value is 0x%x passed!\n", buf[0] << 8 | buf[1] );

	*rdata = (rlen == 2 ? buf[0] << 8 | buf[1] : buf[0]);

	return rc;

}

static int32_t t8et5_i2c_write_b(unsigned short saddr,unsigned short waddr, uint8_t bdata)
{
	int32_t rc = -EFAULT;
	unsigned char buf[3];

	memset(buf, 0, sizeof(buf));
	//buf[0] = (waddr & 0xFF00) >> 8;
	buf[0] = waddr;
	buf[1] = bdata;

	CDBG("i2c_write_b addr = %d, val = %d\n", waddr, bdata);
	rc = t8et5_i2c_txdata(saddr, buf, 2);

	if (rc < 0) {
		CDBG("i2c_write_b failed, addr = 0x%x, val = 0x%x!\n",
			 waddr, bdata);
	}

	return rc;
}

static int32_t t8et5_i2c_write_af_b(unsigned short saddr, unsigned short baddr,
				   unsigned short bdata)
{
	int32_t rc = -EIO;
	unsigned char buf[2];

	memset(buf, 0, sizeof(buf));
	buf[0] = baddr;
	buf[1] = bdata;
	CDBG("i2c_write_b addr = %d, val = %d\n", baddr, bdata);
	rc = t8et5_i2c_txdata(saddr, buf, 2);

	if (rc < 0)
		CDBG("i2c_write failed, saddr = 0x%x addr = 0x%x, val =0x%x!\n",
			  saddr, baddr, bdata);

	return rc;
}

static int32_t t8et5_af_i2c_write(uint16_t data)
{
	uint8_t code_val_msb, code_val_lsb;
	int32_t rc = 0;

	code_val_msb = data >> 4;
	code_val_lsb = ((data & 0x000F) << 4) | T8ET5_HW_DAMPING;

	rc = t8et5_i2c_write_af_b(T8ET5_AF_I2C_SLAVE_ID >>1 ,
			code_val_msb, code_val_lsb);

	if (rc < 0)
		return rc;

	return rc;
} /* t8et5_af_i2c_write */

static void t8et5_setup_af_tbl(void)
{
	int i;
	uint16_t t8et5_nl_region_boundary1 = 3;
	uint16_t t8et5_nl_region_boundary2 = 5;
	uint16_t t8et5_nl_region_code_per_step1 = 85;
	uint16_t t8et5_nl_region_code_per_step2 = 8;
	uint16_t t8et5_l_region_code_per_step = 6;

	t8et5_step_pos_tbl[0] = 0;

	for(i = 1; i <= T8ET5_TOTAL_STEPS_NEAR_TO_FAR; i++){
		if (i <= t8et5_nl_region_boundary1){
			t8et5_step_pos_tbl[i] = t8et5_step_pos_tbl[i-1] +
			t8et5_nl_region_code_per_step1;
		}else if (i <= t8et5_nl_region_boundary2)
			t8et5_step_pos_tbl[i] = t8et5_step_pos_tbl[i-1] +
			t8et5_nl_region_code_per_step2;
		else
			t8et5_step_pos_tbl[i] = t8et5_step_pos_tbl[i-1] +
			t8et5_l_region_code_per_step;
	}
}

static void t8et5_get_pict_fps(uint16_t fps, uint16_t *pfps)
{
	/* input fps is preview fps in Q8 format */
	uint32_t divider;	/*Q10 */
	uint32_t d1;
	uint32_t d2;

	uint16_t snapshot_height, preview_height, preview_width, snapshot_width;

	if (t8et5_ctrl->prev_res == QTR_SIZE) {
		preview_width = T8ET5_QTR_SIZE_WIDTH + T8ET5_HRZ_QTR_BLK_PIXELS;
		preview_height = T8ET5_QTR_SIZE_HEIGHT + T8ET5_VER_QTR_BLK_LINES;
	}
	else {
		/* full size resolution used for preview. */
		preview_width = T8ET5_FULL_SIZE_WIDTH + T8ET5_HRZ_FULL_BLK_PIXELS;
		preview_height= T8ET5_FULL_SIZE_HEIGHT + T8ET5_VER_FULL_BLK_LINES;
	}
	if (t8et5_ctrl->pict_res == QTR_SIZE){
		snapshot_width  = T8ET5_QTR_SIZE_WIDTH + T8ET5_HRZ_QTR_BLK_PIXELS;
		snapshot_height = T8ET5_QTR_SIZE_HEIGHT + T8ET5_VER_QTR_BLK_LINES;
	}
	else {
		snapshot_width  = T8ET5_FULL_SIZE_WIDTH + T8ET5_HRZ_FULL_BLK_PIXELS;
		snapshot_height = T8ET5_FULL_SIZE_HEIGHT + T8ET5_VER_FULL_BLK_LINES;
	}
	if(t8et5_ctrl->prev_res == t8et5_ctrl->pict_res )
		divider = 0x00000400;
	else {
		d1 = (preview_height * 0x00000400) / snapshot_height;
		d2 = (preview_width * 0x00000400) / snapshot_width;

		divider = (d1 * d2) / 0x00000400;
	}
	*pfps = (uint16_t)( (fps * divider) / 0x00000400);

}/*endof t8et5_get_pict_fps*/

static uint16_t t8et5_get_prev_lines_pf(void)
{
	if (t8et5_ctrl->prev_res == QTR_SIZE)
		return (T8ET5_QTR_SIZE_HEIGHT + T8ET5_VER_QTR_BLK_LINES);
	else
		return (T8ET5_FULL_SIZE_HEIGHT + T8ET5_VER_FULL_BLK_LINES);
}

static uint16_t t8et5_get_prev_pixels_pl(void)
{
	if (t8et5_ctrl->prev_res == QTR_SIZE)
		return (T8ET5_QTR_SIZE_WIDTH + T8ET5_HRZ_QTR_BLK_PIXELS);
	else
		return (T8ET5_FULL_SIZE_WIDTH + T8ET5_HRZ_FULL_BLK_PIXELS);
}

static uint16_t t8et5_get_pict_lines_pf(void)
{
	if (t8et5_ctrl->pict_res == QTR_SIZE)
		return (T8ET5_QTR_SIZE_HEIGHT + T8ET5_VER_QTR_BLK_LINES);
	else
		return (T8ET5_FULL_SIZE_HEIGHT + T8ET5_VER_FULL_BLK_LINES);
}

static uint16_t t8et5_get_pict_pixels_pl(void)
{
	if (t8et5_ctrl->pict_res == QTR_SIZE)
		return (T8ET5_QTR_SIZE_WIDTH + T8ET5_HRZ_QTR_BLK_PIXELS);
	else
		return (T8ET5_FULL_SIZE_WIDTH + T8ET5_HRZ_FULL_BLK_PIXELS);
}

static uint32_t t8et5_get_pict_max_exp_lc(void)
{
	if (t8et5_ctrl->pict_res == QTR_SIZE)
		return ((T8ET5_QTR_SIZE_HEIGHT + T8ET5_VER_QTR_BLK_LINES) * 24);
	else
		return ((T8ET5_FULL_SIZE_HEIGHT + T8ET5_VER_FULL_BLK_LINES)* 24);
}

static int32_t t8et5_set_fps(struct fps_cfg *fps)
{
	int32_t rc = 0;
	t8et5_ctrl->fps_divider = fps->fps_div;
	t8et5_ctrl->pict_fps_divider = fps->pict_fps_div;
	t8et5_ctrl->fps = fps->f_mult;
	return rc;
}

static int32_t t8et5_write_exp_gain(uint16_t gain, uint32_t line)
{
	int32_t rc = 0;
	uint16_t elc;
	uint16_t aec_msb;
	uint16_t aec_lsb;
	uint8_t t8et5_offset = 1;
	uint32_t line_length_ratio = 1*Q8;
	uint32_t total_lines_per_frame = 0;
	static uint8_t reduced_line_to_change_fps = FALSE;

	/* check if linecount is within range */
	if (t8et5_ctrl->sensormode != SENSOR_PREVIEW_MODE)
		elc = (uint16_t)line;
	else
		elc = (uint16_t)( (uint32_t)(line * t8et5_ctrl->fps_divider) / Q10);


	if (t8et5_ctrl->curr_res == QTR_SIZE)
		total_lines_per_frame = ((T8ET5_QTR_SIZE_HEIGHT + T8ET5_VER_QTR_BLK_LINES) *
								t8et5_ctrl->fps_divider) / Q10;
	else
		total_lines_per_frame = ((T8ET5_FULL_SIZE_HEIGHT + T8ET5_VER_FULL_BLK_LINES) *
								t8et5_ctrl->fps_divider) / Q10;

	if ((total_lines_per_frame - t8et5_offset) < elc)
		line_length_ratio =(((uint32_t)(elc) * Q8) ) / (total_lines_per_frame-t8et5_offset) ;
	else
		line_length_ratio = 1 * Q8;

	if (t8et5_ctrl->sensormode != SENSOR_PREVIEW_MODE)
		stored_gain = gain;


	aec_msb = (uint16_t) ((elc & 0xFF00) >> 8);
	aec_lsb = (uint16_t) (elc & 0x00FF);

	if ((reduced_line_to_change_fps == TRUE) || (t8et5_ctrl->sensormode != SENSOR_PREVIEW_MODE)) {
		total_lines_per_frame = (uint32_t) (total_lines_per_frame*line_length_ratio/ Q8);
		rc = t8et5_i2c_write_b(t8et5_client->addr,0x12, (uint8_t)((total_lines_per_frame & 0xFF00)>>8));
		rc |= t8et5_i2c_write_b(t8et5_client->addr,0x13, (uint8_t)(total_lines_per_frame & 0x00FF));

		reduced_line_to_change_fps = FALSE;
		if (t8et5_ctrl->sensormode == SENSOR_PREVIEW_MODE)
			rc |= -EINVAL;
	} else if ((reduced_line_to_change_fps == FALSE) && (line_length_ratio != stored_line_length_ratio))
		reduced_line_to_change_fps = TRUE;

	rc |= t8et5_i2c_write_b(t8et5_client->addr, T8ET5_AEC_MSB, (uint8_t)aec_msb);

	rc |= t8et5_i2c_write_b(t8et5_client->addr, T8ET5_AEC_LSB, (uint8_t)aec_lsb);

	rc |= t8et5_i2c_write_b(t8et5_client->addr,T8ET5_GAIN_MSB, (uint8_t)((stored_gain & 0xFF00)>>8));

	rc |= t8et5_i2c_write_b(t8et5_client->addr,T8ET5_GAIN_LSB, (uint8_t)(stored_gain & 0x00FF));

	stored_gain = gain;
	stored_line_length_ratio = line_length_ratio;

	return rc;
}/* endof t8et5_write_exp_gain*/

static int32_t t8et5_set_pict_exp_gain(uint16_t gain, uint32_t line)
{
	int32_t rc = 0;
	rc = t8et5_write_exp_gain(gain, line);
	return rc;
}/* endof t8et5_set_pict_exp_gain*/

#if 0
static int32_t t8et5_test(enum t8et5_test_mode_t mode)
{
	int32_t rc = 0;
    //mode = TEST_1;
	if (mode == TEST_OFF)
		return rc;

	/* Activate  the Color bar test pattern */
	if (mode == TEST_1) {
		/* Activate  the Color bar test pattern */
		rc = t8et5_i2c_write_b(t8et5_client->addr,
							   T8ET5_COLOR_BAR_PATTERN_SEL_REG,0x40);
		if (rc < 0)
			return rc;
		rc = t8et5_i2c_write_b(t8et5_client->addr,0x3145,0x80);
		if (rc < 0 )
			return rc;
		rc = t8et5_i2c_write_b(t8et5_client->addr, 0x3148,0x80);
		if (rc < 0 )
			return rc;
		rc = t8et5_i2c_write_b(t8et5_client->addr,
							   T8ET5_COLOR_BAR_ENABLE_REG,0x01);
		if (rc < 0 )
			return rc;
	} else if (mode == TEST_2) {
		rc = t8et5_i2c_write_b(t8et5_client->addr,
							   T8ET5_COLOR_BAR_PATTERN_SEL_REG,0x50);
		if (rc < 0)
			return rc;
		rc = t8et5_i2c_write_b(t8et5_client->addr,0x3145,0x80);
		if (rc < 0 )
			return rc;
		rc = t8et5_i2c_write_b(t8et5_client->addr, 0x3148,0x80);
		if (rc < 0 )
			return rc;
		rc = t8et5_i2c_write_b(t8et5_client->addr,
							   T8ET5_COLOR_BAR_ENABLE_REG,0x01);
		if (rc < 0 )
			return rc;
	} else {
		rc = t8et5_i2c_write_b(t8et5_client->addr,
							   T8ET5_COLOR_BAR_ENABLE_REG,0x00);
		if (rc < 0 )
			return rc;
		rc = t8et5_i2c_write_b(t8et5_client->addr,
							   T8ET5_COLOR_BAR_PATTERN_SEL_REG,0x00);
		if (rc < 0)
			return rc;
	}
	return rc;
}
#endif
static int32_t t8et5_lens_shading_enable(uint8_t is_enable)
{
	int32_t i, array_length;
	int32_t rc = 0;

    array_length = sizeof(t8et5_lens_shading_array) /
				   sizeof(t8et5_lens_shading_array[0]);

	/* lens shading setting */
	for (i=0; i<array_length; i++) {
		rc = t8et5_i2c_write_b(t8et5_client->addr,
							   t8et5_lens_shading_array[i].reg_addr,
							   t8et5_lens_shading_array[i].reg_val);
		if ( rc < 0 )
			return rc;
	}

    return rc;
}

static int32_t initialize_t8et5_registers(void)
{
	int32_t i, array_length;
	int32_t rc = 0;
	//uint8_t chipid = 0;

	array_length = sizeof(t8et5_init_settings_array) /
					sizeof(t8et5_init_settings_array[0]);

	/* Configure sensor for Preview mode and Snapshot mode */
	for (i=0; i < array_length; i++)
	{
		rc = t8et5_i2c_write_b(t8et5_client->addr,
							   t8et5_init_settings_array[i].reg_addr,
							   t8et5_init_settings_array[i].reg_val);
		if (rc < 0) {
	        return rc;
	    }
	}

	/* lens shading setting */
	rc = t8et5_lens_shading_enable(TRUE);
	if (rc < 0) {
	    return rc;
	}

	return rc;
} /* end of initialize_t8et5_ov8m0vc_registers. */

static int32_t t8et5_setting(int sensor_resolution)
{
	int32_t i, array_length;
	uint16_t total_lines_per_frame=0;
	int32_t rc = 0;
    CDBG("Inside t8et5_setting\n");
	switch(sensor_resolution) {
		case QTR_SIZE:
			/* stop streaming */
			rc = t8et5_i2c_write_b(t8et5_client->addr,0x00, 0x01);
			if (rc < 0)
				return rc;

			array_length = sizeof(t8et5_qtr_settings_array) /
						   sizeof(t8et5_qtr_settings_array[0]);

			/* Configure sensor for XGA preview mode */
	  		for (i=0; i<array_length; i++) {
				rc = t8et5_i2c_write_b(t8et5_client->addr,
									   t8et5_qtr_settings_array[i].reg_addr,
									   t8et5_qtr_settings_array[i].reg_val);
				if (rc < 0)
					return rc;
			}

			/* Update the registers with correct values for AFR */
			total_lines_per_frame = ((T8ET5_QTR_SIZE_HEIGHT +
									 T8ET5_VER_QTR_BLK_LINES) *
									 t8et5_ctrl->fps_divider) / Q10;

			rc = t8et5_i2c_write_b(t8et5_client->addr, 0x12,
						(uint8_t)((total_lines_per_frame & 0xFF00) >> 8));
			if (rc < 0)
				return rc;
			rc = t8et5_i2c_write_b(t8et5_client->addr, 0x13,
						(uint8_t)(total_lines_per_frame & 0x00FF));
			if (rc < 0)
				return rc;

			/* start streaming */
			rc = t8et5_i2c_write_b(t8et5_client->addr, 0x00, 0x81);
			if (rc < 0)
				return rc;

			mdelay(T8ET5_REGISTER_UPDATE_DELAY);

			break;

		case FULL_SIZE:
			/* stop streaming */
			rc = t8et5_i2c_write_b(t8et5_client->addr,0x00, 0x01);
			if (rc < 0)
				return rc;

			array_length = sizeof(t8et5_full_settings_array) /
						   sizeof(t8et5_full_settings_array[0]);

			/* Configure sensor for XGA preview mode */
	  		for (i=0; i<array_length; i++) {
				rc = t8et5_i2c_write_b(t8et5_client->addr,
									   t8et5_full_settings_array[i].reg_addr,
									   t8et5_full_settings_array[i].reg_val);
				if (rc < 0)
					return rc;
			}

			/* Update the registers with correct values for AFR */
			total_lines_per_frame = ((T8ET5_FULL_SIZE_HEIGHT +
									 T8ET5_VER_FULL_BLK_LINES) *
									 t8et5_ctrl->fps_divider) / Q10;

			rc = t8et5_i2c_write_b(t8et5_client->addr, 0x12,
						(uint8_t)((total_lines_per_frame & 0xFF00) >> 8));
			if (rc < 0)
				return rc;
			rc = t8et5_i2c_write_b(t8et5_client->addr, 0x13,
						(uint8_t)(total_lines_per_frame & 0x00FF));
			if (rc < 0)
				return rc;

			/* start streaming */
			rc = t8et5_i2c_write_b(t8et5_client->addr, 0x00, 0x81);
			if (rc < 0)
				return rc;

			mdelay(T8ET5_REGISTER_UPDATE_DELAY);

			break;
		default:
			rc = -EINVAL;
	    	break;
	}
	return rc;
} /*endof  t8et5_setting*/



static int32_t t8et5_video_config(int mode )
{
	int32_t rc = 0;
	if( t8et5_ctrl->curr_res != t8et5_ctrl->prev_res) {
		rc = t8et5_setting(t8et5_ctrl->prev_res);
		if (rc < 0)
			return rc;
		else
			t8et5_ctrl->curr_res = t8et5_ctrl->prev_res;
	}

	t8et5_ctrl->sensormode = mode;

	return rc;
}/*end of ov354_video_config*/

static int32_t t8et5_snapshot_config(int mode)
{
	int32_t rc = 0;
	if (t8et5_ctrl->curr_res != t8et5_ctrl->pict_res) {
		rc = t8et5_setting(t8et5_ctrl->pict_res);
		if (rc < 0)
			return rc;
		else
			t8et5_ctrl->curr_res = t8et5_ctrl->pict_res;
	}

	t8et5_ctrl->sensormode = mode;

	return rc;
 }/*end of t8et5_snapshot_config*/

static int32_t t8et5_raw_snapshot_config(int mode)
{
	int32_t rc = 0;

	if (t8et5_ctrl->curr_res != t8et5_ctrl->pict_res) {
		rc = t8et5_setting(t8et5_ctrl->pict_res);
		if (rc < 0)
			return rc;
		else
			/* Update sensor resolution */
			t8et5_ctrl->curr_res = t8et5_ctrl->pict_res;
	}

	t8et5_ctrl->sensormode = mode;

	return rc;
}/*end of t8et5_raw_snapshot_config*/

static int32_t t8et5_power_down(void)
{
	return 0;
}

static int32_t t8et5_move_focus( int direction,
	int32_t num_steps)
{
	uint8_t t8et5_damping_time_wait;
	int8_t step_direction;
	int8_t dest_step_position;
	uint16_t dest_lens_pos, target_dist, small_step;
	int16_t next_lens_pos;
	int32_t rc = 0;

	if (num_steps == 0)
		return rc;

	if (direction == MOVE_NEAR)
		step_direction = 1;
	else if (direction == MOVE_FAR)
		step_direction = -1;
	else {
		CDBG("Illegal focus direction/n");
		return -EINVAL;
	}

	dest_step_position = t8et5_ctrl->curr_step_pos +
						(step_direction * num_steps);

	if (dest_step_position < 0)
		dest_step_position = 0;
	else if (dest_step_position > T8ET5_TOTAL_STEPS_NEAR_TO_FAR)
		dest_step_position = T8ET5_TOTAL_STEPS_NEAR_TO_FAR;

	dest_lens_pos = t8et5_step_pos_tbl[dest_step_position];

	/* Taking small damping steps */
	target_dist = step_direction *
				  (dest_lens_pos - t8et5_ctrl->curr_lens_pos);
	if (target_dist == 0)
		return rc;

	if(t8et5_use_threshold_damping && (step_direction < 0) &&
	  (target_dist >= t8et5_step_pos_tbl[T8ET5_DAMPING_THRESHOLD])) {
		small_step = (uint16_t)(target_dist /T8ET5_DAMPING_FINE_STEP);
		if ((target_dist % T8ET5_DAMPING_FINE_STEP) != 0)
			small_step = small_step + 1;

		t8et5_damping_time_wait = 1;
	} else {
		small_step = (uint16_t)target_dist/T8ET5_DAMPING_COARSE_STEP;
		if((target_dist % T8ET5_DAMPING_COARSE_STEP) != 0)
			small_step = small_step + 1;

		t8et5_damping_time_wait = 4;
	}

	for (next_lens_pos =
	     t8et5_ctrl->curr_lens_pos + (step_direction * small_step);
		(step_direction * next_lens_pos) <= (step_direction * dest_lens_pos);
		 next_lens_pos += (step_direction * small_step)) {
		rc = t8et5_af_i2c_write(next_lens_pos);
		if (rc < 0) {
			CDBG("t8et5_af_i2c_write Failed in Move Focus!!!\n");
			return rc;
		}
		t8et5_ctrl->curr_lens_pos = next_lens_pos;
		if(t8et5_ctrl->curr_lens_pos != dest_lens_pos)
			mdelay(t8et5_damping_time_wait);
	}

	if(t8et5_ctrl->curr_lens_pos != dest_lens_pos) {
		rc = t8et5_af_i2c_write(dest_lens_pos);
		if (rc < 0) {
			CDBG("t8et5_af_i2c_write Failed in Move Focus Final step!!!\n");
			return rc;
		}
	}

	/* Storing the current lens Position */
	t8et5_ctrl->curr_lens_pos = dest_lens_pos;
	t8et5_ctrl->curr_step_pos = dest_step_position;

	return rc;
}

static int32_t t8et5_set_default_focus(uint8_t af_step)
{
	int16_t position;
	int32_t rc = 0;
	uint8_t t8et5_damping_time_wait = 4;

	if(t8et5_use_default_damping)
	{
		/* when lens is uninitialized */
		if(t8et5_ctrl->curr_lens_pos == -1 || (t8et5_focus_debug == 1)) {
			position = t8et5_step_pos_tbl[T8ET5_DAMPING_THRESHOLD];
			rc = t8et5_af_i2c_write(position);
			if (rc < 0)
				return rc;

			t8et5_ctrl->curr_step_pos = T8ET5_DAMPING_THRESHOLD;
			t8et5_ctrl->curr_lens_pos = position;
			mdelay(t8et5_damping_time_wait);
		}

		rc = t8et5_move_focus(MOVE_FAR, t8et5_ctrl->curr_step_pos);
		if(rc < 0)
			return rc;
	}
	else {
		rc = t8et5_af_i2c_write(t8et5_step_pos_tbl[0]);
		if (rc < 0)
			return rc;
		t8et5_ctrl->curr_step_pos = 0;
		t8et5_ctrl->curr_lens_pos = t8et5_step_pos_tbl[0];
	}
	return rc;
}

static int t8et5_probe_init_done(const struct msm_camera_sensor_info *data)
{
	gpio_direction_output(data->sensor_reset, 0);
	gpio_free(data->sensor_reset);
	return 0;
}

static int t8et5_probe_init_sensor(const struct msm_camera_sensor_info *data)
{
	int32_t rc = 0;
	uint8_t chipid = 0;

	CDBG("Calling t8et5_probe_init_sensor\n");
	rc = gpio_request(data->sensor_reset, "t8et5");
	if (!rc)
		gpio_direction_output(data->sensor_reset, 1);
	else
		goto init_probe_done;

	msleep(T8ET5_RESET_DELAY_MSECS);

	/* 3. Read sensor Model ID: */
	rc = t8et5_i2c_read(T8ET5_REG_MODEL_ID, (unsigned short*)&chipid,1);
	if (rc < 0)
		goto init_probe_fail;

	CDBG("t8et5 model_id = 0x%x\n", chipid);


	if (chipid != T8ET5_MODEL_ID) {
		rc = -ENODEV;
		goto init_probe_fail;
	}

	goto init_probe_done;

init_probe_fail:
	CDBG("t8et5_probe_init_sensor sensore probe failed\n");
	t8et5_probe_init_done(data);

init_probe_done:
	CDBG(" t8et5_probe_init_sensor finishes\n");
	return rc;
}

static int t8et5_sensor_open_init(const struct msm_camera_sensor_info *data)
{
	int32_t  rc = 0;

	t8et5_ctrl = kzalloc(sizeof(struct t8et5_ctrl_t), GFP_KERNEL);
	if (!t8et5_ctrl) {
		CDBG("t8et5_init failed!\n");
		rc = -ENOMEM;
		goto init_done;
	}

	t8et5_ctrl->fps_divider = 1 * 0x00000400;
	t8et5_ctrl->pict_fps_divider = 1 * 0x00000400;
	t8et5_ctrl->set_test = TEST_OFF;
	t8et5_ctrl->prev_res = QTR_SIZE;
	t8et5_ctrl->pict_res = FULL_SIZE;
	t8et5_ctrl->curr_res = INVALID_SIZE;

	if (data)
		t8et5_ctrl->sensordata = data;

    msm_camio_clk_rate_set(24000000);
	mdelay(20);

	msm_camio_camif_pad_reg_reset();
	mdelay(20);

	rc = t8et5_probe_init_sensor(data);
	if (rc < 0) {
		kfree(t8et5_ctrl);
		goto init_done;
	}

	/* Initialize Sensor registers */
	rc = initialize_t8et5_registers();
	if (rc < 0)
		goto init_fail1;

	/* AF Initialization */
	t8et5_ctrl->curr_lens_pos = -1;
	/* set up lens position table */
	t8et5_setup_af_tbl();

    CDBG("sensor regiters initialized \n");

	if( t8et5_ctrl->curr_res != t8et5_ctrl->prev_res) {
	CDBG("calling t8et5_setting\n");
		rc = t8et5_setting(t8et5_ctrl->prev_res);
		if (rc < 0)
			goto init_fail1;
		else
			t8et5_ctrl->curr_res = t8et5_ctrl->prev_res;
	}
	goto init_done;

    CDBG("Open Successful rc = %d\n", rc);
	/* reset the driver state */
init_fail1:
	CDBG(" init_fail \n");
	t8et5_probe_init_done(data);
	kfree(t8et5_ctrl);

init_done:
	return rc;

} /*endof t8et5_sensor_open_init*/

static int t8et5_init_client(struct i2c_client *client)
{
	/* Initialize the MSM_CAMI2C Chip */
	init_waitqueue_head(&t8et5_wait_queue);
	return 0;
}

static int32_t t8et5_set_sensor_mode(int  mode,
	int  res)
{
	int32_t rc = 0;

	switch (mode) {
	case SENSOR_PREVIEW_MODE:
		rc = t8et5_video_config(mode);
		break;

	case SENSOR_SNAPSHOT_MODE:
		rc = t8et5_snapshot_config(mode);
		break;

	case SENSOR_RAW_SNAPSHOT_MODE:
		rc = t8et5_raw_snapshot_config(mode);
		break;

	default:
		rc = -EINVAL;
		break;
	}
	return rc;
}

int t8et5_sensor_config(void __user *argp)
{
	struct sensor_cfg_data cdata;
	int   rc = 0;

	if (copy_from_user(&cdata,
				(void *)argp,
				sizeof(struct sensor_cfg_data)))
		return -EFAULT;

	down(&t8et5_sem);

  	CDBG("t8et5_sensor_config: cfgtype = %d\n",
	  cdata.cfgtype);
		switch (cdata.cfgtype) {
		case CFG_GET_PICT_FPS:
				t8et5_get_pict_fps(
				cdata.cfg.gfps.prevfps,
				&(cdata.cfg.gfps.pictfps));

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data)))
				rc = -EFAULT;
			break;

		case CFG_GET_PREV_L_PF:
			cdata.cfg.prevl_pf =
			t8et5_get_prev_lines_pf();

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data)))
				rc = -EFAULT;
			break;

		case CFG_GET_PREV_P_PL:
			cdata.cfg.prevp_pl =
				t8et5_get_prev_pixels_pl();

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data)))
				rc = -EFAULT;
			break;

		case CFG_GET_PICT_L_PF:
			cdata.cfg.pictl_pf =
				t8et5_get_pict_lines_pf();

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data)))
				rc = -EFAULT;
			break;

		case CFG_GET_PICT_P_PL:
			cdata.cfg.pictp_pl =
				t8et5_get_pict_pixels_pl();

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data)))
				rc = -EFAULT;
			break;

		case CFG_GET_PICT_MAX_EXP_LC:
			cdata.cfg.pict_max_exp_lc =
				t8et5_get_pict_max_exp_lc();

			if (copy_to_user((void *)argp,
				&cdata,
				sizeof(struct sensor_cfg_data)))
				rc = -EFAULT;
			break;

		case CFG_SET_FPS:
		case CFG_SET_PICT_FPS:
			rc = t8et5_set_fps(&(cdata.cfg.fps));
			break;

		case CFG_SET_EXP_GAIN:
			rc =
				t8et5_write_exp_gain(
					cdata.cfg.exp_gain.gain,
					cdata.cfg.exp_gain.line);
			break;

		case CFG_SET_PICT_EXP_GAIN:
			rc =
				t8et5_set_pict_exp_gain(
					cdata.cfg.exp_gain.gain,
					cdata.cfg.exp_gain.line);
			break;

		case CFG_SET_MODE:
			rc = t8et5_set_sensor_mode(cdata.mode,
						cdata.rs);
			break;

		case CFG_PWR_DOWN:
			rc = t8et5_power_down();
			break;

		case CFG_MOVE_FOCUS:
			rc =
				t8et5_move_focus(
					cdata.cfg.focus.dir,
					cdata.cfg.focus.steps);
			break;
		case CFG_SET_LENS_SHADING:
			CDBG("%s: CFG_SET_LENS_SHADING\n", __func__);
			rc = t8et5_lens_shading_enable(cdata.cfg.lens_shading);
		break;
		case CFG_SET_DEFAULT_FOCUS:
			rc =
				t8et5_set_default_focus(
					cdata.cfg.focus.steps);
			break;

		case CFG_SET_EFFECT:
			rc = t8et5_set_default_focus(
						cdata.cfg.effect);
			break;

		default:
			rc = -EFAULT;
			break;
		}

	up(&t8et5_sem);

	return rc;
}

static int t8et5_sensor_release(void)
{
	int rc = -EBADF;

	down(&t8et5_sem);
	t8et5_power_down();

	gpio_direction_output(t8et5_ctrl->sensordata->sensor_reset, 0);
	gpio_free(t8et5_ctrl->sensordata->sensor_reset);

	kfree(t8et5_ctrl);
	t8et5_ctrl = NULL;

	CDBG("t8et5_release completed\n");
	up(&t8et5_sem);

	return rc;
}

static int t8et5_i2c_probe(struct i2c_client *client,
	const struct i2c_device_id *id)
{
	int rc = 0;
	CDBG("t8et5_probe called!\n");

	if (!i2c_check_functionality(client->adapter, I2C_FUNC_I2C)) {
		CDBG("i2c_check_functionality failed\n");
		goto probe_failure;
	}

	t8et5_sensorw = kzalloc(sizeof(struct t8et5_work_t), GFP_KERNEL);
	if (!t8et5_sensorw) {
		CDBG("kzalloc failed.\n");
		rc = -ENOMEM;
		goto probe_failure;
	}

	i2c_set_clientdata(client, t8et5_sensorw);
	t8et5_init_client(client);
	t8et5_client = client;

	mdelay(50);

	CDBG("t8et5_probe successed! rc = %d\n", rc);
	return 0;

	probe_failure:
	CDBG("t8et5_probe failed! rc = %d\n", rc);
	return rc;
}

static const struct i2c_device_id t8et5_i2c_id[] = {
	{"t8et5", 0},
	{ }
};

static struct i2c_driver t8et5_i2c_driver = {
	.id_table = t8et5_i2c_id,
	.probe	= t8et5_i2c_probe,
	.remove = __exit_p(t8et5_i2c_remove),
	.driver = {
		.name = "t8et5",
	},
};

static int t8et5_sensor_probe(const struct msm_camera_sensor_info *info,
		struct msm_sensor_ctrl *s)
{

	int rc = i2c_add_driver(&t8et5_i2c_driver);
	if (rc < 0 || t8et5_client == NULL) {
		rc = -ENOTSUPP;
		goto probe_done;
	}

	msm_camio_clk_rate_set(24000000);
	mdelay(20);

	rc = t8et5_probe_init_sensor(info);
	if (rc < 0)
		goto probe_done;

	s->s_init = t8et5_sensor_open_init;
	s->s_release = t8et5_sensor_release;
	s->s_config  = t8et5_sensor_config;
	t8et5_probe_init_done(info);

probe_done:
	CDBG("%s %s:%d\n", __FILE__, __func__, __LINE__);
	return rc;
}

static int __t8et5_probe(struct platform_device *pdev)
{
	return msm_camera_drv_start(pdev, t8et5_sensor_probe);
}

static struct platform_driver msm_camera_driver = {
	.probe = __t8et5_probe,
	.driver = {
		.name = "msm_camera_t8et5",
		.owner = THIS_MODULE,
	},
};

static int __init t8et5_init(void)
{
	return platform_driver_register(&msm_camera_driver);
}

module_init(t8et5_init);
void t8et5_exit(void)
{
	i2c_del_driver(&t8et5_i2c_driver);
}

