OMXCore
77401*.patch

MM-Video
77403*.patch
77404*.patch
77407*.patch
77866*.patch 

kernel
77408*.patch
77409*.patch

framework/base
77690*.patch
